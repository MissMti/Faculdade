#ifndef _LGA_PTH_H
#define _LGA_PTH_H

void simulate_pth(byte *grid_1, byte *grid_2, int grid_size, int num_threads);

#endif
