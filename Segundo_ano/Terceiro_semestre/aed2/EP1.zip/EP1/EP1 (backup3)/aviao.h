#include <iostream>
#include <iomanip>
#include <fstream>
#include <random>
#include <string.h>
#pragma once

using namespace std;

class aviao{
    private:
        char nome[15];
        int prioridade;
        int tipo;
        long long c;
        double d;
        long long t_chegado;

    public:
        char* getnome(); 
        void setnome(int seed);
        int getprioridade();//0: emergencia, 1:combustivel zerado, 2:+10%, 3:pousa, 4:decolagem
        void setprioridade(int prio);
        int gettipo();//tipo 0pe 1de 2pn 3dn
        void settipo(int tip);
        long long getC();
        void setC(long long comb);
        double getD();
        void setD(double deco);
        long long gett_chegado();
        void sett_chegado(long long t_chegou);
        void atualiza(long long tempo);
};