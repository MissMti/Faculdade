#include <iostream>
#include <iomanip>
#include <string.h>
#include <cstdlib>
#include <ctime>
//#include "Fila.h"
#include "aviao.h"


using namespace std;

//nova biblioteca soh para o funcionamento do negocio + funcao de leitura apenas;

void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V);
void organizar(long long k, long long m, aviao* voo,long long T);

int main(){
    long long T,K,pp,pd,pe,C,V;
    long long i,j;

    //leituras
    cout<<"*** CENTRAL DE COMANDO DO AEROPORTO ABC ***"<<endl<<endl;
    cout<<"Insira valor de T:";
    cin>>T;
    cout<<endl;
    cout<<"Insira valor de K:";
    cin>>K;
    cout<<endl;
    cout<<"Insira valor de Pp(em %):";
    cin>>pp;
    cout<<endl;
    pd=100-pp;
    cout<<"Insira valor de Pe(em %):";
    cin>>pe;
    cout<<endl;
    cout<<"Insira valor de C:";
    cin>>C;
    cout<<endl;
    cout<<"Insira valor de V:";
    cin>>V;
    cout<<endl;

    //cout<<T<<endl<<K<<endl<<pp<<endl<<pd<<endl<<pe<<endl<<C<<endl<<V<<endl;
    

    programa(T,K,pp,pd,pe,C,V);
    return 0;
}

void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V){
    long long i,m,l,a=0,param,b;
    double mC,mCG=0,nV=0,npE=0,ndE=0,TpE=0,TdE=0;
    long long qtdemergencia=0;
    long long p0=0,p1=0,p2=0,p3=0,p4=0;
    char* name[K*T+10];
    aviao fila[10][K*T+10];
    long long guarda_i[10][K*T+10];
    long long seed=time(0);
    srand(seed);
    aviao voo[K*T+10];
    
    
    for(m=1;m<T+1;m++){
        //atualiza voos

        cout<<endl<<endl<< "NOVO ROUND"<<endl<<endl<<endl;
        cout<<"m:"<<m<<endl;
        for(i=0;i<K*(m-1);i++){
            voo[i].atualiza(m);
            
        }
       

        //cria K voo
        cout<<endl<<endl<<"Novos avioes: "<<endl;
        for(l=0;l<K;l++){
            voo[a].settipo(1);
            if(rand()%100>pp){//decolagem
                voo[a].settipo(1);
                param=(rand()%V)+1;
                voo[a].setD((double)param);
                //cout<<"param"<<param;
                voo[a].setprioridade(4);
            }
            else{//pouso
                voo[a].settipo(0);
                param=rand()%C;
                voo[a].setC(param);
                if(param==0){
                    voo[a].setprioridade(1);
                }
                else{
                    voo[a].setprioridade(3);
                }
            }
            if(rand()%100<pe){//normal
                if(voo[a].getprioridade()==1){
                    voo[a].setprioridade(6);
                }
                else{
                    voo[a].setprioridade(0);
                }
            }
            

            //cout<<"oi";
            string n;
            voo[a].sett_chegado(m);
            voo[a].setnome(a*seed);
            name[a]=voo[a].getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<endl;
            cout<<"T:"<<voo[a].gettipo()<<"  P:"<<voo[a].getprioridade()<<"  t_chegado:"<<voo[a].gett_chegado();
            if(voo[a].gettipo()==0){
                cout<<"  C:"<<voo[a].getC();
            }
            else{
                cout<<"  D:"<<voo[a].getD();
            }
            cout<<endl;

            a++;


        }
        
        //organiza "fila"
        long long i,p0=0,p1=0,p2=0,p3=0,p4=0,p6=0;
        
        long long h=0,e, f=0;

        for(i=0;i<K*m;i++){
                //cout<<"a2";
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                guarda_i[voo[i].getprioridade()][p0]=i;
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                guarda_i[voo[i].getprioridade()][p1]=i;
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                guarda_i[voo[i].getprioridade()][p2]=i;
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                guarda_i[voo[i].getprioridade()][p3]=i;
                p3++;
            }
            if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                guarda_i[voo[i].getprioridade()][p4]=i;
                p4++;
            }
            if(voo[i].getprioridade()==6){
                fila[voo[i].getprioridade()][p6]=voo[i];
                guarda_i[voo[i].getprioridade()][p6]=i;
                p6++;
            }
        }    
        cout<<p0<<p1<<p2<<p3<<p4<<p6;  


        long long a=-1,b=-1;
        char*na;
        cout<<endl<<endl<<endl<<"Avião que saiu: "<<endl;
        //string n;
        aviao oi;
        if(p6!=0){
            oi=fila[6][0];
            na=oi.getnome();
              
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=6;
            b=0; 
            f=1;
        }
        else{
            if (p0!=0)
                {
                    
                    oi=fila[0][0];
                    na=oi.getnome();
                    

                    //teste
                    for(i=0;i<5;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<" ";
                    for(i=5;i<8;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<"->";
                    for(i=8;i<11;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<endl;
                    cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                    if(oi.gettipo()==0){
                        cout<<"  C:"<<oi.getC();
                    }
                    else{
                        cout<<"  D:"<<oi.getD();
                    }
                    cout<<endl<<endl;
                    a=0;
                    b=0;     
                }
            else{
                if(p1!=0){
                    
                    oi=fila[1][0];
                    
                    na=oi.getnome();
                    
                    

                    //teste
                    for(i=0;i<5;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<" ";
                    for(i=5;i<8;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<"->";
                    for(i=8;i<11;i++){
                        cout<<(char)(na[i]);
                    }
                    cout<<endl;
                    cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                    if(oi.gettipo()==0){
                        cout<<"  C:"<<oi.getC();
                    }
                    else{
                        cout<<"  D:"<<oi.getD();
                    }
                    cout<<endl<<endl;
                    a=1;
                    b=0;    
                    h=1;
                }
                else{
                    if(p2!=0){
                    
                        oi=fila[2][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=2;
                        b=0;      
                    }
                    else{
                        if((m%3)!=3){
                            if(p3!=0){
                                
                                oi=fila[3][0];
                                na=oi.getnome();
                                

                                //teste
                                for(i=0;i<5;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<" ";
                                for(i=5;i<8;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<"->";
                                for(i=8;i<11;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<endl;
                                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                                if(oi.gettipo()==0){
                                    cout<<"  C:"<<oi.getC();
                                }
                                else{
                                    cout<<"  D:"<<oi.getD();
                                }
                                cout<<endl<<endl;
                                a=3;
                                b=0;      
                            }
                            else{
                                if(p4!=0){
                                    
                                    oi=fila[4][0];
                                    na=oi.getnome();
                                    

                                    //teste
                                    for(i=0;i<5;i++){
                                        cout<<(char)(na[i]);
                                    }
                                    cout<<" ";
                                    for(i=5;i<8;i++){
                                        cout<<(char)(na[i]);
                                    }
                                    cout<<"->";
                                    for(i=8;i<11;i++){
                                        cout<<(char)(na[i]);
                                    }
                                    cout<<endl;
                                    cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                                    if(oi.gettipo()==0){
                                        cout<<"  C:"<<oi.getC();
                                    }
                                    else{
                                        cout<<"  D:"<<oi.getD();
                                    }
                                    cout<<endl<<endl;
                                    a=4;
                                    b=0;      
                                }
                            }
                        }
                        else{
                            if(p4!=0){
                                
                                oi=fila[4][0];
                                na=oi.getnome();
                                

                                //teste
                                for(i=0;i<5;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<" ";
                                for(i=5;i<8;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<"->";
                                for(i=8;i<11;i++){
                                    cout<<(char)(na[i]);
                                }
                                cout<<endl;
                                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                                if(oi.gettipo()==0){
                                    cout<<"  C:"<<oi.getC();
                                }
                                else{
                                    cout<<"  D:"<<oi.getD();
                                }
                                cout<<endl<<endl;
                                a=4;
                                b=0;      
                            }
                        }
                    }
                }
            }
        }
        


        
        char* nome;
        
        cout<<"stcrit i:"<<p1;
        if((p1>=1) && (h==0 || p1>1) || (p6>1) && (f==1)){
            cout<<endl<<endl<<"Situacao Crítica!!!"<<endl<<endl;
            cout<<"Mandou para aeroporto vizinho:"<<endl;
            cout<<"stcrit i:"<<guarda_i[1][h]<<" "<<voo[guarda_i[1][h]].getprioridade();

            while((p1>=1)){
                voo[guarda_i[1][h]].setprioridade(5);
                cout<<"stcrit i:"<<guarda_i[1][h]<<" "<<voo[guarda_i[1][h]].getprioridade();
                
                oi=voo[guarda_i[1][h]];
                nome=oi.getnome();
                    

                //teste
                for(e=0;e<5;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<" ";
                for(e=5;e<8;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<"->";
                for(e=8;e<11;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<endl;
                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                if(oi.gettipo()==0){
                    cout<<"  C:"<<oi.getC();
                }
                else{
                    cout<<"  D:"<<oi.getD();
                }
                cout<<endl<<endl;
                h++;
                p1--;
            }
            while(p6>1){
                voo[guarda_i[6][f]].setprioridade(5);
                oi=voo[guarda_i[6][f]];
                nome=oi.getnome();
                    

                //teste
                for(e=0;e<5;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<" ";
                for(e=5;e<8;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<"->";
                for(e=8;e<11;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<endl;
                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                if(oi.gettipo()==0){
                    cout<<"  C:"<<oi.getC();
                }
                else{
                    cout<<"  D:"<<oi.getD();
                }
                cout<<endl<<endl;
                f++;
                p6--;
            }
        }
        
        




        long long g;
        long long imp;
        double np=0;
        mC=0;
        qtdemergencia=0;
        g = guarda_i[a][b];
        //cout<<"i: "<<g<<endl;
        if(voo[g].getprioridade()==0){
            qtdemergencia=1;
        }
        if(voo[g].gettipo()==0){
            mCG=mCG+voo[g].getC();
            nV++;
            TpE=TpE+m-voo[g].gett_chegado();
            npE++;
        }
        else{
            TdE=TdE+m-voo[g].gett_chegado();
            ndE++;
        }
        voo[g].setprioridade(5);
        
        cout<<endl<<endl<<endl<<"Avioes Esperando: "<<endl;
        
        for(imp=0;imp<K*m;imp++){
            if(voo[imp].getprioridade()!=5){
                cout<<endl;

                for(i=0;i<5;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<endl;
                cout<<"T:"<<voo[imp].gettipo()<<"  P:"<<voo[imp].getprioridade()<<"  t_chegado:"<<voo[imp].gett_chegado();
                if(voo[imp].gettipo()==0){
                    cout<<"  C:"<<voo[imp].getC();
                    mC=mC+voo[imp].getC();
                    np++;
                }
                else{
                    cout<<"  D:"<<voo[imp].getD();
                }
                cout<<endl;
            }
        }
        cout<<endl<<endl;
        if(npE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: "<<TpE/npE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: Indefinido"<<endl;
        }
        if(ndE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: "<<TdE/ndE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: Indefinido"<<endl;
        }
        if(np!=0){
            cout<<endl<<"Média de Combustivel dos avioes esperando: "<<mC/np<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes esperando: 0"<<endl;
        }
        if(nV!=0){
            cout<<endl<<"Média de Combustivel dos avioes que já pousaram: "<<mCG/nV<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes que pousaram: 0"<<endl;
        }

        cout<<endl<<"Quantidade de avioes de emergencia: "<<qtdemergencia<<endl<<endl<<endl;
        
        



        cout<<endl<<"*******************************************"<<endl;
        /*p0=0,p1=0,p2=0,p3=0,p4=0;

        for(i=0;i<K*m;i++){
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                p3++;
            }if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                p4++;
            }
            if(voo[i].getprioridade()==5){
                //medias
            }
        }        */


        //decide pista e situacoes de emergencia
        
        /*if (p0!=0)
        {
            cout<<endl<<"Avião que saiu: ";
            string n;
            aviao oi;
            oi=fila[0][0];
            na[a]=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;

            a++;
        }
        else{

        }*/
        

        //imprime
        
    }

    
}
 /*string getnome(); 

    voo[0].settipo(1);
    voo[0].setnome(n);
    n=voo[0].getnome();
    
    for(i=0;i<5;i++){
        cout<<(char)(n[i]);
    }
    cout<<" ";
    for(i=5;i<8;i++){
        cout<<(char)(n[i]);
    }
    cout<<"->";
    for(i=8;i<11;i++){
        cout<<(char)(n[i]);
    }










        void setnome();
        int getprioridade();
        void setprioridade(int prio);
        int gettipo();
        void settipo(int tip);
        long long getC();
        void setC(long long comb);
        long long getD();
        void setD(long long deco);
        long long gett_chegado();
        void sett_chegado(long long t_chegou);
        //void atualiza();
long long organizar(long long K, long long m, aviao* voo,long long T){
    long long i,p0=0,p1=0,p2=0,p3=0,p4=0;
    aviao fila[10][K*T+10];
    long long guarda_i[10][K*T+10];

        for(i=0;i<K*m;i++){
            //cout<<"a2";
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                guarda_i[voo[i].getprioridade()][p0]=i;
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                guarda_i[voo[i].getprioridade()][p1]=i;
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                guarda_i[voo[i].getprioridade()][p2]=i;
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                guarda_i[voo[i].getprioridade()][p3]=i;
                p3++;
            }if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                guarda_i[voo[i].getprioridade()][p4]=i;
                p4++;
            }
            if(voo[i].getprioridade()==5){
                //medias
            }
        }      


    long long a=-1,b=-1;
    char*na;
    cout<<endl<<endl<<endl<<"Avião que saiu: "<<endl;
    string n;
    aviao oi;
    if (p0!=0)
        {
            
            oi=fila[0][0];
            na=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=0;
            b=0;     
        }
    else{
        if(p1!=0){
            
            oi=fila[1][0];
            n=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=1;
            b=0;    
            p1--;
            p1--;  
        }
        else{
            if(p2!=0){
               
                oi=fila[2][0];
                na=oi.getnome();
                

                //teste
                for(i=0;i<5;i++){
                    cout<<(char)(na[i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(na[i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(na[i]);
                }
                cout<<endl;
                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                if(oi.gettipo()==0){
                    cout<<"  C:"<<oi.getC();
                }
                else{
                    cout<<"  D:"<<oi.getD();
                }
                cout<<endl<<endl;
                a=2;
                b=0;      
            }
            else{
                if((m%3)!=3){
                    if(p3!=0){
                        
                        oi=fila[3][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=3;
                        b=0;      
                    }
                    else{
                        if(p4!=0){
                            
                            oi=fila[4][0];
                            na=oi.getnome();
                            

                            //teste
                            for(i=0;i<5;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<" ";
                            for(i=5;i<8;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<"->";
                            for(i=8;i<11;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<endl;
                            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                            if(oi.gettipo()==0){
                                cout<<"  C:"<<oi.getC();
                            }
                            else{
                                cout<<"  D:"<<oi.getD();
                            }
                            cout<<endl<<endl;
                            a=4;
                            b=0;      
                        }
                    }
                }
                else{
                    if(p4!=0){
                        
                        oi=fila[4][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=4;
                        b=0;      
                    }
                }
            }
        }
    }

    if(p1!=0){
        cout<<endl<<endl<<"Situacao Crítica!!!"<<endl<<endl;
        cout<<"Mandou para aeroporto vizinho:"<<endl;
    }
    long long h=1;
    while(p1!=0){
        voo(guarda_i[1][h]).;
        h++;
        p1--;
        oi=fila[1][h];
        na=oi.getnome();
            

        //teste
        for(i=0;i<5;i++){
            cout<<(char)(na[i]);
        }
        cout<<" ";
        for(i=5;i<8;i++){
            cout<<(char)(na[i]);
        }
        cout<<"->";
        for(i=8;i<11;i++){
            cout<<(char)(na[i]);
        }
        cout<<endl;
        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
        if(oi.gettipo()==0){
            cout<<"  C:"<<oi.getC();
        }
        else{
            cout<<"  D:"<<oi.getD();
        }
        cout<<endl<<endl;
    }

    if(a!=-1){
        return guarda_i[a][b];
    }
    return -1;
        
}*/
 /*for(b=0;b<K*(m-1);b++){
            for(i=0;i<5;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<endl;
            cout<<"T:"<<voo[b].gettipo()<<"  P:"<<voo[b].getprioridade()<<"  t_chegado:"<<voo[b].gett_chegado();
            if(voo[b].gettipo()==0){
                cout<<"  C:"<<voo[b].getC();
            }
            else{
                cout<<"  D:"<<voo[b].getD();
            }
            cout<<endl;
        }*/
