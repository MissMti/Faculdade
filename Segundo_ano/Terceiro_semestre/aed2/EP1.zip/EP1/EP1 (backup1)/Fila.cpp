#include <iostream>
#include <iomanip>
#include <fstream>
#include <random>
#include "Fila.h"
#include "aviao.h"

using namespace std;



long long organizar(long long K, long long m, aviao* voo,long long T){
    long long i,p0=0,p1=0,p2=0,p3=0,p4=0;
    aviao fila[10][K*T+10];
    long long guarda_i[10][K*T+10];

        for(i=0;i<K*m;i++){
            //cout<<"a2";
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                guarda_i[voo[i].getprioridade()][p0]=i;
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                guarda_i[voo[i].getprioridade()][p1]=i;
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                guarda_i[voo[i].getprioridade()][p2]=i;
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                guarda_i[voo[i].getprioridade()][p3]=i;
                p3++;
            }if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                guarda_i[voo[i].getprioridade()][p4]=i;
                p4++;
            }
            if(voo[i].getprioridade()==5){
                //medias
            }
        }      


    long long a=-1,b=-1;
    char*na;
    cout<<endl<<endl<<"Avião que saiu: "<<endl<<endl;;
    string n;
    aviao oi;
    if (p0!=0)
        {
            
            oi=fila[0][0];
            na=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=0;
            b=0;      
        }
    else{
        if(p1!=0){
            
            oi=fila[1][0];
            n=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=1;
            b=0;      
        }
        else{
            if(p2!=0){
               
                oi=fila[2][0];
                na=oi.getnome();
                

                //teste
                for(i=0;i<5;i++){
                    cout<<(char)(na[i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(na[i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(na[i]);
                }
                cout<<endl;
                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                if(oi.gettipo()==0){
                    cout<<"  C:"<<oi.getC();
                }
                else{
                    cout<<"  D:"<<oi.getD();
                }
                cout<<endl<<endl;
                a=2;
                b=0;      
            }
            else{
                if((m%3)!=3){
                    if(p3!=0){
                        
                        oi=fila[3][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=3;
                        b=0;      
                    }
                    else{
                        if(p4!=0){
                            
                            oi=fila[4][0];
                            na=oi.getnome();
                            

                            //teste
                            for(i=0;i<5;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<" ";
                            for(i=5;i<8;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<"->";
                            for(i=8;i<11;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<endl;
                            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                            if(oi.gettipo()==0){
                                cout<<"  C:"<<oi.getC();
                            }
                            else{
                                cout<<"  D:"<<oi.getD();
                            }
                            cout<<endl<<endl;
                            a=4;
                            b=0;      
                        }
                    }
                }
                else{
                    if(p4!=0){
                        
                        oi=fila[4][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=4;
                        b=0;      
                    }
                }
            }
        }
    }




    if(a!=-1){
        return guarda_i[a][b];
    }
    return -1;
        
}

/*int filaPriorVazia (filaPrior *f) {
  return (f->n == 0);
}

void rebaixa (filaPrior * f, int i) {
  int maior, pai, filhoEsq, filhoDir;
  item aux;

  pai = i;
  filhoEsq = 2*i + 1;
  filhoDir = 2*i + 2;

  maior = i;
  if (filhoEsq < f->n && f->vet[filhoEsq].prior > f->vet[maior].prior)
    maior = filhoEsq;

  if (filhoDir < f->n && f->vet[filhoDir].prior > f->vet[maior].prior)
    maior = filhoDir;

  if (maior != pai){
    aux = f->vet[maior];
    f->vet[maior] = f->vet[pai];
    f->vet[pai] = aux;

    f->ind[f->vet[maior].elem] = maior;
    f->ind[f->vet[pai].elem] = pai;
    rebaixa(f, maior);
  }
}

void sobe (filaPrior * f, int i) {
  int pai, filho;
  item aux; 
  filho = i;
  pai = (i - 1)/2;

  if (filho >= 1 && f->vet[filho].prior > f->vet[pai].prior){
    aux = f->vet[pai];
    f->vet[pai] = f->vet[filho];
    f->vet[filho] = aux;

    f->ind[f->vet[pai].elem] = pai;
    f->ind[f->vet[filho].elem] = filho;
    sobe(f, pai);
  }
}





filaPrior * criaFilaPrior (int max, int tam) {
  int i;
  
  filaPrior *f = malloc (sizeof(filaPrior));
  f->vet = malloc (max * sizeof (item));
  f->ind = malloc (tam * sizeof (int));
  for (i = 0; i < tam; i++)
    f->ind[i] = -1; 
  f->n   = 0;
  f->max = max;
  f->tam = tam;
  return f; 
}

filaPrior * resizeFilaPrior (filaPrior * f) {
  item * novo = malloc (2 * f->max * sizeof(item)) ; 
  int i; 
  for (i = 0; i < f->n; i++){
    novo[i] = f->vet[i];
  }
  free (f->vet); 
  f->vet = novo;
  f-> max = 2 * f->max;
  return f; 
} 

void destroiFilaPrioridade (filaPrior * f) {
  free (f->vet);
  free (f->ind);
  free (f); 
} 


int removeFilaPrior (filaPrior * f) {
  int aux;
  if (!filaPriorVazia(f)){
    aux = f->vet[0].elem;
    f->ind[aux] = -1;   /* removi da fila de prioridade */ 
 
    /*f->vet[0] = f->vet[f->n - 1];
    f->ind[f->vet[0].elem] = 0;
    f->n = f->n - 1;
    rebaixa (f, 0);
    return aux;
  }
} 

void insereFilaPrior (filaPrior *f, item x) {
  if (f->n == f->max)
    resizeFilaPrior (f);
  f->vet[f->n] = x;
  f->ind[x.elem] = f->n;
  f->n = f->n + 1;
  /* corrige pra cima no indice f->n - 1 */
  /*sobe (f, f->n - 1);
}

void mudaPrior (filaPrior *f, int indice, int novaPrior){
  int auxPrior = f->vet[indice].prior;
  
  f->vet[indice].prior = novaPrior;
    if (auxPrior < novaPrior)
    sobe (f, indice);
  else
    rebaixa (f, indice);
} */



  




/*
int main() {
  item novo;
  int i, j, n;
  filaPrior * f;

  n = 15;
  f  = criaFilaPrior(1,n);
  
  for (i = 0; i < n; i++){
    novo.elem = i;
    novo.prior = 100-i;
    insereFilaPrior(f, novo);
   }
    printf("----------\n");

  
  mudaPrior(f,6,1000);
  
  mudaPrior(f,8,900);
  
  for (i = 0; i < n; i++){
    printf("%d \n",f->vet[i].elem);
  }

    printf("----------\n");
   for (i = 0; i < n; i++){
     j = removeFilaPrior(f);
     
     printf("removido: %d\n",j);
     for (j = 0; j < f->n; j++){
       printf("%d \n",f->vet[j].elem);
     }
     
     printf("*********** \n");
   }
}


*/

/*
long long decide_pista(long long p0, long long p1, long long p2, long long p3, long long p4, aviao** fila, long long** guarda_i, long long m ){
    long long a=-1,b=-1,i;
    char*na;
    if (p0!=0)
        {
            cout<<endl<<"Avião que saiu: ";
            string n;
            aviao oi;
            oi=fila[0][0];
            na=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=0;
            b=0;      
        }
    else{
        if(p1!=0){
            cout<<endl<<"Avião que saiu: ";
            char* n;
            aviao oi;
            oi=fila[1][0];
            n=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;
            a=1;
            b=0;      
        }
        else{
            if(p2!=0){
                cout<<endl<<"Avião que saiu: ";
                string n;
                aviao oi;
                oi=fila[2][0];
                na=oi.getnome();
                

                //teste
                for(i=0;i<5;i++){
                    cout<<(char)(na[i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(na[i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(na[i]);
                }
                cout<<endl;
                cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                if(oi.gettipo()==0){
                    cout<<"  C:"<<oi.getC();
                }
                else{
                    cout<<"  D:"<<oi.getD();
                }
                cout<<endl<<endl;
                a=2;
                b=0;      
            }
            else{
                if((m%3)+1!=3){
                    if(p3!=0){
                        cout<<endl<<"Avião que saiu: ";
                        string n;
                        aviao oi;
                        oi=fila[3][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=3;
                        b=0;      
                    }
                    else{
                        if(p4!=0){
                            cout<<endl<<"Avião que saiu: ";
                            string n;
                            aviao oi;
                            oi=fila[4][0];
                            na=oi.getnome();
                            

                            //teste
                            for(i=0;i<5;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<" ";
                            for(i=5;i<8;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<"->";
                            for(i=8;i<11;i++){
                                cout<<(char)(na[i]);
                            }
                            cout<<endl;
                            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                            if(oi.gettipo()==0){
                                cout<<"  C:"<<oi.getC();
                            }
                            else{
                                cout<<"  D:"<<oi.getD();
                            }
                            cout<<endl<<endl;
                            a=4;
                            b=0;      
                        }
                    }
                }
                else{
                    if(p4!=0){
                        cout<<endl<<"Avião que saiu: ";
                        string n;
                        aviao oi;
                        oi=fila[4][0];
                        na=oi.getnome();
                        

                        //teste
                        for(i=0;i<5;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<" ";
                        for(i=5;i<8;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<"->";
                        for(i=8;i<11;i++){
                            cout<<(char)(na[i]);
                        }
                        cout<<endl;
                        cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
                        if(oi.gettipo()==0){
                            cout<<"  C:"<<oi.getC();
                        }
                        else{
                            cout<<"  D:"<<oi.getD();
                        }
                        cout<<endl<<endl;
                        a=4;
                        b=0;      
                    }
                }
            }
        }
    }




    if(a!=-1){
        return guarda_i[a][b];
    }
    return -1;
}

*/