#include <iostream>
#include <iomanip>
#include <string.h>
#include <cstdlib>
#include <ctime>
#include "Fila.h"
#include "aviao.h"


using namespace std;

//nova biblioteca soh para o funcionamento do negocio + funcao de leitura apenas;

void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V);

int main(){
    long long T,K,pp,pd,pe,C,V;
    long long i,j;

    //leituras
    cout<<"*** CENTRAL DE COMANDO DO AEROPORTO ABC ***"<<endl<<endl;
    cout<<"Insira valor de T:";
    cin>>T;
    cout<<endl;
    cout<<"Insira valor de K:";
    cin>>K;
    cout<<endl;
    cout<<"Insira valor de Pp(em %):";
    cin>>pp;
    cout<<endl;
    pd=100-pp;
    cout<<"Insira valor de Pe(em %):";
    cin>>pe;
    cout<<endl;
    cout<<"Insira valor de C:";
    cin>>C;
    cout<<endl;
    cout<<"Insira valor de V:";
    cin>>V;
    cout<<endl;

    cout<<T<<endl<<K<<endl<<pp<<endl<<pd<<endl<<pe<<endl<<C<<endl<<V<<endl;
    

    programa(T,K,pp,pd,pe,C,V);
    return 0;
}

void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V){
    long long i,m,l,a=0,param,b;
    double mC,mCG=0,nV=0,npE=0,ndE=0,TpE=0,TdE=0;
    long long qtdemergencia=0;
    long long p0=0,p1=0,p2=0,p3=0,p4=0;
    char* na[K*T+10];

    long long seed=time(0);
    srand(seed);
    aviao voo[K*T+10];
    
    
    for(m=1;m<T+1;m++){
        //atualiza voos

        cout<<endl<<endl<< "NOVO ROUND"<<endl<<endl<<endl;
        cout<<"m:"<<m<<endl;
        for(i=0;i<K*(m-1);i++){
            voo[i].atualiza(m);
            
        }
        /*for(b=0;b<K*(m-1);b++){
            for(i=0;i<5;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[b][i]);
            }
            cout<<endl;
            cout<<"T:"<<voo[b].gettipo()<<"  P:"<<voo[b].getprioridade()<<"  t_chegado:"<<voo[b].gett_chegado();
            if(voo[b].gettipo()==0){
                cout<<"  C:"<<voo[b].getC();
            }
            else{
                cout<<"  D:"<<voo[b].getD();
            }
            cout<<endl;
        }*/






        //cria K voo
        cout<<endl<<"Novos avioes: "<<endl;
        for(l=0;l<K;l++){
            voo[a].settipo(1);
            if(rand()%100>pp){//decolagem
                voo[a].settipo(1);
                param=(rand()%V)+1;
                voo[a].setD((double)param);
                //cout<<"param"<<param;
                voo[a].setprioridade(4);
            }
            else{//pouso
                voo[a].settipo(0);
                param=rand()%C;
                voo[a].setC(param);
                if(param==0){
                    voo[a].setprioridade(1);
                }
                else{
                    voo[a].setprioridade(3);
                }
            }
            if(rand()%100<pe){//normal
                voo[a].setprioridade(0);
            }
            

            //cout<<"oi";
            string n;
            voo[a].sett_chegado(m);
            voo[a].setnome(a*seed);
            na[a]=voo[a].getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<endl;
            cout<<"T:"<<voo[a].gettipo()<<"  P:"<<voo[a].getprioridade()<<"  t_chegado:"<<voo[a].gett_chegado();
            if(voo[a].gettipo()==0){
                cout<<"  C:"<<voo[a].getC();
            }
            else{
                cout<<"  D:"<<voo[a].getD();
            }
            cout<<endl;

            a++;


        }
        //cout<<"a1";
        //organiza "fila"


        long long g;
        long long imp;
        double np=0;
        mC=0;
        qtdemergencia=0;
        g = organizar(K,m,voo,T);
        //cout<<"i: "<<g<<endl;
        if(voo[g].getprioridade()==0){
            qtdemergencia=1;
        }
        if(voo[g].gettipo()==0){
            mCG=mCG+voo[g].getC();
            nV++;
            TpE=TpE+m-voo[g].gett_chegado();
            npE++;
        }
        else{
            TdE=TdE+m-voo[g].gett_chegado();
            ndE++;
        }
        voo[g].setprioridade(5);
        
        cout<<endl<<"Avioes Esperando: "<<endl;
        
        for(imp=0;imp<K*m;imp++){
            if(voo[imp].getprioridade()!=5){
                cout<<endl;

                for(i=0;i<5;i++){
                    cout<<(char)(na[imp][i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(na[imp][i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(na[imp][i]);
                }
                cout<<endl;
                cout<<"T:"<<voo[imp].gettipo()<<"  P:"<<voo[imp].getprioridade()<<"  t_chegado:"<<voo[imp].gett_chegado();
                if(voo[imp].gettipo()==0){
                    cout<<"  C:"<<voo[imp].getC();
                    mC=mC+voo[imp].getC();
                    np++;
                }
                else{
                    cout<<"  D:"<<voo[imp].getD();
                }
                cout<<endl;
            }
        }
        if(npE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: "<<TpE/npE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: Indefinido"<<endl;
        }
        if(ndE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: "<<TdE/ndE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: Indefinido"<<endl;
        }
        if(np!=0){
            cout<<endl<<"Média de Combustivel dos avioes esperando: "<<mC/np<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes esperando: 0"<<endl;
        }
        if(nV!=0){
            cout<<endl<<"Média de Combustivel dos avioes que já pousaram: "<<mCG/nV<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes que pousaram: 0"<<endl;
        }

        cout<<endl<<"Quantidade de avioes de emergencia: "<<qtdemergencia<<endl<<endl;
        
        



        cout<<endl<<"*******************************************"<<endl;
        /*p0=0,p1=0,p2=0,p3=0,p4=0;

        for(i=0;i<K*m;i++){
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                p3++;
            }if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                p4++;
            }
            if(voo[i].getprioridade()==5){
                //medias
            }
        }        */


        //decide pista e situacoes de emergencia
        
        /*if (p0!=0)
        {
            cout<<endl<<"Avião que saiu: ";
            string n;
            aviao oi;
            oi=fila[0][0];
            na[a]=oi.getnome();
            

            //teste
            for(i=0;i<5;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[a][i]);
            }
            cout<<endl;
            cout<<"T:"<<oi.gettipo()<<"  P:"<<oi.getprioridade()<<"  t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  C:"<<oi.getC();
            }
            else{
                cout<<"  D:"<<oi.getD();
            }
            cout<<endl<<endl;

            a++;
        }
        else{

        }*/
        

        //imprime
        
    }

    
}
 /*string getnome(); 

    voo[0].settipo(1);
    voo[0].setnome(n);
    n=voo[0].getnome();
    
    for(i=0;i<5;i++){
        cout<<(char)(n[i]);
    }
    cout<<" ";
    for(i=5;i<8;i++){
        cout<<(char)(n[i]);
    }
    cout<<"->";
    for(i=8;i<11;i++){
        cout<<(char)(n[i]);
    }










        void setnome();
        int getprioridade();
        void setprioridade(int prio);
        int gettipo();
        void settipo(int tip);
        long long getC();
        void setC(long long comb);
        long long getD();
        void setD(long long deco);
        long long gett_chegado();
        void sett_chegado(long long t_chegou);
        //void atualiza();*/
