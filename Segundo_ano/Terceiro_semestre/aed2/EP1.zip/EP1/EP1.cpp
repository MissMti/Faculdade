#include <iostream>
#include <iomanip>
#include <string.h>
#include <cstdlib>
#include <ctime>
#include "aviao.h"


using namespace std;

void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V);

int main(){
    long long T,K,pp,pd,pe,C,V;
    long long i,j;

    //leituras dos valores dados pelo usuario
    cout<<endl<<"*** CENTRAL DE COMANDO DO AEROPORTO ABC ***"<<endl<<endl;
    cout<<"Insira valor de T: ";
    cin>>T;
    cout<<endl;
    cout<<"Insira valor de K: ";
    cin>>K;
    cout<<endl;
    cout<<"Insira valor de Pp(em %): ";
    cin>>pp;
    cout<<endl;
    pd=100-pp;
    cout<<"Insira valor de Pe(em %): ";
    cin>>pe;
    cout<<endl;
    cout<<"Insira valor de C: ";
    cin>>C;
    cout<<endl;
    cout<<"Insira valor de V: ";
    cin>>V;
    cout<<endl;

    cout<<endl<<"*******************"<<endl;
    
    

    programa(T,K,pp,pd,pe,C,V);
    return 0;
}



void programa(long long T,long long K,long long pp,long long pd,long long pe,long long C, long long V){
    long long i,m,l,a=0,param,b;
    double mC,mCG=0,nV=0,npE=0,ndE=0,TpE=0,TdE=0;
    long long controle;
    long long qtdemergencia=0;
    long long p0=0,p1=0,p2=0,p3=0,p4=0;
    char* name[K*T+10];
    aviao fila[10][K*T+10];
    long long guarda_i[10][K*T+10];
    long long seed=12542842;
    srand(seed);
    aviao voo[K*T+10];
    
    
    for(m=1;m<T+1;m++){
        //atualiza voos

        cout<<endl<<endl<< "NOVO ROUND"<<endl<<endl<<endl;
        for(i=0;i<K*(m-1);i++){
            voo[i].atualiza(m);
            
        }
       

        //cria K voo
        cout<<endl<<endl<<"Novos avioes: "<<endl<<endl;
        for(l=0;l<K;l++){
            voo[a].settipo(1);
            if(rand()%100>pp){//decolagem
                voo[a].settipo(1);
                param=(rand()%V)+1;
                voo[a].setD((double)param);
                
                voo[a].setprioridade(4);
            }
            else{//pouso
                voo[a].settipo(0);
                param=rand()%C;
                voo[a].setC(param);
                if(param==0){
                    voo[a].setprioridade(1);
                }
                else{
                    voo[a].setprioridade(3);
                }
            }
            if(rand()%100<pe){//emergencia
                if(voo[a].getprioridade()==1){
                    voo[a].setprioridade(6);
                }
                else{
                    voo[a].setprioridade(0);
                }
            }
            

            
            string n;
            voo[a].sett_chegado(m);
            voo[a].setnome(seed*a);
            name[a]=voo[a].getnome();
            

            //imprime voos criados
            for(i=0;i<5;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(name[a][i]);
            }
            cout<<endl;
            
            if(voo[a].gettipo()==0){
                cout<<"Pouso";
            }
            if(voo[a].gettipo()==1){
                cout<<"Decolagem";
            }
            if(voo[a].getprioridade()==0 || voo[a].getprioridade()==6){
                cout<<" de Emergencia!";
            }
            cout<<"   t_chegado:"<<voo[a].gett_chegado();
            if(voo[a].gettipo()==0){
                cout<<"  Combustivel:"<<voo[a].getC();
            }
            else{
                cout<<"  Tempo estimado de voo:"<<voo[a].getD();
            }
            cout<<endl;

            a++;


        }
        
        //organiza "fila"
        long long i,p0=0,p1=0,p2=0,p3=0,p4=0,p6=0;
        
        long long h=0,e, f=0;

        for(i=0;i<K*m;i++){
            if(voo[i].getprioridade()==0){
                fila[voo[i].getprioridade()][p0]=voo[i];
                guarda_i[voo[i].getprioridade()][p0]=i;
                p0++;
            }
            if(voo[i].getprioridade()==1){
                fila[voo[i].getprioridade()][p1]=voo[i];
                guarda_i[voo[i].getprioridade()][p1]=i;
                p1++;
            }
            if(voo[i].getprioridade()==2){
                fila[voo[i].getprioridade()][p2]=voo[i];
                guarda_i[voo[i].getprioridade()][p2]=i;
                p2++;
            }
            if(voo[i].getprioridade()==3){
                fila[voo[i].getprioridade()][p3]=voo[i];
                guarda_i[voo[i].getprioridade()][p3]=i;
                p3++;
            }
            if(voo[i].getprioridade()==4){
                fila[voo[i].getprioridade()][p4]=voo[i];
                guarda_i[voo[i].getprioridade()][p4]=i;
                p4++;
            }
            if(voo[i].getprioridade()==6){
                fila[voo[i].getprioridade()][p6]=voo[i];
                guarda_i[voo[i].getprioridade()][p6]=i;
                p6++;
            }
        }    
        


        long long a=-1,b=-1;
        char*na;

        //Decide qual aviao saira
        cout<<endl<<endl<<endl<<"Avião que saiu: "<<endl;
        cout<<"Pista "<<((m-1)%3)+1<<endl;
        
        aviao oi;



        if(p6!=0){
            oi=fila[6][0];
            na=oi.getnome();
            a=6;
            b=0; 
            f=1;
        }
        else{
            if (p0!=0)
                {
                    
                    oi=fila[0][0];
                    na=oi.getnome();
                    a=0;
                    b=0;     
                }
            else{
                if(p1!=0){
                    
                    oi=fila[1][0];
                    na=oi.getnome();
                    a=1;
                    b=0;    
                    h=1;
                }
                else{
                    if(p2!=0){
                    
                        oi=fila[2][0];
                        na=oi.getnome();
                    
                        a=2;
                        b=0;      
                    }
                    else{
                        if((m%3)!=0){
                            if(p3!=0){
                                
                                oi=fila[3][0];
                                na=oi.getnome();
                                a=3;
                                b=0;      
                            }
                            else{
                                if(p4!=0){
                                    
                                    oi=fila[4][0];
                                    na=oi.getnome();                                    
                                    a=4;
                                    b=0;      
                                }
                            }
                        }
                        else{
                            if(p4!=0){
                                
                                oi=fila[4][0];
                                na=oi.getnome();                
                                a=4;
                                b=0;      
                            }
                        }
                    }
                }
            }
        }
        if(a!=-1){
            for(i=0;i<5;i++){
                cout<<(char)(na[i]);
            }
            cout<<" ";
            for(i=5;i<8;i++){
                cout<<(char)(na[i]);
            }
            cout<<"->";
            for(i=8;i<11;i++){
                cout<<(char)(na[i]);
            }
            cout<<endl;
            if(oi.gettipo()==0){
                cout<<"Pouso";
            }
            if(oi.gettipo()==1){
                cout<<"Decolagem";
            }
            if(oi.getprioridade()==0 || oi.getprioridade()==6){
                cout<<" de Emergencia!";
            }
            cout<<"   t_chegado:"<<oi.gett_chegado();
            if(oi.gettipo()==0){
                cout<<"  Combustivel:"<<oi.getC();
            }
            else{
                cout<<"  Tempo estimado de voo:"<<oi.getD();
            }
            cout<<endl<<endl;
        }
        else{
            cout<<"Não houve saidas";
        }


        
        char* nome;
        long long p;
        p=h;
        
        //Investiga e imprime eventuais casos de emergencia
        if((p1>=1) && (h==0 || p1>1) || (p6>1) && (f==1)){
            cout<<endl<<endl<<"Situacao Crítica!!!"<<endl<<endl;
            cout<<"Mandou para aeroporto vizinho:"<<endl;
            
            
            while((p1>=1 && p==0) || (p1>1 && p==1)){
                voo[guarda_i[1][h]].setprioridade(5);
                                
                oi=voo[guarda_i[1][h]];
                nome=oi.getnome();
                    
                for(e=0;e<5;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<" ";
                for(e=5;e<8;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<"->";
                for(e=8;e<11;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<endl;
                
                cout<<"Pouso"<<"         t_chegado:"<<oi.gett_chegado();
                
                
                if(oi.gettipo()==0){
                    cout<<"  Combustivel:"<<oi.getC();
                }
                else{
                    cout<<"  Tempo estimado de voo:"<<oi.getD();
                }
                cout<<endl<<endl;
                h++;
                p1--;
            }
            while(p6>1){
                voo[guarda_i[6][f]].setprioridade(5);
                oi=voo[guarda_i[6][f]];
                nome=oi.getnome();
                    

                for(e=0;e<5;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<" ";
                for(e=5;e<8;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<"->";
                for(e=8;e<11;e++){
                    cout<<(char)(nome[e]);
                }
                cout<<endl;
                
                cout<<"Pouso de Emergencia!"<<"   t_chegado:"<<oi.gett_chegado();
                                
                if(oi.gettipo()==0){
                    cout<<"  Combustivel:"<<oi.getC();
                }
                else{
                    cout<<"  Tempo estimado de voo:"<<oi.getD();
                }
                cout<<endl<<endl;
                f++;
                p6--;
            }
        }
        
        




        long long g;
        long long imp;
        double np=0;
        mC=0;
        qtdemergencia=0;
        g = guarda_i[a][b];
        
        if(voo[g].getprioridade()==0){
            qtdemergencia=1;
        }
        if(voo[g].gettipo()==0){
            mCG=mCG+voo[g].getC();
            nV++;
            TpE=TpE+m-voo[g].gett_chegado();
            npE++;
        }
        else{
            TdE=TdE+m-voo[g].gett_chegado();
            ndE++;
        }
        voo[g].setprioridade(5);
        

        //Imprime avioes de pouso e emergencia que ainda estao esperando no aeroporto 

        if(K!=1){
            cout<<endl<<endl<<endl<<"Avioes Esperando: "<<endl<<endl;
        }
        
        
        for(imp=0;imp<K*m;imp++){
            if(voo[imp].getprioridade()!=5){

                for(i=0;i<5;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<" ";
                for(i=5;i<8;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<"->";
                for(i=8;i<11;i++){
                    cout<<(char)(name[imp][i]);
                }
                cout<<endl;
                
                if(voo[imp].gettipo()==0){
                    cout<<"Pouso";
                }
                if(voo[imp].gettipo()==1){
                    cout<<"Decolagem";
                }
                if(voo[imp].getprioridade()==0 || voo[imp].getprioridade()==6){
                    cout<<" de Emergencia!";
                }
                cout<<"   t_chegado:"<<voo[imp].gett_chegado();

                if(voo[imp].gettipo()==0){
                    cout<<"  Combustivel:"<<voo[imp].getC();
                    mC=mC+voo[imp].getC();
                    np++;
                }
                else{
                    cout<<"  Tempo estimado de voo:"<<voo[imp].getD();
                }
                cout<<endl;
            }
        }
        cout<<endl<<endl;


        //Impressao das saidas padroes de cada "rodada" t

        if(npE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: "<<TpE/npE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para pousar: Indefinido(Por falta de informacao)"<<endl;
        }
        if(ndE!=0){
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: "<<TdE/ndE<<endl;
        }
        else{
            cout<<endl<<"Tempo médio de espera dos avioes para decolar: Indefinido(Por falta de informacao)"<<endl;
        }
        if(np!=0){
            cout<<endl<<"Média de Combustivel dos avioes esperando: "<<mC/np<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes esperando: 0"<<endl;
        }
        if(nV!=0){
            cout<<endl<<"Média de Combustivel dos avioes que já pousaram: "<<mCG/nV<<endl;
        }
        else{
            cout<<endl<<"Média de Combustivel dos avioes que pousaram: 0"<<endl;
        }

        cout<<endl<<"Quantidade de avioes de emergencia: "<<qtdemergencia<<endl<<endl<<endl;
        
        



        cout<<endl<<"*******************************************"<<endl;
    }
}        