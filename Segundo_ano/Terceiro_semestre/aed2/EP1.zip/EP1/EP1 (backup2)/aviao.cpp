#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <string.h>
#include "aviao.h"

using namespace std;



char* aviao::getnome(){
    return nome;
}

void aviao::setnome(int seed){
    //char* n;

    srand(seed);
    this->nome[0]=rand()%26+65;
    this->nome[1]=rand()%26+65;
    this->nome[2]=rand()%10+48;
    this->nome[3]=rand()%10+48;
    this->nome[4]=rand()%10+48;
    if(this->tipo==0){//pouso
        this->nome[5]=rand()%26+65;
        this->nome[6]=rand()%26+65;
        this->nome[7]=rand()%26+65;
        this->nome[8]='A';
        this->nome[9]='B';
        this->nome[10]='C';
        if(this->nome[7]=='C'){
            this->nome[7]=nome[5];
        }
    }
    if(this->tipo==1){//decolagem
        this->nome[5]='A';
        this->nome[6]='B';
        this->nome[7]='C';
        this->nome[8]=rand()%26+65;
        this->nome[9]=rand()%26+65;
        this->nome[10]=rand()%26+65;
        if(this->nome[10]=='C'){
            this->nome[10]=nome[8];
        }
    }
    //cout<<"n:"<<this->nome[0]<<endl;
    //this->nome=n;
    //cout<<n[0];
    
}

int aviao::getprioridade(){
    return prioridade;
}

void aviao::setprioridade(int prio){
    this->prioridade=prio;
}

int aviao::gettipo(){
    return tipo;
}

void aviao::settipo(int tip){
    this->tipo=tip;
}

long long aviao::getC(){
    return c;
}

void aviao::setC(long long comb){
    this->c=comb;
}
        
double aviao::getD(){
    return d;
}

void aviao::setD(double deco){
    this->d=deco;
}

long long aviao::gett_chegado(){
    return t_chegado;
}

void aviao::sett_chegado(long long t_chegou){
    this->t_chegado=t_chegou;
}

void aviao::atualiza(long long tempo){
    double v;
    if(this->prioridade!=5){
        if(this->tipo==0){//pouso
            this->c--;
            if(this->c==0){
                this->prioridade=1;
            }
        }
        
        else{//decolagem
            v=this->d;
            if((double)(tempo - this->t_chegado) >= (double)(v*1.1)){
                this->prioridade=2;
                //cout<<"entrou"<<tempo<<" "<<this->t_chegado<<" "<<this->d<<" "<<v<<" "<<(v*1.1)<<" "<<(double)(tempo - this->t_chegado)<<endl;
            }
        }
    }
}