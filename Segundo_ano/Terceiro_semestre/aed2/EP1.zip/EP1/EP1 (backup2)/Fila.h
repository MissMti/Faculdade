#include <iostream>
#include <iomanip>
#include <fstream>
#include <random>
#include "aviao.h"

#pragma once

using namespace std;


class pista{
    private:
        
    public:
        
};
//funcao para impressoes que devolve o i do aviao que deve perder dua prioridade;

long long organizar(long long k, long long m, aviao* voo,long long T);
long long sitcrit(long long i);
long long decide_pista(long long p0, long long p1, long long p2, long long p3, long long p4, aviao** fila, long long** guarda_i, long long m  );



//typedef struct {
  //item *vet; /* armazena o heap */
  //int  *ind; /* armazena os índices dos elem no heap */ 
  //int n;     /* número de elem na fila (heap)     */
  //int max;   /* tamanho da fila             */
  //int tam;   /* número total de elementos (vetor ind) */
//} filaPrior; 

/*filaPrior * criaFilaPrior (int max, int tam);
int filaPriorVazia (filaPrior *f); 
int removeFilaPrior (filaPrior * f);
void insereFilaPrior (filaPrior *f, item x);


filaPrior * resizeFilaPrior (filaPrior * f); 



void destroiFilaPrior (filaPrior * f);

void mudaPrior (filaPrior *f, int indice, int novapr);*/

