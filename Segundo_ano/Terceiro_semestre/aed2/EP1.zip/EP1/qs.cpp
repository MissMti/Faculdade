#include <iostream>
#include <iomanip>

using namespace std;

//l rua reta
//n lanternas na rua
//lanterna i esta na posicao ai
//raio de d
//menor valor de d
//dado n,l, posicao das lanternas
//double d
//cuidado com o primeiro e ultimo caso.
//multiplicar por 10^9?
long long a[10000];
long long part(long long a[], long long l, long long u){
    long long v, i,j,tmp;
    v=a[l];
    i=l;
    j=u+1;
    do{
        do
            i++;
        while(a[i]<v && i<=u);
        do
        {
            j--;
        } while (v<a[j]);
        if(i<j){
            tmp=a[i];
            a[i]=a[j];
            a[j]=tmp;
        }
        
    }
    while(i<j);
    a[l]=a[j];
    a[j]=v;
    return j;
}
void qs(long long a[],long long l,long long u){
    long long j;
    if(l<u){
        j=part(a,l,u);
        qs(a,l,j-1);
        qs(a,j+1,u);
    }
}


int main(){
    long long n,i,l,tmp;
    double d=0.0;
    cin>>n>>l;
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    qs(a,0,n-1);
    //for(i=0;i<n;i++){
    //    cout<<a[i]<<" , ";
    //}
    tmp=a[0];
    if(tmp<l-a[n-1]){
        tmp=l-a[n-1];
    }
    tmp=tmp*2;
    for(i=1;i<n;i++){
        if(a[i]-a[i-1]>tmp){
            tmp=a[i]-a[i-1];
        }
    }

    d=((double)tmp/(double)2);
    cout<<fixed<<setprecision(9)<<d;
    return 0;
}