#include <iostream>
#include <iomanip>
#include <fstream>
#include <random>
#include <string.h>
#pragma once

using namespace std;

class aviao{
    private:
        char nome[15];
        int prioridade;
        int tipo;
        long long c;
        double d;
        long long t_chegado;

    public:
        char* getnome(); 
        void setnome(int seed);
        int getprioridade();//0: emergencia, 1:combustivel zerado, 2:+10%, 3:pousa, 4:decolagem, 5:ja aterrissou/pousou, 6:emergencia+comb=0
        void setprioridade(int prio);
        int gettipo();//tipo 0pouso 1decolagem
        void settipo(int tip);
        long long getC();//quantidade de combustivel
        void setC(long long comb);
        double getD();//tempo de voo
        void setD(double deco);
        long long gett_chegado();//o t em que o aviao fez contato
        void sett_chegado(long long t_chegou);
        void atualiza(long long tempo);
};