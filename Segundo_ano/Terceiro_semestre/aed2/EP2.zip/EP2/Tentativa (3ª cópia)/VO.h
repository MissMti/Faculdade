#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;



Item value(string key);
void add(string key,Item val);

void Consultas_VO(long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);
void principalVO(long long N);
void testeVO(char* arq);

void qs(long long l,long long u);
long long part(long long l, long long u);