#include <bits/stdc++.h>
#include "funcoes.h"
#include "VO.h"
#include "ABB.h"
#include "Treaps.h"
#include "A23.h"
#include "ARN.h"
#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

vector<pair<string,long long>> palavrasVO;
long long freq_maxVO=1;

string leitura(){
    string palavra="",p;
    long long tam,i;
    cin>>p;
    while(p=="\n" || p=="\0"){
        cin>>p;
    }
    tam=p.length();
    for(i=0;i<tam;i++){
        if((p[i]>='a' && p[i]<='z') || (p[i]>='A' && p[i]<='Z') || p[i]==39 || p[i]==45 || (p[i]>='0' && p[i]<='9')){
            palavra=palavra+p[i];
        }
    }
    return palavra;
}

bool nRep(string p){
    int alfabeto[50];
    long long i,l;

    for(i=0;i<35;i++){
        alfabeto[i]=0;
    }
    for(i=0;i<p.length();i++){
        if(p[i]=='-' ||p[i]==39){
            l=30;
        }
        else{
            if(p[i]>='A' && p[i]<='Z'){
                l=p[i]-65;
            }
            else{
                if(p[i]>='a' && p[i]<='z'){
                    l=p[i]-97;
                }
                else{
                    l=p[i]-'0'+35;
                }
            }
        }



        if(alfabeto[l]==1 && l!=30){
            return false;
        }
        else{
            alfabeto[l]=1;
        }
    }
    return true;
}

long long qtd_vogal(string p){
    long long qtd,j,a=0,e=0,i=0,o=0,u=0;
    for(j=0;j<p.length();j++){
        if((p[j]=='a'||p[j]=='A')&& a==0){
            a=1;
        }
        if((p[j]=='e'||p[j]=='E')&& e==0){
            e=1;
        }
        if((p[j]=='i'||p[j]=='I')&& i==0){
            i=1;
        }
        if((p[j]=='o'||p[j]=='O')&& o==0){
            o=1;
        }
        if((p[j]=='u'||p[j]=='U')&& u==0){
            u=1;
        }
    }
    qtd=a+e+i+o+u;
    return qtd;
}