#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include <random>
#include "Treaps.h"
#include "funcoes.h"
using namespace std;

long long freq_maxTreaps=1;
random_device rd;
uniform_int_distribution<int> distr(1,10000);

Treaps::Treaps(){
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
}

void Treaps::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz);
    return;
}

Treaps* Treaps::put(string chave, Item val, Treaps* raiz){
    if(raiz==nullptr){//primeiro elemento
        raiz=new Treaps;
        raiz->key=chave;
        raiz->values=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;   
        raiz->prioridade=distr(rd);    
        return raiz;
    }
    if(raiz->key==chave){//elemento já existente
        raiz->values.freq++;
        if(raiz->values.freq>freq_maxTreaps){
            freq_maxTreaps=raiz->values.freq;
        }
        return raiz;
    }
    if(raiz->key<chave){//para direita
        raiz->dir=put(chave,val,raiz->dir);
        if(raiz->dir->prioridade>raiz->prioridade){
            raiz=rotacionadir(raiz);
        }
        return raiz;
    }
    raiz->esq=put(chave,val,raiz->esq);//para esquerda
    if(raiz->esq->prioridade>raiz->prioridade){
        raiz=rotacionaesq(raiz);
    }
    return raiz;
}


Item Treaps::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item Treaps::get(string chave, Treaps* raiz){
    if(raiz==nullptr){
        Item nada;
        nada.freq=0;
        return nada;
    }
    if(raiz->key==chave){
        return raiz->values;
    }
    if(raiz->key<chave){
        return get(chave,raiz->dir);
    }
    return get(chave,raiz->esq);
}

void Consultas_Treaps (Treaps arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    Treaps* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxTreaps(arv.getraiz());
        }
        if(tmp=="VD"){
            arv.vmaxTreaps(arv.getraiz(),vog_max,tam_min);        
        }
        if(tmp=="SR"){
            arv.nrmaxTreaps(arv.getraiz(),nrtam_max);
        }
        if(tmp=="L"){
            arv.tmaxTreaps(arv.getraiz(),tam_max);
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalTreaps(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Treaps arv;
    Item stats;
    for(i=0;i<N;i++){//leitura do texto
        texto=leitura();
        
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        arv.add(texto,stats);
        cout<<"saida "<<i<<endl;
        arv.printa(arv.getraiz());
        cout<<endl<<endl;
    }

    Consultas_Treaps (arv,tam_max,vog_max,nrtam_max,tam_min);
}

Treaps* Treaps::getraiz(){
    return raiz;
}

Treaps* Treaps::getmenor(Treaps* atual){
    if (atual->esq != nullptr) {
      return getmenor(atual->esq);
    }
    return atual;
}

Treaps* Treaps::getmaior(Treaps* atual){
    if (atual->dir != nullptr) {
      return getmaior(atual->dir);
    }
    return atual;
}

string Treaps::getkey(){
    return key;
}

void Treaps::printa(Treaps* raiz){
  queue<Treaps*> q;
  Treaps* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout << n->key<<n->values.freq <<"P:"<<n->prioridade<<" ";
      q.push(n->esq);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    cout<<endl;
  }
}

Treaps*  Treaps::rotacionaesq (Treaps* raiz){
    Treaps* k;
    k=new Treaps;
    k = raiz->esq;
    raiz->esq = k->dir;
    k->dir = raiz;
    raiz = k;
    return raiz;
}

Treaps*  Treaps::rotacionadir (Treaps* raiz){
    Treaps* k;
    k=new Treaps;
    k = raiz->dir;
    raiz->dir = k->esq;
    k->esq = raiz;
    raiz = k;
    return raiz;
}

void Treaps::fmaxTreaps(Treaps *raiz){
    if (raiz != NULL) {
      fmaxTreaps(raiz->esq);
      if(raiz->values.freq==freq_maxTreaps){
        cout<< raiz->key<<endl;
      }
      fmaxTreaps(raiz->dir);
    }
}

void Treaps::nrmaxTreaps(Treaps *raiz, long long nrtam_maxTreaps){
    if (raiz != NULL) {
      nrmaxTreaps(raiz->esq,nrtam_maxTreaps);
      if(raiz->key.length()==nrtam_maxTreaps && raiz->values.nR){
        cout<< raiz->key<<endl;
      }
      nrmaxTreaps(raiz->dir,nrtam_maxTreaps);
    }
}
void Treaps::vmaxTreaps(Treaps *raiz, long long vog_maxTreaps, long long tam_minTreaps){
    if (raiz != NULL) {
      vmaxTreaps(raiz->esq,vog_maxTreaps,tam_minTreaps);
      if(raiz->values.vogais==vog_maxTreaps && raiz->key.length()==tam_minTreaps){
        cout<< raiz->key<<endl;
      }
      vmaxTreaps(raiz->dir,vog_maxTreaps,tam_minTreaps);
    }
}
void Treaps::tmaxTreaps(Treaps *raiz,long long tam_maxTreaps){
    if (raiz != NULL) {
      tmaxTreaps(raiz->esq,tam_maxTreaps);
      if(raiz->key.length()==tam_maxTreaps){
        cout<< raiz->key<<endl;
      }
      tmaxTreaps(raiz->dir,tam_maxTreaps);
    }
}

void testeTR(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Treaps palavras;
    Item stats;
    char p[1000];
    char* tmp;

    clock_t t;
    cout<<"comeco da leitura"<<endl;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:");
        texto=texto+tmp;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        palavras.add(texto,stats);
    }
    t=clock()-t;

    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    Item teste;
    cout<<"comeco dos teste"<<endl;

    Treaps* meio;
    Treaps* fim;
    Treaps* primeira;
    primeira=new Treaps;
    primeira=palavras.getmenor(palavras.getraiz());
    cout<<"primeira: "<<primeira->getkey()<<endl;

    meio= new Treaps;
    meio=palavras.getraiz();
    cout<<"meio: "<<meio->getkey()<<endl;

    fim= new Treaps;
    fim=palavras.getmaior(palavras.getraiz());
    cout<<primeira->getkey()<<" "<<meio->getkey()<<" "<<fim->getkey()<<endl;

    t=clock();
    //cout<<"1"<<endl;
    teste=palavras.value(primeira->getkey());
    //cout<<"2"<<endl;
    teste=palavras.value(meio->getkey());
    //cout<<"3"<<endl;
    teste=palavras.value(fim->getkey());
    //cout<<"4"<<endl;
    t=clock()-t;

    cout<<"Tempo para encontrar value na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    float media;
    media=((float)t/CLOCKS_PER_SEC)/3.0;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
}