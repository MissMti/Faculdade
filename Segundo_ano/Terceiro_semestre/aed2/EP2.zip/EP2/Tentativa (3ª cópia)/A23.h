#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;


class A23 {
private:
    string keyA;
    string keyB;
    Item valuesA;
    Item valuesB;
    A23* raiz;
    A23* esq;
    A23* mei;
    A23* dir;
    bool SaoDois;//true: o nó tem dois elementos

public:
    A23();//construtora

    void add(string chave, Item val);
    A23* put(string chave, Item val, A23* ini, bool* promoveu);

    Item value(string chave);
    Item get(string chave, A23* raiz);
  
    A23* getraiz();
    A23* getmenor(A23* atual);
    A23* getmaior(A23* atual);
    string getkeyA();
    bool getSaoDois(A23* raiz);
    bool ehFolha(A23* raiz);
    
    void fmaxA23(A23 *raiz);//imprime palavras com maior frequencia no texto
    void nrmaxA23(A23 *raiz, long long nrtam_maxA23);//imprime palavras com maior tamanho sem repeticao de caracteres do texto
    void vmaxA23(A23 *raiz, long long vog_maxA23, long long tam_minA23);//imprime palavras com a maior quantidade de vogais diferentes e o menor tamanho do texto
    void tmaxA23(A23 *raiz,long long tam_maxA23);//imprime palavras de maior tamanho do texto
    
    void printa(A23* arv);
};

void Consultas_A23(A23 palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);
void principalA23(long long N);
void testeA23(char* arq);