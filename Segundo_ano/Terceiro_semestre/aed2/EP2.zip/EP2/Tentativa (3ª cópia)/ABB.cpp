#include <bits/stdc++.h>
#include "ABB.h"
#include "funcoes.h"
using namespace std;

long long freq_maxABB=1;


ABB::ABB(){
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
}


void ABB::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz);
    return;
}

ABB* ABB::put(string chave, Item val, ABB* raiz){
    if(raiz==nullptr){//primeiro elemento
        raiz=new ABB;
        raiz->key=chave;
        raiz->values=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;        
        return raiz;
    }
    if(raiz->key==chave){//elemento já existente
        raiz->values.freq++;
        if(raiz->values.freq>freq_maxABB){
            freq_maxABB=raiz->values.freq;
        }
        return raiz;
    }
    if(raiz->key<chave){//para direita
        raiz->dir=put(chave,val,raiz->dir);
        return raiz;
    }
    raiz->esq=put(chave,val,raiz->esq);//para esquerda
    return raiz;
}


Item ABB::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}

Item ABB::get(string chave, ABB* raiz){
    if(raiz==nullptr){
        Item nada;
        nada.freq=0;
        return nada;
    }
    if(raiz->getkey()==chave){
        return raiz->values;
    }
    if(raiz->getkey()<chave){
        return get(chave,raiz->dir);
    }
    return get(chave,raiz->esq);
}


void Consultas_ABB (ABB arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    ABB* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxABB(arv.getraiz());
            cout<<endl;
        }
        if(tmp=="VD"){
            arv.vmaxABB(arv.getraiz(),vog_max,tam_min);    
            cout<<endl;    
        }
        if(tmp=="SR"){
            arv.nrmaxABB(arv.getraiz(),nrtam_max);
            cout<<endl;
        }
        if(tmp=="L"){
            arv.tmaxABB(arv.getraiz(),tam_max);
            cout<<endl;
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalABB(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    ABB arv;
    Item stats;
    for(i=0;i<N;i++){//leitura do texto
        texto=leitura();
        
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        arv.add(texto,stats);//adiciona a palavra a estrutura
    }

    arv.printa(arv.getraiz());
    cout<<endl;

    Consultas_ABB (arv,tam_max,vog_max,nrtam_max,tam_min);//realiza as consultas
}


ABB* ABB::getesq(){
    return esq;
}

ABB* ABB::getdir(){
    return dir;
}

long long ABB::getfreq(){
    return values.freq;
}
void ABB::printa(ABB* raiz){
  queue<ABB*> q;
  ABB* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout << n->getkey()<<n->getfreq() << " ";
      q.push(n->getesq());
      q.push(n->getdir());
    }
    else {
      cout << "- ";
    }
    cout<<endl;
  }
}



ABB* ABB::getraiz(){
    return raiz;
}

ABB* ABB::getmenor(ABB *atual){
    if (atual->esq != nullptr) {
      return getmenor(atual->esq);
    }
    return atual;
}

ABB* ABB::getmaior(ABB *atual){
    if (atual->dir != nullptr) {
      return getmaior(atual->dir);
    }
    return atual;
}

string ABB::getkey(){
    return key;
}


void ABB::fmaxABB(ABB *raiz){
    if (raiz != NULL) {
      fmaxABB(raiz->esq);
      if(raiz->values.freq==freq_maxABB){
        cout<< raiz->key<<" ";
      }
      fmaxABB(raiz->dir);
    }
}

void ABB::nrmaxABB(ABB *raiz, long long nrtam_maxABB){
    if (raiz != NULL) {
      nrmaxABB(raiz->esq,nrtam_maxABB);
      if(raiz->key.length()==nrtam_maxABB && raiz->values.nR){
        cout<< raiz->key<<" ";
      }
      nrmaxABB(raiz->dir,nrtam_maxABB);
    }
}
void ABB::vmaxABB(ABB *raiz, long long vog_maxABB, long long tam_minABB){
    if (raiz != NULL) {
      vmaxABB(raiz->esq,vog_maxABB,tam_minABB);
      if(raiz->values.vogais==vog_maxABB && raiz->key.length()==tam_minABB){
        cout<< raiz->key<<" ";
      }
      vmaxABB(raiz->dir,vog_maxABB,tam_minABB);
    }
}
void ABB::tmaxABB(ABB *raiz,long long tam_maxABB){
    if (raiz != NULL) {
      tmaxABB(raiz->esq,tam_maxABB);
      if(raiz->key.length()==tam_maxABB){
        cout<< raiz->key<<" ";
      }
      tmaxABB(raiz->dir,tam_maxABB);
    }
}

void testeABB(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    ABB palavras;
    Item stats;
    char p[1000];
    char* tmp;

    clock_t t;
    cout<<"comeco da leitura"<<endl;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:");
        texto=texto+tmp;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        palavras.add(texto,stats);
    }
    t=clock()-t;
    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    Item teste;
    cout<<"comeco dos teste"<<endl;

    ABB* meio;
    ABB* fim;
    ABB* primeira;
    primeira=new ABB;
    primeira=palavras.getmenor(palavras.getraiz());
    cout<<"primeira: "<<primeira->getkey()<<endl;

    meio= new ABB;
    meio=palavras.getraiz();
    cout<<"meio: "<<meio->getkey()<<endl;

    fim= new ABB;
    fim=palavras.getmaior(palavras.getraiz());
    cout<<primeira->getkey()<<" "<<meio->getkey()<<" "<<fim->getkey()<<endl;

    t=clock();
    //cout<<"1"<<endl;
    teste=palavras.value(primeira->getkey());
    //cout<<"2"<<endl;
    teste=palavras.value(meio->getkey());
    //cout<<"3"<<endl;
    teste=palavras.value(fim->getkey());
    //cout<<"4"<<endl;
    t=clock()-t;

    cout<<"Tempo para encontrar value na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    float media;
    media=((float)t/CLOCKS_PER_SEC)/3.0;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
}