#include <bits/stdc++.h>
#include "VO.h"
#include "funcoes.h"
//#include "item.h"
using namespace std;

//long long freq_max=1,palavras.size()=0;

//vector<pair<string,Item>> palavras;

vector<pair<string,long long>> palavras;
long long freq_max=1;

void Consultas_VO (long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    Item valor;
    cin>>Q;
    cout<<tam_max<<" " <<vog_max<<" " <<nrtam_max<<" " <<tam_min<<endl;
    for(j=0;j<Q;j++){
        string tmp;
        long long i;
        cin>>tmp;
        if(tmp=="F"){
            for(i=0;i<palavras.size();i++){
                valor=value(palavras[i].first);
                if(valor.freq==freq_max){
                    cout<<palavras[i].first<<" ";
                }
            }
        }
        if(tmp=="VD"){
            for(i=0;i<palavras.size();i++){
                valor=value(palavras[i].first);
                if(valor.vogais==vog_max && palavras[i].first.length()==tam_min){
                    cout<<palavras[i].first<<valor.vogais<<" ";
                }
            }
        }
        if(tmp=="SR"){
            for(i=0;i<palavras.size();i++){
                valor=value(palavras[i].first);
                if(valor.nR && palavras[i].first.length()==nrtam_max){
                    cout<<palavras[i].first<<" ";
                }
            }            
        }
        if(tmp=="L"){
            for(i=0;i<palavras.size();i++){
                if(palavras[i].first.length()==tam_max){
                    cout<<palavras[i].first<<" ";
                }
            }
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}

Item value(string key){
    Item val;
    if(palavras.size()==0){
        //cout<<"tamzero"<<endl;
        Item nada;
        nada.freq=0;
        nada.vogais=0;
        nada.tam=0;
        nada.nR=true;
        return nada;
    }
    long long inicio,meio,fim;
    inicio=0;
    fim=palavras.size()-1;
    meio=(inicio+fim)/2;
    while(key!=palavras[meio].first && inicio<fim){
        if(key>palavras[meio].first){
            if(inicio==meio){
                Item nada;
                nada.freq=0;
                nada.vogais=0;
                nada.tam=0;
                nada.nR=true;
                return nada;
            }
            inicio=meio;
            meio=(meio+fim+1)/2;
        }
        else{
            if(fim==meio){
                Item nada;
                nada.freq=0;
                nada.vogais=0;
                nada.tam=0;
                nada.nR=true;
                return nada;
            }
            fim=meio;
            meio=(meio+inicio)/2;
        }
        //cout<<inicio<<" "<<meio<<" "<<fim<<endl;
    }
    if(!(inicio<fim)){
        //cout<<"novo"<<endl;
        Item nada;
        nada.freq=0;
        nada.vogais=0;
        nada.tam=0;
        nada.nR=true;
        return nada;
    }
    val.freq=palavras[meio].second;
    val.nR=nRep(palavras[meio].first);
    val.tam=palavras[meio].first.length();
    val.vogais=qtd_vogal(palavras[meio].first);
    return val;
}

long long part(long long l, long long u){
    long long i,j;
    vector<pair<string,long long>> tmp;
    vector<pair<string,long long>> v;
    tmp.push_back(make_pair("",0));
    v.push_back(make_pair(palavras[l].first,palavras[l].second));
    i=l;
    j=u+1;
    do{
        do
            i++;
        while(palavras[i].first<v[0].first && i<=u);
        do
        {
            j--;
        } while (v[0].first<palavras[j].first);
        if(i<j){
            tmp[0]=palavras[i];
            palavras[i]=palavras[j];
            palavras[j]=tmp[0];
        }
        
    }
    while(i<j);
    palavras[l]=palavras[j];
    palavras[j]=v[0];
    return j;
}
void qs(long long l,long long u){
    long long j;
    if(l<u){
        j=part(l,u);
        qs(l,j-1);
        qs(j+1,u);
    }
}

void add(string key,Item val){
    //cout<<"entra"<<endl;
    Item tmp;
    tmp=value(key);
    //cout<<"palavas: "<<key<<endl;
    if(tmp.freq==0){
        //cout<<"passou3.0"<<endl;
        palavras.push_back(make_pair(key,val.freq));
        //cout<<"tam: "<<palavras.size()<<endl;
        sort(palavras.begin(),palavras.end());
        //qs(0,palavras.size()-1);
    }
    else{
        //cout<<"passou2.0"<<endl;
        long long inicio,meio,fim;
        inicio=0;
        fim=palavras.size();
        meio=(inicio+fim)/2;
        while(key!=palavras[meio].first){
            if(key>palavras[meio].first){
                inicio=meio;
                meio=(meio+fim+1)/2;
            }
            else{
                fim=meio;
                meio=(meio+inicio)/2;
            }
        }
        palavras[meio].second++;
        if( palavras[meio].second>freq_max){
            freq_max=palavras[meio].second;
        }
    }
    //cout<<"passou1.0"<<endl;
}

void principalVO(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Item stats;
    for(i=0;i<N;i++){//leitura do texto
        texto=leitura();
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }

        add(texto,stats);
    }

    

    Consultas_VO (tam_max,vog_max,nrtam_max,tam_min);//funcao que realiza as consultas
}



void testeVO(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i,size;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Item stats;
    char p[1000];
    char* tmp;

    clock_t t;
    cout<<"comeco da leitura"<<endl;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:");
        texto=texto+tmp;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        //cout<<"passou1"<<endl;
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        //cout<<"passou2"<<endl;
        add(texto,stats);
    }

    /*
    AA
    AAA
    AAAA
    AAAAAA
    AAAL*/
    

    t=clock()-t;
    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    Item teste;
    cout<<"comeco dos teste"<<endl;

    string aux,primeira,meio,fim;
    primeira=palavras[0].first;
    cout<<"primeira: "<<primeira<<endl;

    cout<<"erro"<<endl;
    aux=palavras[0].first;
    cout<<"retrona nulo1"<<endl;
    
    aux=palavras[1].first;
    cout<<"segunda: "<<aux<<endl;

    meio=palavras[palavras.size()/2].first;
    cout<<"meio: "<<meio<<endl;

    cout<<"acaba"<<endl;
    fim=palavras[palavras.size()-1].first;
    cout<<primeira<<" "<<meio<<" "<<fim<<endl;

    t=clock();
    //cout<<"1"<<endl;
    teste=value(primeira);
    //cout<<"2"<<endl;
    teste=value(meio);
    //cout<<"3"<<endl;
    teste=value(fim);
    //cout<<"4"<<endl;
    t=clock()-t;

    cout<<"Tempo para encontrar value na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    float media;
    media=((float)t/CLOCKS_PER_SEC)/3.0;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
}