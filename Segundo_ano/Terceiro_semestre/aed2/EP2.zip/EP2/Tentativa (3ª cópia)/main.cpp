#include <bits/stdc++.h>
#include "funcoes.h"
#include "VO.h"
#include "ABB.h"
#include "Treaps.h"
#include "A23.h"
#include "ARN.h"
using namespace std;

int main(){
    string E;
    char arq[1000];
    long long N;
    cin>>E;

    if(E=="VO"){
        cin>>N;
        principalVO(N);
    }
    if(E=="ABB"){
        cin>>N;
        principalABB(N);
    }
    if(E=="TR"){
        cin>>N;
        principalTreaps(N);
    }
    if(E=="A23"){
        cin>>N;
        principalA23(N);
    }
    if(E=="ARN"){
        cin>>N;
        principalARN(N);
    }
    
    
    if(E=="teste"){
        cout<<"a"<<endl;
        cin>>arq>>E;
        if(E=="VO"){
            cout<<"b"<<endl;
            testeVO(arq);
        }
        if(E=="ABB"){
            testeABB(arq);
        }
        if(E=="TR"){
            testeTR(arq);
        }
        if(E=="A23"){
            testeA23(arq);
        }
        if(E=="ARN"){
            testeARN(arq);
        }
    }
    
    

    return 0;
}