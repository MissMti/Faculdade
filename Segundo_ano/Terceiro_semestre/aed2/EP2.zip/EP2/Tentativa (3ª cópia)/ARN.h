#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;


class ARN {
private:
    string key;
    Item values;
    ARN* raiz;
    ARN* esq;
    ARN* dir;
    bool cor;//false=preto true=vermelho
public:
    ARN();//construtora

    void add(string chave, Item val);
    ARN* put(string chave, Item val, ARN* ini);

    Item value(string chave);
    Item get(string chave, ARN* raiz);
 
    bool getcor(ARN* folha);

    ARN*  rotacionadir (ARN* raiz);
    ARN*  rotacionaesq (ARN* raiz);
    ARN* mudaCor (ARN* raiz);
    ARN* getraiz();
    ARN* getmenor(ARN* atual);
    ARN* getmaior(ARN* atual);
    string getkey();
    
    void fmaxARN(ARN *raiz);//imprime palavras com maior frequencia no texto
    void nrmaxARN(ARN *raiz, long long nrtam_maxARN);//imprime palavras com maior tamanho sem repeticao de caracteres do texto
    void vmaxARN(ARN *raiz, long long vog_maxARN, long long tam_minARN);//imprime palavras com a maior quantidade de vogais diferentes e o menor tamanho do texto
    void tmaxARN(ARN *raiz,long long tam_maxARN);//imprime palavras de maior tamanho do texto
    
    void printa(ARN* arv);
};

void Consultas_ARN(ARN palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);

void principalARN(long long N);

void testeARN(char* arq);