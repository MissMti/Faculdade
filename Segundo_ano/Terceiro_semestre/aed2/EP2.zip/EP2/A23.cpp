#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include "A23.h"
#include "funcoes.h"
using namespace std;

long long freq_maxA23=1,promove=0;

A23::A23(){
    keyA="\0";
    keyB="\0";
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
    SaoDois=false;
}

void A23::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz,getSaoDois(this->raiz));
    return;
}

bool A23::getSaoDois(A23* raiz){
    if(raiz==nullptr){
        return false;
    }
    return raiz->SaoDois;
}

bool A23::ehFolha(A23* raiz){
    if(raiz->dir==nullptr && raiz->esq == nullptr){
        return true;
    }
    return false;
}

A23* A23::put(string chave, Item val, A23* raiz, bool SaoDois){
    if(raiz==nullptr){//primeiro elemento
        raiz=new A23;
        raiz->keyA=chave;
        raiz->valuesA=val;
        raiz->esq=nullptr;
        raiz->mei=nullptr; 
        raiz->dir=nullptr; 
        raiz->SaoDois=false;
        return raiz;
    }
    if(raiz->keyA==chave){//elemento já existente
        raiz->valuesA.freq++;
        if(raiz->valuesA.freq>freq_maxA23){
            freq_maxA23=raiz->valuesA.freq;
        }
        return raiz;
    }
    if(!raiz->SaoDois){//apenas um elemento
        //se nao for folha continuar
        if(!ehFolha(raiz)){
            if(raiz->keyA<chave){//para direita
                raiz->dir=put(chave,val,raiz->dir,getSaoDois(this->raiz));
                //return raiz;
            }
            raiz->esq=put(chave,val,raiz->esq,getSaoDois(this->raiz));//para esquerda
            //return raiz;
        }
        //checa se eh folha, se for folha eh soh adciionar
        else{
            raiz->keyB=chave;
            raiz->valuesB=val; 
            raiz->SaoDois=true;
            return raiz;
        }
        
    }
    else{//dois elementos
        //se nao for folha eh soh continuar
        if(!ehFolha(raiz)){
            if(raiz->keyB==chave){//elemento já existente
                raiz->valuesB.freq++;
                if(raiz->valuesB.freq>freq_maxA23){
                    freq_maxA23=raiz->valuesB.freq;
                }
                return raiz;
            }
            if(raiz->keyB<chave){
                raiz->dir=put(chave,val,raiz->dir,getSaoDois(this->raiz));
                //return raiz;
            }
            raiz->mei=put(chave,val,raiz->mei,getSaoDois(this->raiz));
            //return raiz;
        }
        
        //se for folha tera que haver promocao, para isso outra funcao que ira promover a celula do meio para cima ate que a celula do meio encontre uma celula com apenas um ou vazia(eh raiz)
        else{
            A23* promovido=new A23;
            promovido=promocao(chave,val,raiz);
            promove=1;
            return promovido;
        }
    }
    if(promove==1){
        if()
    }
    return raiz;
    
}

A23* A23::promocao(string chave, Item val, A23* raiz){
    A23* novo;
    novo=new A23; 
    if(raiz->keyA>chave){//promove keyA
        novo->esq=new A23;
        novo->dir=new A23;
        novo->esq->keyA=chave;
        novo->esq->valuesA=val;
        novo->dir->keyA=raiz->keyB;
        novo->dir->valuesA=raiz->valuesB;
        novo->keyA=raiz->keyA;
        novo->valuesA=raiz->valuesA;
        return novo;
    }
    else{
        if(raiz->keyB<chave){//promove keyB

        }
        else{//promove novo

        }
    }
    return 1;
}


Item A23::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item A23::get(string chave, A23* raiz){
    if(raiz==nullptr){
        Item nada;
        return nada;
    }
    if(raiz->keyA==chave){
        return raiz->valuesA;
    }
    if(raiz->keyA>chave){
        return get(chave,raiz->esq);
    }
    if(raiz->SaoDois){
        if(raiz->keyB==chave){
            return raiz->valuesB;
        }
        if(raiz->keyB<chave){
            return get(chave,raiz->dir);
        }
        return get(chave,raiz->mei);
    }
    else{
        return get(chave,raiz->dir);
    }
}


void principalA23(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[N+10];
    A23 arv;

    for(i=0;i<N;i++){//leitura do texto
        texto[i]=leitura();
        Item stats;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto[i]);
        stats.tam=texto[i].length();
        stats.nR=nRep(texto[i]);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        arv.add(texto[i],stats);
        cout<<"saida "<<i<<endl;
        arv.printa(arv.getraiz());
    }

    //Consultas_A23 (arv,tam_max,vog_max,nrtam_max,tam_min);
}

A23* A23::getraiz(){
    return raiz;
}

void A23::printa(A23* raiz){
  queue<A23*> q;
  A23* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout <<"A:"<< n->keyA<<n->valuesA.freq;
      if(n->keyB!="\0"){
        cout <<"B:"<< n->keyB<<n->valuesB.freq;
      }
      else{
        cout<<"B:-";
      }
      cout<<"   ";
      q.push(n->esq);
      q.push(n->mei);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    if (c == (1 << i) - 1) {
      cout << endl;
      i++;
    }
  }
}