#include <bits/stdc++.h>
#include "VO.h"
#include "funcoes.h"
using namespace std;

vector<pair<string,long long>> palavras;
long long freq_max=1;

Item value(string key){
    Item* val;
    val=new Item[3];
    if(palavras.size()==0){
        Item nada;
        nada.freq=0;
        nada.vogais=0;
        nada.tam=0;
        nada.nR=true;
        return nada;
    }
    long long inicio,meio,fim;
    inicio=0;
    fim=palavras.size()-1;
    meio=(inicio+fim)/2;
    while(key!=palavras[meio].first && inicio<fim){//"busca binaria"
        if(key>palavras[meio].first){
            if(inicio==meio){
                Item nada;
                nada.freq=0;
                nada.vogais=0;
                nada.tam=0;
                nada.nR=true;
                return nada;
            }
            inicio=meio;
            meio=(meio+fim+1)/2;
        }
        else{
            if(fim==meio){
                Item nada;
                nada.freq=0;
                nada.vogais=0;
                nada.tam=0;
                nada.nR=true;
                return nada;
            }
            fim=meio;
            meio=(meio+inicio)/2;
        }
    }
    if(!(inicio<fim)){
        Item nada;
        nada.freq=0;
        nada.vogais=0;
        nada.tam=0;
        nada.nR=true;
        return nada;
    }
    val[1].freq=palavras[meio].second;
    val[1].nR=nRep(key);
    val[1].tam=key.length();
    val[1].vogais=qtd_vogal(key);
    return val[1];
}

void add(string key,Item val){
    long long inicio,meio,fim;
    inicio=0;
    fim=palavras.size()-1;
    meio=(inicio+fim)/2;
    if(inicio<fim){
        while(key!=palavras[meio].first && inicio<fim){
            if(key>palavras[meio].first){
                if(inicio==meio){//nova palavra
                    palavras.push_back(make_pair(key,val.freq));
                    sort(palavras.begin(),palavras.end());
                    return;
                }
                inicio=meio;
                meio=(meio+fim+1)/2;
            }
            else{
                if(fim==meio){//nova  palavra
                    palavras.push_back(make_pair(key,val.freq));
                    sort(palavras.begin(),palavras.end());
                    return;
                }
                fim=meio;
                meio=(meio+inicio)/2;
            }
        }
    }
    if(!(inicio<fim)){//nova palavra
        palavras.push_back(make_pair(key,val.freq));
        sort(palavras.begin(),palavras.end());
        return;
    }
    palavras[meio].second++;
    if(palavras[meio].second>freq_max){
        freq_max=palavras[meio].second;
    }
}

void Consultas_VO (long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    Item* valor;
    valor=new Item[5];
    cin>>Q;
    cout<<tam_min<<endl;
    for(j=0;j<Q;j++){
        string tmp;
        long long i;
        cin>>tmp;
        if(tmp=="F"){
            for(i=0;i<palavras.size();i++){
                valor[1]=value(palavras[i].first);
                if(valor[1].freq==freq_max){
                    cout<<palavras[i].first<<" ";
                }
            }
            cout<<endl;
        }
        if(tmp=="VD"){
            cout<<vog_max<<" "<<tam_min;
            for(i=0;i<palavras.size();i++){
                valor[1]=value(palavras[i].first);
                if(valor[1].vogais==vog_max && palavras[i].first.length()==tam_min){
                    cout<<palavras[i].first<<" ";
                }
            }
            cout<<"a"<<endl;
            for(i=0;i<palavras.size();i++){
                valor[1]=value(palavras[i].first);
                if(valor[1].vogais==vog_max){
                    cout<<palavras[i].first<<" ";
                }
            }
            cout<<"a"<<endl;
            for(i=0;i<palavras.size();i++){
                valor[1]=value(palavras[i].first);
                if(palavras[i].first.length()==tam_min){
                    cout<<palavras[i].first<<" ";
                }
            }
            cout<<endl;
        }
        if(tmp=="SR"){
            for(i=0;i<palavras.size();i++){
                valor[1]=value(palavras[i].first);
                if(valor[1].nR && palavras[i].first.length()==nrtam_max){
                    cout<<palavras[i].first<<" ";
                }
            }   
            cout<<endl;         
        }
        if(tmp=="L"){
            for(i=0;i<palavras.size();i++){
                if(palavras[i].first.length()==tam_max){
                    cout<<palavras[i].first<<" ";
                }
            }
            cout<<endl;
        }
        if(tmp=="O"){
            cin>>tmp;
            valor[1]=value(tmp);
            cout<<valor[1].freq<<endl;           
        }
    }
}

void principalVO(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Item stats;
    for(i=0;i<N;i++){//leitura do texto
        texto=leitura();
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        add(texto,stats);
    }
    Consultas_VO (tam_max,vog_max,nrtam_max,tam_min);//funcao que realiza as consultas
}

void testeVO(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i,size;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Item stats;
    char p[1000];
    char* tmp;

    clock_t t;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:");
        texto=texto+tmp;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto);
        stats.tam=texto.length();
        stats.nR=nRep(texto);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        add(texto,stats);
    }


    t=clock()-t;
    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    Item teste;

    string primeira,meio,fim;
    primeira=palavras[0].first;

    meio=palavras[palavras.size()/2].first;

    fim=palavras[palavras.size()-1].first;

    t=clock();
    teste=value(primeira);
    teste=value(meio);
    teste=value(fim);
    t=clock()-t;

    float media;
    media=((float)t/CLOCKS_PER_SEC)/3.0;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
    //cout<<"Consultas: "<<endl;
    //Consultas_VO (tam_max,vog_max,nrtam_max,tam_min);
}