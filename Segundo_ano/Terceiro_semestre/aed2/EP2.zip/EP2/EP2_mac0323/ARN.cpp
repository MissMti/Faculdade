#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include <random>
#include "ARN.h"
#include "funcoes.h"
using namespace std;

long long freq_maxARN=1;

ARN::ARN(){
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
}

void ARN::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz);
    this->raiz->cor=false;//raiz preta
    return;
}

ARN* ARN::put(string chave, Item val, ARN* raiz){
    if(raiz==nullptr){//primeiro elemento
        raiz=new ARN;
        raiz->key=chave;
        raiz->values=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;  
        raiz->cor=true;  //inicia vermelho
        return raiz;
    }
    if(raiz->key==chave){//elemento já existente
        raiz->values.freq++;
        if(raiz->values.freq>freq_maxARN){
            freq_maxARN=raiz->values.freq;
        }
    }
    else{
        if(raiz->key<chave){//para direita
            raiz->dir=put(chave,val,raiz->dir);
        }
        else{
            raiz->esq=put(chave,val,raiz->esq);//para esquerda
        }   
    }
    
    //balanceia/arruma as cores após adicionar elemento
    if (getcor(raiz->dir) && !getcor(raiz->esq)){
        raiz=rotacionaesq(raiz);
    }
    if(raiz->esq!=nullptr){
        if (getcor(raiz->esq) &&  getcor(raiz->esq->esq)){
            raiz=rotacionadir(raiz);
        }
    }
    if (getcor(raiz->esq) &&  getcor(raiz->dir)){
        raiz=mudaCor(raiz);
    }    
    return raiz;
}

Item ARN::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item ARN::get(string chave, ARN* raiz){
    if(raiz==nullptr){
        Item nada;
        nada.freq=0;
        return nada;
    }
    if(raiz->key==chave){
        return raiz->values;
    }
    if(raiz->key<chave){
        return get(chave,raiz->dir);
    }
    return get(chave,raiz->esq);
}

void Consultas_ARN (ARN arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    ARN* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxARN(arv.getraiz());
            cout<<endl;
        }
        if(tmp=="VD"){
            arv.vmaxARN(arv.getraiz(),vog_max,tam_min);
            cout<<endl;        
        }
        if(tmp=="SR"){
            arv.nrmaxARN(arv.getraiz(),nrtam_max);
            cout<<endl;
        }
        if(tmp=="L"){
            arv.tmaxARN(arv.getraiz(),tam_max);
            cout<<endl;
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;
        }
    }
}




void principalARN(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto[1];
    ARN arv;

    for(i=0;i<N;i++){//leitura do texto[1]
        texto[1]=leitura();
        Item stats[1];
        stats[1].freq=1;
        stats[1].vogais=qtd_vogal(texto[1]);
        stats[1].tam=texto[1].length();
        stats[1].nR=nRep(texto[1]);
        if(stats[1].tam>tam_max){
            tam_max=stats[1].tam;
        }
        if(stats[1].nR && stats[1].tam>nrtam_max){
            nrtam_max=stats[1].tam;
        }
        if(stats[1].vogais>vog_max){
            tam_min=stats[1].tam;
            vog_max=stats[1].vogais;
        }
        if(stats[1].vogais==vog_max){
            if(tam_min>stats[1].tam){
                tam_min=stats[1].tam;
            }
        }
        arv.add(texto[1],stats[1]);//adiciona palavra a estrutura     
    }
    arv.printa(arv.getraiz());
    Consultas_ARN (arv,tam_max,vog_max,nrtam_max,tam_min);
}

ARN* ARN::getraiz(){
    return raiz;
}

void ARN::printa(ARN* raiz){
  queue<ARN*> q;
  ARN* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout << n->key<<n->values.freq <<"C:"<<n->cor<<" ";
      q.push(n->esq);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    if (c == (1 << i) - 1) {
      cout << endl;
      i++;
    }
  }
  cout<<endl<<endl;
}

bool ARN::getcor(ARN* folha){
    if(folha==nullptr){
        return false;
    }
    return folha->cor;
}

string ARN::getmenor(ARN* atual){
    if (atual->esq != nullptr) {
      return getmenor(atual->esq);
    }
    return atual->getkey();
}
string ARN::getmaior(ARN* atual){
    if (atual->dir != nullptr) {
      return getmaior(atual->dir);
    }
    return atual->getkey();
}
string ARN::getkey(){
    return key;
}

ARN*  ARN::rotacionadir (ARN* raiz){
    if(raiz!=nullptr && getcor(raiz->esq)){
        ARN* k;
        k=new ARN;
        k = raiz->esq;
        raiz->esq = k->dir;
        k->dir = raiz;

        k->cor = raiz->cor;
        raiz->cor = true;

        raiz = k;
        return k;
    }
    return raiz;
        
}

ARN*  ARN::rotacionaesq (ARN* raiz){
    if(raiz!=nullptr && getcor(raiz->dir)){
        ARN* k;
        k=new ARN;
        k = raiz->dir;
        raiz->dir = k->esq;
        k->esq = raiz;
        k->cor = raiz->cor;
        raiz->cor = true;
        raiz = k;
        return k;
    }
    return raiz;
}

ARN* ARN::mudaCor (ARN* raiz){
    raiz->cor = !raiz->cor;
    raiz->esq->cor = !raiz->esq->cor;
    raiz->dir->cor = !raiz->dir->cor;
    return raiz;
}

void ARN::fmaxARN(ARN *raiz){
    if (raiz != NULL) {
      fmaxARN(raiz->esq);
      if(raiz->values.freq==freq_maxARN){
        cout<< raiz->key<<" ";
      }
      fmaxARN(raiz->dir);
    }
}
void ARN::nrmaxARN(ARN *raiz, long long nrtam_maxARN){
    if (raiz != NULL) {
      nrmaxARN(raiz->esq,nrtam_maxARN);
      if(raiz->key.length()==nrtam_maxARN && raiz->values.nR){
        cout<< raiz->key<<" ";
      }
      nrmaxARN(raiz->dir,nrtam_maxARN);
    }
}
void ARN::vmaxARN(ARN *raiz, long long vog_maxARN, long long tam_minARN){
    if (raiz != NULL) {
      vmaxARN(raiz->esq,vog_maxARN,tam_minARN);
      if(raiz->values.vogais==vog_maxARN && raiz->key.length()==tam_minARN){
        cout<< raiz->key<<" ";
      }
      vmaxARN(raiz->dir,vog_maxARN,tam_minARN);
    }
}
void ARN::tmaxARN(ARN *raiz,long long tam_maxARN){
    if (raiz != NULL) {
      tmaxARN(raiz->esq,tam_maxARN);
      if(raiz->key.length()==tam_maxARN){
        cout<< raiz->key<<" ";
      }
      tmaxARN(raiz->dir,tam_maxARN);
    }
}

void testeARN(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[5];
    ARN palavras;
    Item* stats;
    stats=new Item[5];

    char p[10000];
    char* tmp;

    clock_t t;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto[0]="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:/""");
        texto[0]=texto[0]+tmp;
        
        stats[0].freq=1;
        stats[0].vogais=qtd_vogal(texto[0]);
        stats[0].tam=texto[0].length();
        stats[0].nR=nRep(texto[0]);
        if(stats[0].tam>tam_max){
            tam_max=stats[0].tam;
        }
        if(stats[0].nR && stats[0].tam>nrtam_max){
            nrtam_max=stats[0].tam;
        }
        if(stats[0].vogais>vog_max){
            tam_min=stats[0].tam;
            vog_max=stats[0].vogais;
        }
        if(stats[0].vogais==vog_max){
            if(tam_min>stats[0].tam){
                tam_min=stats[0].tam;
            }
        }
        palavras.add(texto[0],stats[0]);
    }
    t=clock()-t;
    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    

    Item teste;

    string primeira,meio,fim;
    
    
    primeira=palavras.getmenor(palavras.getraiz());
    
    meio=palavras.getraiz()->getkey();
    
    fim=palavras.getmaior(palavras.getraiz());

    t=clock();
    teste=palavras.value(primeira);
    teste=palavras.value(meio);
    teste=palavras.value(fim);
    t=clock()-t;
    float media;
    media=((float)t/(float)CLOCKS_PER_SEC)/(float)3.0;
    cout<<"Tempo médio para value: "<<media<<" s"<<endl;
    cout<<endl;
    //cout<<"Consultas: "<<endl;
    //Consultas_ARN (palavras,tam_max,vog_max,nrtam_max,tam_min);
}