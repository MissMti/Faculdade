#include <bits/stdc++.h>
#include "VO.h"
using namespace std;

long long k=0,freq_max=1,tam_max=0,nrtam_max=0,vog_max=0;
Vordem* palavras;


long long value_VO (string p){
    for(long long j=0;j<k;j++){
        if(palavras[j].word==p){
            return palavras[j].freq;
        }
    }
    return 0;
}

bool nR(string p){
    int alfabeto[35];
    long long i,l;

    for(i=0;i<35;i++){
        alfabeto[i]=0;
    }
    for(i=0;i<p.length();i++){
        if(p[i]=='-'){
            l=30;
        }
        else{
            if(p[i]>='A' && p[i]<='Z'){
                l=p[i]-65;
            }
            else{
                l=p[i]-97;
            }
        }
        if(alfabeto[l]==1){
            return false;
        }
        else{
            alfabeto[l]=1;
        }
    }
    return true;
}

long long qtd_vogal(string p){
    long long qtd,j,a=0,e=0,i=0,o=0,u=0;
    //cout<<p<<" ";
    for(j=0;j<p.length();j++){
        if((p[j]=='a'||p[j]=='A')&& a==0){
            //cout<<"a";
            a=1;
        }
        if((p[j]=='e'||p[j]=='E')&& e==0){
            //cout<<"e";
            e=1;
        }
        if((p[j]=='i'||p[j]=='I')&& i==0){
            //cout<<"i";
            i=1;
        }
        if((p[j]=='o'||p[j]=='O')&& o==0){
            //cout<<"o";
            o=1;
        }
        if((p[j]=='u'||p[j]=='U')&& u==0){
            //cout<<"u";
            u=1;
        }
    }
    qtd=a+e+i+o+u;
    //cout<<"a: "<<a<<"e: "<<e<<"i: "<<i<<"o: "<<o<<"u: "<<u<<"qtd: "<<qtd<<endl;
    return qtd;
}


void Consultas_VO (){
    long long i,Q,j;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            for(j=0;j<k;j++){
                if(palavras[j].freq==freq_max){
                    cout<<palavras[j].word<<endl;
                }
            }
        }
        if(tmp=="VD"){
            //cout<<"vogal maxima: "<<vog_max<<endl;
            for(j=0;j<k;j++){
                //cout<<palavras[j].word<<palavras[j].vogais<<endl;
                if(palavras[j].vogais==vog_max){
                    cout<<palavras[j].word<<endl;
                }
            }
            
        }
        if(tmp=="SR"){
            for(j=0;j<k;j++){
                if(palavras[j].nR==true && palavras[j].word.length()==nrtam_max){
                    cout<<palavras[j].word<<endl;
                }
            }
            
        }
        if(tmp=="L"){\
            for(j=0;j<k;j++){
                if(palavras[j].word.length()==tam_max){
                    cout<<palavras[j].word<<endl;
                    //break;
                }
            }
        }
        if(tmp=="O"){
            cin>>tmp;
            cout<<value_VO(tmp)<<endl;           
        }
    }
}



void add_VO (string p, long long val){//tornar uma busca binaria!!
    long long entrou=0,i,cont=0,j;
    
    for(i=0;i<k;i++){
        if(palavras[i].word == p){//palavras já existentes
            entrou=1;
            palavras[i].freq++;
            if(palavras[i].freq>freq_max){
                freq_max=palavras[i].freq;
            }
            //cout<<p<<palavras[k].vogais<<qtd_vogal(p)<<endl;
            return;
        }
        else{
            if(palavras[i].word > p){//novas palavras
                entrou=1;
                k++;
                for(j=k;j>=i;j--){
                    palavras[j].word=palavras[j-1].word;
                    palavras[j].freq=palavras[j-1].freq;
                    palavras[j].vogais=palavras[j-1].vogais;
                    palavras[j].nR=palavras[j-1].nR;
                }
                palavras[i].word=p;
                palavras[i].freq=val;
                palavras[i].vogais=qtd_vogal(p);
                //cout<<p<<palavras[i].vogais<<qtd_vogal(p)<<endl;
                palavras[i].nR=nR(p);
                if(palavras[i].nR && p.length()>nrtam_max){
                    nrtam_max=p.length();
                }
                if(palavras[i].vogais>vog_max){
                    vog_max=palavras[i].vogais;
                }
                return;
            }
        }
    }
    if(k==0){//primeira palavra
        palavras[k].word=p;
        palavras[k].freq=val;
        palavras[k].vogais=qtd_vogal(p);
        //cout<<p<<palavras[k].vogais<<qtd_vogal(p)<<endl;
        palavras[k].nR=nR(p);
        if(palavras[k].nR && p.length()>nrtam_max){
            nrtam_max=p.length();
        }
        if(palavras[k].vogais>vog_max){
            vog_max=palavras[k].vogais;
        }
        k++;
        return;
    }
    if(entrou==0){//entra no fim
        palavras[k].word=p;
        palavras[k].freq=val;
        palavras[k].vogais=qtd_vogal(p);
        //cout<<p<<palavras[k].vogais<<qtd_vogal(p)<<endl;
        palavras[k].nR=nR(p);
        if(palavras[k].nR && p.length()>nrtam_max){
            nrtam_max=p.length();
        }
        if(palavras[k].vogais>vog_max){
            vog_max=palavras[k].vogais;
        }
        k++;
    }
    return;
}

void mVO(long long N){
    long long j=0,i,entrou;
    string p;
    //cout<<"a1";
    
    palavras= new Vordem [N+10];

    for(j=0;j<N;j++){//ler o texto
		cin>>p;
        if(p.length()>tam_max){
            tam_max=p.length();
        }
        cout<<p<<p.length()<<endl;
        add_VO(p,1);
    }
    
    for(j=0;j<k;j++){//ler o texto
        //cout<<"entrou";
		cout<<palavras[j].word<<" "<<palavras[j].freq<<endl;
    }


    Consultas_VO ();
}



