#include <bits/stdc++.h>
#pragma once
using namespace std;

class Treaps {
    public:
        string word;
        long long freq;  
        long long vogais;
        bool nR;
        Treaps* dir;
        Treaps* esq;
};
void mTR(long long N);
void add_TR (string p, long long val);

/*

long long get(ABB* raiz, string p);
long long value_ABB (string p);
void add_ABB (string p, long long val);
ABB* put(ABB* raiz, string p, long long val);
void inorder(ABB* atual);
void Consultas_ABB();
void fmaxABB(ABB *atual);
void nrmaxABB(ABB *atual);
void vmaxABB(ABB *atual);
void tmaxABB(ABB *atual);*/