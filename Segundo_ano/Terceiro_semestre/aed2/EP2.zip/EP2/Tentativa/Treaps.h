#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;


class Treaps {
private:
    string key;
    Item values;
    Treaps* raiz;
    Treaps* esq;
    Treaps* dir;
    long long prioridade;//valor sorteado pseudo-aleatoriamente
public:
    Treaps();//constutora

    void add(string chave, Item val);
    Treaps* put(string chave, Item val, Treaps* ini);

    Item value(string chave);
    Item get(string chave, Treaps* raiz);
  
    Treaps*  rotacionadir (Treaps* raiz);
    Treaps*  rotacionaesq (Treaps* raiz);

    Treaps* getraiz();
    Treaps* getmenor(Treaps* atual);
    Treaps* getmaior(Treaps* atual);
    string getkey();
       
    void fmaxTreaps(Treaps *raiz);//imprime palavras com maior frequencia no texto
    void nrmaxTreaps(Treaps *raiz, long long nrtam_maxTreaps);//imprime palavras com maior tamanho sem repeticao de caracteres do texto
    void vmaxTreaps(Treaps *raiz, long long vog_maxTreaps, long long tam_minTreaps);//imprime palavras com a maior quantidade de vogais diferentes e o menor tamanho do texto
    void tmaxTreaps(Treaps *raiz,long long tam_maxTreaps);//imprime palavras de maior tamanho do texto
    
    void printa(Treaps* arv);
};

void Consultas_Treaps(Treaps palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);

void principalTreaps(long long N);

void testeTR(char* arq);