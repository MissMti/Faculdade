#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;



void Consultas_VO(VO palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);
void principalVO(long long N);
void printa(VO* atu);