#include <bits/stdc++.h>
#pragma once
using namespace std;

struct Item {
    long long freq;//frequencia da palavra do texto
    long long vogais;//quantidade de vogais diferentes na palavra
    long long tam;//tamanho da palavra
    bool nR;//true: se não há repeticao e false: se há repeticao de caracteres na palavra (sem contar "-" e "'")
};

string leitura();//funcao de leitura das palavras do texto

bool nRep(string p);//funcao que verifica se não há repeticao de caracteres na palavra (sem contar "-" e "'")

long long qtd_vogal(string p);//funcao que verifica a quantidade de vogais diferentes há na palavra