#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include <random>
#include "Treaps.h"
#include "funcoes.h"
using namespace std;

long long freq_maxTreaps=1;
random_device rd;
uniform_int_distribution<int> distr(1,10000);

Treaps::Treaps(){
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
}

void Treaps::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz);
    return;
}

Treaps* Treaps::put(string chave, Item val, Treaps* raiz){
    if(raiz==nullptr){//primeiro elemento
        raiz=new Treaps;
        raiz->key=chave;
        raiz->values=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;   
        raiz->prioridade=distr(rd);    
        return raiz;
    }
    if(raiz->key==chave){//elemento já existente
        raiz->values.freq++;
        if(raiz->values.freq>freq_maxTreaps){
            freq_maxTreaps=raiz->values.freq;
        }
        return raiz;
    }
    if(raiz->key<chave){//para direita
        raiz->dir=put(chave,val,raiz->dir);
        if(raiz->dir->prioridade>raiz->prioridade){
            raiz=rotacionadir(raiz);
        }
        return raiz;
    }
    raiz->esq=put(chave,val,raiz->esq);//para esquerda
    if(raiz->esq->prioridade>raiz->prioridade){
        raiz=rotacionaesq(raiz);
    }
    return raiz;
}


Item Treaps::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item Treaps::get(string chave, Treaps* raiz){
    if(raiz==nullptr){
        Item nada;
        nada.freq=0;
        return nada;
    }
    if(raiz->key==chave){
        return raiz->values;
    }
    if(raiz->key<chave){
        return get(chave,raiz->dir);
    }
    return get(chave,raiz->esq);
}

void Consultas_Treaps (Treaps arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    Treaps* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxTreaps(arv.getraiz());
            cout<<endl;
        }
        if(tmp=="VD"){
            arv.vmaxTreaps(arv.getraiz(),vog_max,tam_min);  
            cout<<endl;
        }
        if(tmp=="SR"){
            arv.nrmaxTreaps(arv.getraiz(),nrtam_max);
            cout<<endl;
        }
        if(tmp=="L"){
            arv.tmaxTreaps(arv.getraiz(),tam_max);
            cout<<endl;
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalTreaps(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Treaps arv;
    Item stats[1];
    for(i=0;i<N;i++){//leitura do texto
        texto=leitura();
        
        stats[1].freq=1;
        stats[1].vogais=qtd_vogal(texto);
        stats[1].tam=texto.length();
        stats[1].nR=nRep(texto);
        if(stats[1].tam>tam_max){
            tam_max=stats[1].tam;
        }
        if(stats[1].nR && stats[1].tam>nrtam_max){
            nrtam_max=stats[1].tam;
        }
        if(stats[1].vogais>vog_max){
            tam_min=stats[1].tam;
            vog_max=stats[1].vogais;
        }
        if(stats[1].vogais==vog_max){
            if(tam_min>stats[1].tam){
                tam_min=stats[1].tam;
            }
        }
        arv.add(texto,stats[1]);
        /*cout<<"saida "<<i<<endl;
        arv.printa(arv.getraiz());
        cout<<endl<<endl;*/
    }
    Consultas_Treaps (arv,tam_max,vog_max,nrtam_max,tam_min);
}

Treaps* Treaps::getraiz(){
    return raiz;
}

Treaps* Treaps::getmenor(Treaps* atual){
    if (atual->esq != nullptr) {
      return getmenor(atual->esq);
    }
    return atual;
}

Treaps* Treaps::getmaior(Treaps* atual){
    if (atual->dir != nullptr) {
      return getmaior(atual->dir);
    }
    return atual;
}

string Treaps::getkey(){
    return key;
}

void Treaps::printa(Treaps* raiz){
  queue<Treaps*> q;
  Treaps* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout << n->key<<n->values.freq <<"P:"<<n->prioridade<<" ";
      q.push(n->esq);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    cout<<endl;
  }
}

Treaps*  Treaps::rotacionaesq (Treaps* raiz){
    Treaps* k;
    k=new Treaps;
    k = raiz->esq;
    raiz->esq = k->dir;
    k->dir = raiz;
    raiz = k;
    return raiz;
}

Treaps*  Treaps::rotacionadir (Treaps* raiz){
    Treaps* k;
    k=new Treaps;
    k = raiz->dir;
    raiz->dir = k->esq;
    k->esq = raiz;
    raiz = k;
    return raiz;
}

void Treaps::fmaxTreaps(Treaps *raiz){
    if (raiz != NULL) {
      fmaxTreaps(raiz->esq);
      if(raiz->values.freq==freq_maxTreaps){
        cout<< raiz->key<<" ";
      }
      fmaxTreaps(raiz->dir);
    }
}

void Treaps::nrmaxTreaps(Treaps *raiz, long long nrtam_maxTreaps){
    if (raiz != NULL) {
      nrmaxTreaps(raiz->esq,nrtam_maxTreaps);
      if(raiz->key.length()==nrtam_maxTreaps && raiz->values.nR){
        cout<< raiz->key<<" ";
      }
      nrmaxTreaps(raiz->dir,nrtam_maxTreaps);
    }
}
void Treaps::vmaxTreaps(Treaps *raiz, long long vog_maxTreaps, long long tam_minTreaps){
    if (raiz != NULL) {
      vmaxTreaps(raiz->esq,vog_maxTreaps,tam_minTreaps);
      if(raiz->values.vogais==vog_maxTreaps && raiz->key.length()==tam_minTreaps){
        cout<< raiz->key<<" ";
      }
      vmaxTreaps(raiz->dir,vog_maxTreaps,tam_minTreaps);
    }
}
void Treaps::tmaxTreaps(Treaps *raiz,long long tam_maxTreaps){
    if (raiz != NULL) {
      tmaxTreaps(raiz->esq,tam_maxTreaps);
      if(raiz->key.length()==tam_maxTreaps){
        cout<< raiz->key<<" ";
      }
      tmaxTreaps(raiz->dir,tam_maxTreaps);
    }
}

void testeTR(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto;
    Treaps palavras;
    Item* stats;
    stats= new Item[5];
    char p[10000];
    char* tmp;

    clock_t t;

    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:/");
        texto=texto+tmp;
        stats[1].freq=1;
        stats[1].vogais=qtd_vogal(texto);
        stats[1].tam=texto.length();
        stats[1].nR=nRep(texto);
        if(stats[1].tam>tam_max){
            tam_max=stats[1].tam;
        }
        if(stats[1].nR && stats[1].tam>nrtam_max){
            nrtam_max=stats[1].tam;
        }
        if(stats[1].vogais>vog_max){
            tam_min=stats[1].tam;
            vog_max=stats[1].vogais;
        }
        if(stats[1].vogais==vog_max){
            if(tam_min>stats[1].tam){
                tam_min=stats[1].tam;
            }
        }
        palavras.add(texto,stats[1]);
    }
    t=clock()-t;

    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;
    Item teste;

    Treaps* meio;
    Treaps* fim;
    Treaps* primeira;
    primeira=new Treaps;
    primeira=palavras.getmenor(palavras.getraiz());

    meio= new Treaps;
    meio=palavras.getraiz();

    fim= new Treaps;
    fim=palavras.getmaior(palavras.getraiz());

    t=clock();
    teste=palavras.value(primeira->getkey());
    teste=palavras.value(meio->getkey());
    teste=palavras.value(fim->getkey());
    t=clock()-t;

    
    float media;
    media=(float)((float)t/CLOCKS_PER_SEC)/3.0;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
    //cout<<endl;
    //cout<<"Consultas: "<<endl;
    //Consultas_Treaps (palavras,tam_max,vog_max,nrtam_max,tam_min);
}