#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include "A23.h"
#include "funcoes.h"
using namespace std;

long long freq_maxA23=1;
bool* promoveu=new bool;

A23::A23(){
    keyA="\0";
    keyB="\0";
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
    SaoDois=false;
}

void A23::add(string chave, Item val){
    promoveu[0]=0;
    this->raiz=put(chave,val,this->raiz,promoveu);
    return;
}

A23* A23::put(string chave, Item val, A23* raiz, bool* promoveu){
    if(raiz==nullptr){//raiz tah vazia
        raiz=new A23;
        raiz->keyA=chave;
        raiz->valuesA=val;
        raiz->esq=nullptr;
        raiz->mei=nullptr; 
        raiz->dir=nullptr;
        raiz->SaoDois=false;
        promoveu[0]=true;
        return raiz;
    }
    if(!raiz->SaoDois){//raiz so tem um elmento
        if(raiz->keyA==chave){//jah existe a chave
            raiz->valuesA.freq++;
            if(raiz->valuesA.freq>freq_maxA23){
                freq_maxA23=raiz->valuesA.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(ehFolha(raiz)){//se for folha eu adiciono aqui
            if(chave>raiz->keyA){//o elemento que jah estava era menor
                raiz->keyB=chave;
                raiz->valuesB=val;
            }
            else{//o elemnto que jah estava eh maior
                raiz->keyB=raiz->keyA;
                raiz->valuesB=raiz->valuesA;
                raiz->keyA=chave;
                raiz->valuesA=val;
            }
            raiz->SaoDois=true;//agr sao dois elementos
            promoveu[0]=false;
            return raiz;
        }
        else{//nao eh folha, preciso continuar o caminho
            A23* tmp=new A23;
            if(raiz->keyA>chave){//caminho para a esquerda
                tmp=put(chave,val,raiz->esq,promoveu);
                //verifica se cresceu
                if(promoveu[0]==1){
                    raiz->keyB=raiz->keyA;
                    raiz->valuesB=raiz->valuesA;
                    raiz->keyA=tmp->keyA;
                    raiz->valuesA=tmp->valuesA;
                    raiz->esq=tmp->esq;
                    raiz->mei=tmp->dir;
                    raiz->SaoDois=true;
                    promoveu[0]=false;
                    return raiz;
                }
                raiz->esq=tmp;
                return raiz;
            }
            //caminho para a direita
            tmp=put(chave,val,raiz->dir,promoveu);
            //
            //verifica se cresceu
            if(promoveu[0]){
                raiz->keyB=tmp->keyA;
                raiz->valuesB=tmp->valuesA;
                raiz->dir=tmp->dir;
                raiz->mei=tmp->esq;
                raiz->SaoDois=true;
                promoveu[0]=false;
                return raiz;
            }
            raiz->dir=tmp;
            return raiz;
        }
    }
    else{
        if(raiz->keyA==chave){//jah existe a chave
            raiz->valuesA.freq++;
            if(raiz->valuesA.freq>freq_maxA23){
                freq_maxA23=raiz->valuesA.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(raiz->keyB==chave){//jah existe a chave
            raiz->valuesB.freq++;
            if(raiz->valuesB.freq>freq_maxA23){
                freq_maxA23=raiz->valuesB.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(ehFolha(raiz)){//se for folha eu adiciono aqui, Explode!!!
            A23* sobe=new A23;
            A23* maior=new A23;
            if(chave<raiz->keyA){//sobe A
                sobe->keyA=raiz->keyA;
                sobe->valuesA=raiz->valuesA;
                sobe->esq=raiz;
                sobe->mei=nullptr; 
                sobe->dir=maior;
                sobe->SaoDois=false;

                raiz->keyA=chave;
                raiz->valuesA=val;
                raiz->SaoDois=false;

                maior->keyA=raiz->keyB;
                maior->valuesA=raiz->valuesB;
                maior->esq=nullptr;
                maior->mei=nullptr; 
                maior->dir=nullptr;
                maior->SaoDois=false;

            }
            else{
                if(chave<raiz->keyB){//sobre chave
                    sobe->keyA=chave;
                    sobe->valuesA=val;
                    sobe->esq=raiz;
                    sobe->mei=nullptr; 
                    sobe->dir=maior;
                    sobe->SaoDois=false;

                    raiz->SaoDois=false;

                    maior->keyA=raiz->keyB;
                    maior->valuesA=raiz->valuesB;
                    maior->esq=nullptr;
                    maior->mei=nullptr; 
                    maior->dir=nullptr;
                    maior->SaoDois=false;
                }
                else{//sobe o b
                    sobe->keyA=raiz->keyB;
                    sobe->valuesA=raiz->valuesB;
                    sobe->esq=raiz;
                    sobe->mei=nullptr; 
                    sobe->dir=maior;
                    sobe->SaoDois=false;

                    raiz->SaoDois=false;

                    maior->keyA=chave;
                    maior->valuesA=val;
                    maior->esq=nullptr;
                    maior->mei=nullptr; 
                    maior->dir=nullptr;
                    maior->SaoDois=false;
                }

            }
            promoveu[0]=true;
            return sobe;
        }
        else{//nao eh folhae preciso seguir o caminho
            A23* tmp=new A23;
            A23* sobe=new A23;
            if(raiz->keyA>chave){//caminho para a esquerda
                tmp=put(chave,val,raiz->esq,promoveu);
                //verifica se cresceu
                
                if(promoveu[0]){
                    sobe->keyA=raiz->keyA;
                    sobe->valuesA=raiz->valuesA;
                    sobe->esq=tmp;
                    sobe->dir=raiz;
                    sobe->SaoDois=false;

                    raiz->keyA=raiz->keyB;
                    raiz->valuesA=raiz->valuesB;
                    raiz->esq=raiz->mei;
                    raiz->SaoDois=false;

                    promoveu[0]=true;
                    return sobe;
                }
                raiz->esq=tmp;
                return raiz;
            }
            if(raiz->keyB>chave){//caminho para o meio
                tmp=put(chave,val,raiz->mei,promoveu);

                //verifica se cresceu
                if(promoveu[0]){
                    sobe->keyA=raiz->keyB;
                    sobe->valuesA=raiz->valuesB;
                    sobe->esq=tmp->dir;
                    sobe->dir=raiz->dir;
                    sobe->SaoDois=false;

                    raiz->dir=tmp->esq;
                    raiz->SaoDois=false;

                    tmp->esq=raiz;
                    tmp->dir=sobe;
                    tmp->SaoDois=false;

                    promoveu[0]=true;
                    return tmp;
                }
                raiz->mei=tmp;
                return raiz;
            }
            //caminho para a direita
            tmp=put(chave,val,raiz->dir,promoveu);

            //verifica se cresceu
            if(promoveu[0]){
                sobe->keyA=raiz->keyB;
                sobe->valuesA=raiz->valuesB;
                sobe->esq=raiz;
                sobe->dir=tmp;
                sobe->SaoDois=false;

                raiz->dir=raiz->mei;
                raiz->SaoDois=false;

                tmp->SaoDois=false;

                promoveu[0]=true;
                return sobe;
            }
            raiz->dir=tmp;
            return raiz;
        }
    }
    
}


Item A23::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item A23::get(string chave, A23* raiz){
    if(raiz==nullptr){
        Item nada;
        nada.freq=0;
        return nada;
    }
    if(raiz->keyA==chave){
        return raiz->valuesA;
    }
    if(raiz->keyA>chave){
        return get(chave,raiz->esq);
    }
    if(raiz->SaoDois){
        if(raiz->keyB==chave){
            return raiz->valuesB;
        }
        if(raiz->keyB<chave){
            return get(chave,raiz->dir);
        }
        return get(chave,raiz->mei);
    }
    else{
        return get(chave,raiz->dir);
    }
}


void Consultas_A23 (A23 arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    A23* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxA23(arv.getraiz());
            cout<<endl;
        }
        if(tmp=="VD"){
            arv.vmaxA23(arv.getraiz(),vog_max,tam_min);
            cout<<endl;
        }
        if(tmp=="SR"){
            arv.nrmaxA23(arv.getraiz(),nrtam_max);
            cout<<endl;
        }
        if(tmp=="L"){
            arv.tmaxA23(arv.getraiz(),tam_max);
            cout<<endl;
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalA23(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string texto[1];
    A23 arv;

    for(i=0;i<N;i++){//leitura do texto[1]
        texto[1]=leitura();
        Item stats[1];
        stats[1].freq=1;
        stats[1].vogais=qtd_vogal(texto[1]);
        stats[1].tam=texto[1].length();
        stats[1].nR=nRep(texto[1]);
        if(stats[1].tam>tam_max){
            tam_max=stats[1].tam;
        }
        if(stats[1].nR && stats[1].tam>nrtam_max){
            nrtam_max=stats[1].tam;
        }
        if(stats[1].vogais>vog_max){
            tam_min=stats[1].tam;
            vog_max=stats[1].vogais;
        }
        if(stats[1].vogais==vog_max){
            if(tam_min>stats[1].tam){
                tam_min=stats[1].tam;
            }
        }
        arv.add(texto[1],stats[1]);//adiciona a palvra na estrutura
    }

    /*cout<<endl;
    arv.printa(arv.getraiz());
    cout<<endl<<endl;*/
    Consultas_A23 (arv,tam_max,vog_max,nrtam_max,tam_min);
}

A23* A23::getraiz(){
    return raiz;
}

string A23::getkeyA(){
    return keyA;
}

string A23::getmenor(A23* atual){
    if (atual->esq != nullptr) {
      return getmenor(atual->esq);
    }
    return atual->getkeyA();
}

string A23::getmaior(A23* atual){
    if (atual->dir != nullptr) {
      return getmaior(atual->dir);
    }
    return atual->getkeyA();
}

void A23::printa(A23* raiz){
  queue<A23*> q;
  A23* n;
  int c = 1,i=0;;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    i++;
    if (n) {
      cout <<"A:"<< n->keyA<<n->valuesA.freq;
      if(n->SaoDois){
        cout <<"B:"<< n->keyB<<n->valuesB.freq;
      }
      else{
        cout<<"B:-";
      }
      cout<<"   ";
      q.push(n->esq);
      if(n->SaoDois){
        q.push(n->mei);
      }
      else{
        q.push(nullptr);
      }
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    cout<<endl;
  }
}

bool A23::getSaoDois(A23* raiz){
    if(raiz==nullptr){
        return false;
    }
    return raiz->SaoDois;
}

bool A23::ehFolha(A23* raiz){
    if(raiz->dir==nullptr && raiz->esq == nullptr && raiz->mei == nullptr){
        return true;
    }
    return false;
}

void A23::fmaxA23(A23 *raiz){
    if (raiz != NULL) {
      fmaxA23(raiz->esq);
      if(raiz->valuesA.freq==freq_maxA23){
        cout<< raiz->keyA<<" ";
      }
      if(raiz->SaoDois){
        if(raiz->valuesB.freq==freq_maxA23){
            cout<< raiz->keyB<<" ";
        }
        fmaxA23(raiz->mei);
      }
      fmaxA23(raiz->dir);
    }
}
void A23::nrmaxA23(A23 *raiz, long long nrtam_maxA23){
    if (raiz != NULL) {
      nrmaxA23(raiz->esq,nrtam_maxA23);
      if(raiz->keyA.length()==nrtam_maxA23 && raiz->valuesA.nR){
        cout<< raiz->keyA<<" ";
      }
      if(raiz->SaoDois){
        if(raiz->keyB.length()==nrtam_maxA23 && raiz->valuesB.nR){
            cout<< raiz->keyB<<" ";
        }
        nrmaxA23(raiz->mei,nrtam_maxA23);
      }
      nrmaxA23(raiz->dir,nrtam_maxA23);
    }
}
void A23::vmaxA23(A23 *raiz, long long vog_maxA23, long long tam_minA23){
    if (raiz != NULL) {
      vmaxA23(raiz->esq,vog_maxA23,tam_minA23);
      if(raiz->valuesA.vogais==vog_maxA23 && raiz->keyA.length()==tam_minA23){
        cout<< raiz->keyA<<" ";
      }
      if(raiz->SaoDois){
        if(raiz->valuesB.vogais==vog_maxA23 && raiz->keyB.length()==tam_minA23){
            cout<< raiz->keyB<<" ";
        }
        vmaxA23(raiz->mei,vog_maxA23,tam_minA23);
      }
      vmaxA23(raiz->dir,vog_maxA23,tam_minA23);
    }
}
void A23::tmaxA23(A23 *raiz,long long tam_maxA23){
    if (raiz != NULL) {
      tmaxA23(raiz->esq,tam_maxA23);
      if(raiz->keyA.length()==tam_maxA23){
        cout<< raiz->keyA<<" ";
      }
      if(raiz->SaoDois){
        if(raiz->keyB.length()==tam_maxA23){
            cout<< raiz->keyB<<" ";
        }
        tmaxA23(raiz->mei,tam_maxA23);
      }
      tmaxA23(raiz->dir,tam_maxA23);
    }
}

void testeA23(char* arq){
    FILE* f;
    f = fopen(arq, "rt");
    long long N;
    cin>>N;

    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[5];
    A23 palavras;
    Item* stats;
    stats=new Item[5];

    char p[10000];
    char* tmp;

    clock_t t;
    t=clock();
    for(i=0;i<N;i++){//leitura do texto
        texto[0]="";
        fscanf(f, "%s", p);
        tmp=strtok(p, ".?!;,:/");
        texto[0]=texto[0]+tmp;
        
        stats[0].freq=1;
        stats[0].vogais=qtd_vogal(texto[0]);
        stats[0].tam=texto[0].length();
        stats[0].nR=nRep(texto[0]);
        if(stats[0].tam>tam_max){
            tam_max=stats[0].tam;
        }
        if(stats[0].nR && stats[0].tam>nrtam_max){
            nrtam_max=stats[0].tam;
        }
        if(stats[0].vogais>vog_max){
            tam_min=stats[0].tam;
            vog_max=stats[0].vogais;
        }
        if(stats[0].vogais==vog_max){
            if(tam_min>stats[0].tam){
                tam_min=stats[0].tam;
            }
        }
        palavras.add(texto[0],stats[0]);
    }
    t=clock()-t;
    cout<<"Tempo para a adição na estrutura: "<<(float)t/CLOCKS_PER_SEC<<" s"<<endl;

    Item teste;

    string primeira,meio,fim;
    
    
    primeira=palavras.getmenor(palavras.getraiz());
    
    meio=palavras.getraiz()->getkeyA();
    
    fim=palavras.getmaior(palavras.getraiz());

    t=clock();
    teste=palavras.value(primeira);
    teste=palavras.value(meio);
    teste=palavras.value(fim);
    t=clock()-t;
    float media;
    media=((float)t/CLOCKS_PER_SEC)/(float)N;
    cout<<"Tempo médio para value: "<<(float)media<<" s"<<endl;
    //cout<<endl;
    //cout<<"Consultas: "<<endl;
    //Consultas_A23 (palavras,tam_max,vog_max,nrtam_max,tam_min);
}