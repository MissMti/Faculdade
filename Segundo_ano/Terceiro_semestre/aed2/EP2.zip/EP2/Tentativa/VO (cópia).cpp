#include <bits/stdc++.h>
#include "VO.h"
#include "funcoes.h"
//#include "item.h"
using namespace std;

long long freq_max=1;


VO::VO(){
    ini=nullptr;
    prox=nullptr;
}


void VO:: add(string p, Item val){
    this->ini=put(p,val,this->ini);
    return;
}

/*VO* VO::put(string p, Item val, VO* atu){//tirar recursivo!!!
    string provisorio;
    VO* aux;
    
    if(atu==nullptr){//primeira palavra
        atu=new VO;
        atu->key=p;
        atu->values=val;    
        atu->prox=nullptr;
        return atu;
    }
    aux=atu;
    cout<<"primeira"<<endl;
    while(aux->key<p){
        cout<<aux->key<<" "<<p<<endl;
        aux=aux->prox;
        if(aux==nullptr){//ultima posicao
            cout<<"entra"<<p<<endl;;
            aux=new VO;
            aux->key=p;
            aux->values=val;    
            aux->prox=nullptr;
            return atu;
        }
        else{
            cout<<aux->key<<" "<<p<<endl;
        }
    }
    
    cout<<"m";
    if(aux->key==p){//adc em posicao que ja existe
        aux->values.freq++;
        if(aux->values.freq>freq_max){
            freq_max=aux->values.freq;
        }
        return atu;
    }
    //adc nessa posicao
    VO* tmp;
    tmp=new VO;
    tmp->values=aux->values;
    tmp->key=aux->key;
    tmp->prox=aux->prox;
    aux->values=val;
    aux->key=p;
    aux->prox=tmp;

    return atu;
}*/


VO* VO::put(string p, Item val, VO* atu){
    string provisorio;

    
    if(atu==nullptr){//primeira palavra
        atu=new VO;
        atu->key=p;
        atu->values=val;    
        atu->prox=nullptr;
        atu->ini=atu;
        cout<<"novo"<<p<<endl;
        return atu;
    }
    cout<<atu->key<<" "<<p<<endl;
    if(atu->key==p){//adc em posicao que ja existe
        atu->values.freq++;
        if(atu->values.freq>freq_max){
            freq_max=atu->values.freq;
        }
        return atu;
    }
    if(atu->key<p){//adc mais a frente
        cout<<"adc mais frente"<<endl;
        atu->prox=put(p,val,atu->prox);
        return atu;
    }
    //adc nessa posicao
    VO* tmp;
    cout<<"adc aqui"<<endl;
    tmp=new VO;
    tmp->values=atu->values;
    tmp->key=atu->key;
    tmp->prox=atu->prox;
    atu->values=val;
    atu->key=p;
    atu->prox=tmp;

    return atu;
}

//como descobrem onde eh o comeco?

Item VO:: value(string p){
    Item valor=getvalue(p,this->ini);

    return valor;
}

Item VO:: getvalue(string p, VO* atu){
    VO* aux;
    if(atu->getkey()==p){
        return atu->values;
    }
    aux=atu->prox;
    while(aux->key!=p){
        aux=aux->prox;
    }
    return aux->values;
}



void Consultas_VO (VO palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    VO* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            atu=palavras.getini();
            while(atu!=nullptr){
                if(atu->getfreq()==freq_max){
                    cout<<atu->getkey()<<endl;
                }
                atu=atu->getprox();
            }
        }
        if(tmp=="VD"){
            atu=palavras.getini();
            while(atu!=nullptr){
                if(atu->getvogais()==vog_max && atu->getkey().length()==tam_min){
                    cout<<atu->getkey()<<endl;
                }
                atu=atu->getprox();
            }            
        }
        if(tmp=="SR"){
            atu=palavras.getini();
            while(atu!=nullptr){
                if(atu->getnr() && atu->getkey().length()==nrtam_max){
                    cout<<atu->getkey()<<endl;
                }
                atu=atu->getprox();
            }   
            
        }
        if(tmp=="L"){
            atu=palavras.getini();
            while(atu!=nullptr){
                if(atu->getkey().length()==tam_max){
                    cout<<atu->getkey()<<endl;
                }
                atu=atu->getprox();
            }
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=palavras.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalVO(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[N+10];
    VO palavras;
    Item stats;
    for(i=0;i<N;i++){//leitura do texto
        texto[i]=leitura();
        
        stats.freq=1;
        stats.vogais=qtd_vogal(texto[i]);
        stats.tam=texto[i].length();
        stats.nR=nRep(texto[i]);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }

        palavras.add(texto[i],stats);//adiciona a palavra a estrutura
    }

    if(palavras.getini()!=nullptr){
        printa(palavras.getini());
    }

    Consultas_VO (palavras,tam_max,vog_max,nrtam_max,tam_min);//funcao que realiza as consultas
}


void printa(VO* atu){
    cout<<atu->getkey()<<atu->getfreq()<<endl;
    if(atu->getprox()==nullptr){
        return;
    }
    printa(atu->getprox());
}

string VO::getkey() {
	return key;
}
VO* VO::getprox() {
	return  prox;
}

long long VO::getfreq(){
    return values.freq;
}

long long VO::getvogais(){
    return values.vogais;
}

bool VO::getnr(){
    return values.nR;
}

VO* VO::getini(){
    return this->ini;
}