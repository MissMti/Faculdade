#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include "A23.h"
#include "funcoes.h"
using namespace std;

long long freq_maxA23=1;
bool promoveu=0;

A23::A23(){
    keyA="\0";
    keyB="\0";
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
    SaoDois=false;
}

void A23::add(string chave, Item val){
    this->raiz=put(chave,val,this->raiz,promoveu);
    return;
}

bool A23::getSaoDois(A23* raiz){
    if(raiz==nullptr){
        return false;
    }
    return raiz->SaoDois;
}

bool A23::ehFolha(A23* raiz){
    if(raiz->dir==nullptr && raiz->esq == nullptr && raiz->mei == nullptr){
        return true;
    }
    return false;
}

A23* A23::put(string chave, Item val, A23* raiz, bool promoveu){
    if(raiz==nullptr){//primeiro elemento
        raiz=new A23;
        raiz->keyA=chave;
        raiz->valuesA=val;
        raiz->esq=nullptr;
        raiz->mei=nullptr; 
        raiz->dir=nullptr;
        raiz->SaoDois=false;
        promoveu=true;
        return raiz;
    }
    if(ehFolha(raiz)){
        if(raiz->SaoDois==false){//tinha um elemento
            if(chave>raiz->keyA){//o elemento que jah estava era menor
                raiz->keyB=chave;
                raiz->valuesB=val;
            }
            else{//o elemnto que jah estava eh maior
                raiz->keyB=raiz->keyA;
                raiz->valuesB=raiz->valuesA;
                raiz->keyA=chave;
                raiz->valuesA=val;
            }
            raiz->SaoDois=true;//agr sao dois elementos
            promoveu=false;
            return raiz;
        }
        else{//tinha dois elementos
            //raiz vira o menor
            A23* sobe=new A23;
            A23* maior=new A23;
            
            if(raiz->keyA>chave){//sobe keyA

            }
            else{
                if(raiz->keyB<chave){//sobe keyB
                }
                else{//sobe o novo msm
                    sobe->keyA=chave;
                    sobe->valuesA=val;
                }
            }
            promoveu=true;
            return sobe;

        }
    }
    if(raiz->keyA==chave){//eh igual

    }

    if(raiz->keyA>chave){//vou para a esquerda
        A23* p=new A23;
        p=put(chave,val,raiz->dir,promoveu);
        if(!promoveu){
            return p;
        }
        else{
            if(raiz->SaoDois==false){
                //empurra para a direita
                raiz->SaoDois=true;
                promoveu=false;
            }
            else{//explode novamente
                //cuida da explosao
                raiz->SaoDois=false;
                promoveu=true;
                
            }
            return raiz;
        }

    }
    if(raiz->SaoDois){//vou para o meio, jah acontecera a explosao de qualuqer jeito?
        if(raiz->keyB==chave){
            
        }
        if(raiz->keyB>chave){
            A23* p=new A23;
            p=put(chave,val,raiz->dir,promoveu);
            if(!promoveu){
                return p;
            }
            else{
                if(raiz->SaoDois==false){
                    //empurra para a direita
                    raiz->SaoDois=true;
                    promoveu=false;
                    return raiz;
                }
                else{//explode novamente
                    //cuida da explosao, sobe pela segunda vez
                    raiz->SaoDois=false;
                    promoveu=true;
                    return raiz;
                }
            }

        }
    }
    //vou para a direita
    A23* p=new A23;
    p=put(chave,val,raiz->dir,promoveu);
    if(!promoveu){
        return p;
    }
    else{
        if(raiz->SaoDois==false){
            //empurra para a esquera(nao precisa :P)
            raiz->SaoDois=true;
            promoveu=false;
            return raiz;
        }
        else{//explode novamente
            //cuida da explosao
            raiz->SaoDois=false;
            promoveu=true;
            return raiz;
        }
    }
    
}


Item A23::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item A23::get(string chave, A23* raiz){
    if(raiz==nullptr){
        Item nada;
        return nada;
    }
    if(raiz->keyA==chave){
        return raiz->valuesA;
    }
    if(raiz->keyA>chave){
        return get(chave,raiz->esq);
    }
    if(raiz->SaoDois){
        if(raiz->keyB==chave){
            return raiz->valuesB;
        }
        if(raiz->keyB<chave){
            return get(chave,raiz->dir);
        }
        return get(chave,raiz->mei);
    }
    else{
        return get(chave,raiz->dir);
    }
}


void principalA23(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[N+10];
    A23 arv;

    for(i=0;i<N;i++){//leitura do texto
        texto[i]=leitura();
        Item stats;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto[i]);
        stats.tam=texto[i].length();
        stats.nR=nRep(texto[i]);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        arv.add(texto[i],stats);
        cout<<"saida "<<i<<endl;
        arv.printa(arv.getraiz());
    }

    //Consultas_A23 (arv,tam_max,vog_max,nrtam_max,tam_min);
}

A23* A23::getraiz(){
    return raiz;
}

void A23::printa(A23* raiz){
  queue<A23*> q;
  A23* n;
  int c = 0, i = 1;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    c++;
    if (n) {
      cout <<"A:"<< n->keyA<<n->valuesA.freq;
      if(n->keyB!="\0"){
        cout <<"B:"<< n->keyB<<n->valuesB.freq;
      }
      else{
        cout<<"B:-";
      }
      cout<<"   ";
      q.push(n->esq);
      q.push(n->mei);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    if (c == (1 << i) - 1) {
      cout << endl;
      i++;
    }
  }
}