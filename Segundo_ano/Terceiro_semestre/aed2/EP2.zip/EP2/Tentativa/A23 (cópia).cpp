#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#include "A23.h"
#include "funcoes.h"
using namespace std;

long long freq_maxA23=1;
int promoveu[2];
promoveu[0]=false;

A23::A23(){
    keyA="\0";
    keyB="\0";
    raiz=nullptr;
    esq=nullptr;
    dir=nullptr;
    SaoDois=false;
}

void A23::add(string chave, Item val){
    promoveu[0]=0;
    this->raiz=put(chave,val,this->raiz,promoveu[0]);
    return;
}

bool A23::getSaoDois(A23* raiz){
    if(raiz==nullptr){
        return false;
    }
    return raiz->SaoDois;
}

bool A23::ehFolha(A23* raiz){
    if(raiz->dir==nullptr && raiz->esq == nullptr && raiz->mei == nullptr){
        return true;
    }
    return false;
}


A23* A23::put(string chave, Item val, A23* raiz, bool promoveu[0]){
    if(raiz==nullptr){//raiz tah vazia
        raiz=new A23;
        raiz->keyA=chave;
        raiz->valuesA=val;
        raiz->esq=nullptr;
        raiz->mei=nullptr; 
        raiz->dir=nullptr;
        raiz->SaoDois=false;
        promoveu[0]=true;
        return raiz;
    }
    if(!raiz->SaoDois){//raiz so tem um elmento
        if(raiz->keyA==chave){//jah existe a chave
            raiz->valuesA.freq++;
            if(raiz->valuesA.freq>freq_maxA23){
                freq_maxA23=raiz->valuesA.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(ehFolha(raiz)){//se for folha eu adiciono aqui
            if(chave>raiz->keyA){//o elemento que jah estava era menor
                raiz->keyB=chave;
                raiz->valuesB=val;
            }
            else{//o elemnto que jah estava eh maior
                raiz->keyB=raiz->keyA;
                raiz->valuesB=raiz->valuesA;
                raiz->keyA=chave;
                raiz->valuesA=val;
            }
            raiz->SaoDois=true;//agr sao dois elementos
            promoveu[0]=false;
            return raiz;
        }
        else{//nao eh folha, preciso continuar o caminho
            A23* tmp=new A23;
            if(raiz->keyA>chave){//caminho para a esquerda
                tmp=put(chave,val,raiz->esq,promoveu[0]);
                cout<<"entrou na esquerda!"<<endl;
                //verifica se cresceu
                cout<<"promo: "<<promoveu[0]<<endl;
                if(promoveu[0]==1){
                    cout<<"promocao"<<endl;
                    raiz->keyB=raiz->keyA;
                    raiz->valuesB=raiz->valuesA;
                    raiz->keyA=tmp->keyA;
                    raiz->valuesA=tmp->valuesA;
                    raiz->esq=tmp->esq;
                    raiz->mei=tmp->dir;
                    raiz->SaoDois=true;
                    promoveu[0]=false;
                    return raiz;
                }
                raiz->esq=tmp;
                return raiz;
            }
            //caminho para a direita
            tmp=put(chave,val,raiz->dir,promoveu[0]);
            //
            //verifica se cresceu
            if(promoveu[0]){
                raiz->keyB=tmp->keyA;
                raiz->valuesB=tmp->valuesA;
                raiz->dir=tmp->dir;
                raiz->mei=tmp->esq;
                raiz->SaoDois=true;
                promoveu[0]=false;
                return raiz;
            }
            raiz->dir=tmp;
            return raiz;
        }
    }
    else{
        cout<<"eh cheia"<<endl;
        if(raiz->keyA==chave){//jah existe a chave
            raiz->valuesA.freq++;
            if(raiz->valuesA.freq>freq_maxA23){
                freq_maxA23=raiz->valuesA.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(raiz->keyB==chave){//jah existe a chave
            raiz->valuesB.freq++;
            if(raiz->valuesB.freq>freq_maxA23){
                freq_maxA23=raiz->valuesB.freq;
            }
            promoveu[0]=false;
            return raiz;
        }
        if(ehFolha(raiz)){//se for folha eu adiciono aqui, Explode!!!
            A23* sobe=new A23;
            A23* maior=new A23;
            if(chave<raiz->keyA){//sobe A
                cout<<"aquiA"<<endl;
                sobe->keyA=raiz->keyA;
                sobe->valuesA=raiz->valuesA;
                sobe->esq=raiz;
                sobe->mei=nullptr; 
                sobe->dir=maior;
                sobe->SaoDois=false;

                raiz->keyA=chave;
                raiz->valuesA=val;
                raiz->SaoDois=false;

                maior->keyA=raiz->keyB;
                maior->valuesA=raiz->valuesB;
                maior->esq=nullptr;
                maior->mei=nullptr; 
                maior->dir=nullptr;
                maior->SaoDois=false;

            }
            else{
                if(chave<raiz->keyB){//sobre chave
                    cout<<"aquiB"<<endl;
                    sobe->keyA=chave;
                    sobe->valuesA=val;
                    sobe->esq=raiz;
                    sobe->mei=nullptr; 
                    sobe->dir=maior;
                    sobe->SaoDois=false;

                    raiz->SaoDois=false;

                    maior->keyA=raiz->keyB;
                    maior->valuesA=raiz->valuesB;
                    maior->esq=nullptr;
                    maior->mei=nullptr; 
                    maior->dir=nullptr;
                    maior->SaoDois=false;
                }
                else{//sobe o b
                    cout<<"aquiC"<<endl;
                    sobe->keyA=raiz->keyB;
                    sobe->valuesA=raiz->valuesB;
                    sobe->esq=raiz;
                    sobe->mei=nullptr; 
                    sobe->dir=maior;
                    sobe->SaoDois=false;

                    raiz->SaoDois=false;

                    maior->keyA=chave;
                    maior->valuesA=val;
                    maior->esq=nullptr;
                    maior->mei=nullptr; 
                    maior->dir=nullptr;
                    maior->SaoDois=false;
                }

            }
            promoveu[0]=true;
            cout<<"promoveu[0]: "<<promoveu[0]<<endl;
            return sobe;
        }
        else{//nao eh folhae preciso seguir o caminho
            A23* tmp=new A23;
            A23* sobe=new A23;
            if(raiz->keyA<chave){//caminho para a esquerda
                tmp=put(chave,val,raiz->esq,promoveu[0]);
                //verifica se cresceu
                if(promoveu[0]){
                    sobe->keyA=raiz->keyA;
                    sobe->valuesA=raiz->valuesA;
                    sobe->esq=tmp;
                    sobe->dir=raiz;
                    sobe->SaoDois=false;

                    raiz->keyA=raiz->keyB;
                    raiz->valuesA=raiz->valuesB;
                    raiz->esq=raiz->mei;
                    raiz->SaoDois=false;

                    promoveu[0]=true;
                    return sobe;
                }
                raiz->esq=tmp;
                return raiz;
            }
            if(raiz->keyB>chave){//caminho para o meio
                tmp=put(chave,val,raiz->mei,promoveu[0]);
                //verifica se cresceu
                if(promoveu[0]){
                    sobe->keyA=raiz->keyB;
                    sobe->valuesA=raiz->valuesB;
                    sobe->esq=tmp->dir;
                    sobe->dir=raiz->dir;
                    sobe->SaoDois=false;

                    raiz->dir=tmp->esq;
                    raiz->SaoDois=false;

                    tmp->esq=raiz;
                    tmp->dir=sobe;
                    tmp->SaoDois=false;

                    promoveu[0]=true;
                    return tmp;
                }
                raiz->mei=tmp;
                return raiz;
            }
            //caminho para a direita
            tmp=put(chave,val,raiz->dir,promoveu[0]);
            //verifica se cresceu
            if(promoveu[0]){
                sobe->keyA=raiz->keyB;
                sobe->valuesA=raiz->valuesB;
                sobe->esq=raiz;
                sobe->dir=tmp;
                sobe->SaoDois=false;

                raiz->dir=raiz->mei;
                raiz->SaoDois=false;

                tmp->SaoDois=false;

                promoveu[0]=true;
                return sobe;
            }
            raiz->dir=tmp;
            return raiz;
        }
    }
    
}


Item A23::value(string chave){
    Item valor=get(chave,this->raiz);
    return valor;
}
Item A23::get(string chave, A23* raiz){
    if(raiz==nullptr){
        Item nada;
        return nada;
    }
    if(raiz->keyA==chave){
        return raiz->valuesA;
    }
    if(raiz->keyA>chave){
        return get(chave,raiz->esq);
    }
    if(raiz->SaoDois){
        if(raiz->keyB==chave){
            return raiz->valuesB;
        }
        if(raiz->keyB<chave){
            return get(chave,raiz->dir);
        }
        return get(chave,raiz->mei);
    }
    else{
        return get(chave,raiz->dir);
    }
}


void A23::fmaxA23(A23 *raiz){
    if (raiz != NULL) {
      fmaxA23(raiz->esq);
      if(raiz->valuesA.freq==freq_maxA23){
        cout<< raiz->keyA<<endl;
      }
      if(raiz->SaoDois){
        if(raiz->valuesB.freq==freq_maxA23){
            cout<< raiz->keyB<<endl;
        }
        fmaxA23(raiz->mei);
      }
      fmaxA23(raiz->dir);
    }
}
void A23::nrmaxA23(A23 *raiz, long long nrtam_maxA23){
    if (raiz != NULL) {
      nrmaxA23(raiz->esq,nrtam_maxA23);
      if(raiz->keyA.length()==nrtam_maxA23 && raiz->valuesA.nR){
        cout<< raiz->keyA<<endl;
      }
      if(raiz->SaoDois){
        if(raiz->keyB.length()==nrtam_maxA23 && raiz->valuesB.nR){
            cout<< raiz->keyB<<endl;
        }
        nrmaxA23(raiz->mei,nrtam_maxA23);
      }
      nrmaxA23(raiz->dir,nrtam_maxA23);
    }
}
void A23::vmaxA23(A23 *raiz, long long vog_maxA23, long long tam_minA23){
    if (raiz != NULL) {
      vmaxA23(raiz->esq,vog_maxA23,tam_minA23);
      if(raiz->valuesA.vogais==vog_maxA23 && raiz->keyA.length()==tam_minA23){
        cout<< raiz->keyA<<endl;
      }
      if(raiz->SaoDois){
        if(raiz->valuesB.vogais==vog_maxA23 && raiz->keyB.length()==tam_minA23){
            cout<< raiz->keyB<<endl;
        }
        nrmaxA23(raiz->mei,tam_minA23);
      }
      vmaxA23(raiz->dir,vog_maxA23,tam_minA23);
    }
}
void A23::tmaxA23(A23 *raiz,long long tam_maxA23){
    if (raiz != NULL) {
      tmaxA23(raiz->esq,tam_maxA23);
      if(raiz->keyA.length()==tam_maxA23){
        cout<< raiz->keyA<<endl;
      }
      if(raiz->SaoDois){
        if(raiz->keyB.length()==tam_maxA23){
            cout<< raiz->keyB<<endl;
        }
        nrmaxA23(raiz->mei,tam_maxA23);
      }
      tmaxA23(raiz->dir,tam_maxA23);
    }
}


void Consultas_A23 (A23 arv, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min){
    long long i,Q,j;
    A23* atu;
    Item valor;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            arv.fmaxA23(arv.getraiz());
        }
        if(tmp=="VD"){
            arv.vmaxA23(arv.getraiz(),vog_max,tam_min);        
        }
        if(tmp=="SR"){
            arv.nrmaxA23(arv.getraiz(),nrtam_max);
        }
        if(tmp=="L"){
            arv.tmaxA23(arv.getraiz(),tam_max);
        }
        if(tmp=="O"){
            cin>>tmp;
            valor=arv.value(tmp);
            cout<<valor.freq<<endl;           
        }
    }
}


void principalA23(long long N){
    long long j=0,i;
    long long tam_max=0,nrtam_max=0,vog_max=0,tam_min=10000;
    string* texto;
    texto=new string[N+10];
    A23 arv;

    for(i=0;i<N;i++){//leitura do texto
        texto[i]=leitura();
        Item stats;
        stats.freq=1;
        stats.vogais=qtd_vogal(texto[i]);
        stats.tam=texto[i].length();
        stats.nR=nRep(texto[i]);
        if(stats.tam>tam_max){
            tam_max=stats.tam;
        }
        if(stats.nR && stats.tam>nrtam_max){
            nrtam_max=stats.tam;
        }
        if(stats.vogais>vog_max){
            tam_min=stats.tam;
            vog_max=stats.vogais;
        }
        if(stats.vogais==vog_max){
            if(tam_min>stats.tam){
                tam_min=stats.tam;
            }
        }
        arv.add(texto[i],stats);
        cout<<endl;
        cout<<"saida "<<i<<endl;
        arv.printa(arv.getraiz());
        cout<<endl<<endl;
    }

    Consultas_A23 (arv,tam_max,vog_max,nrtam_max,tam_min);
}

A23* A23::getraiz(){
    return raiz;
}

void A23::printa(A23* raiz){
  queue<A23*> q;
  A23* n;
  int c = 1,i=0;;
  q.push(raiz);
  while (!q.empty()) {
    n = q.front(); q.pop();
    i++;
    if (n) {
      cout <<"A:"<< n->keyA<<n->valuesA.freq;
      if(n->SaoDois){
        cout <<"B:"<< n->keyB<<n->valuesB.freq;
      }
      else{
        cout<<"B:-";
      }
      cout<<"   ";
      q.push(n->esq);
      q.push(n->mei);
      q.push(n->dir);
    }
    else {
      cout << "- ";
    }
    cout<<endl;
  }
}