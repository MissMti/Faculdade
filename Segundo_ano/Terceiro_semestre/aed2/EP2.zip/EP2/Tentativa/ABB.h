#include <bits/stdc++.h>
#include "funcoes.h"
#pragma once
using namespace std;


class ABB {
private:
    string key;
    Item values;
    ABB* raiz;
    ABB* esq;
    ABB* dir;
public:
    ABB();//construtora

    void add(string chave, Item val);
    ABB* put(string chave, Item val, ABB* ini);

    Item value(string chave);
    Item get(string chave, ABB* raiz);

	string getkey();
    ABB* getraiz();
    ABB* getmenor(ABB *atual);
    ABB* getmaior(ABB *atual);

    long long getfreq();
    ABB* getesq();
    ABB* getdir();

    void fmaxABB(ABB *raiz);//imprime palavras com maior frequencia no texto
    void nrmaxABB(ABB *raiz, long long nrtam_maxABB);//imprime palavras com maior tamanho sem repeticao de caracteres do texto
    void vmaxABB(ABB *raiz, long long vog_maxABB, long long tam_minABB);//imprime palavras com a maior quantidade de vogais diferentes e o menor tamanho do texto
    void tmaxABB(ABB *raiz,long long tam_maxABB);//imprime palavras de maior tamanho do texto

    void printa(ABB* arv);
};

void Consultas_ABB(ABB palavras, long long tam_max, long long vog_max, long long nrtam_max, long long tam_min);

void principalABB(long long N);

void testeABB(char* arq);


