#include <bits/stdc++.h>
#include "ABB.h"
#include "VO.h"
using namespace std;

long long kABB=0,freq_maxABB=1,tam_maxABB=0,nrtam_maxABB=0,vog_maxABB=0;
ABB* raizABB;

void fmaxABB(ABB *raiz){
    if (raiz != NULL) {
      fmaxABB(raiz->esq);
      if(raiz->freq==freq_maxABB){
        cout<< raiz->word<<endl;
      }
      fmaxABB(raiz->dir);
    }
}

void nrmaxABB(ABB *raiz){
    if (raiz != NULL) {
      nrmaxABB(raiz->esq);
      if(raiz->word.length()==nrtam_maxABB && raiz->nR){
        cout<< raiz->word<<endl;
      }
      nrmaxABB(raiz->dir);
    }
}
void vmaxABB(ABB *raiz){
    if (raiz != NULL) {
      vmaxABB(raiz->esq);
      if(raiz->vogais==vog_maxABB){
        cout<< raiz->word<<endl;
      }
      vmaxABB(raiz->dir);
    }
}
void tmaxABB(ABB *raiz){
    if (raiz != NULL) {
      tmaxABB(raiz->esq);
      if(raiz->word.length()==tam_maxABB){
        cout<< raiz->word<<endl;
      }
      tmaxABB(raiz->dir);
    }
}


void Consultas_ABB (){
    long long i,Q,j;
    cin>>Q;

    for(i=0;i<Q;i++){
        string tmp;
        cin>>tmp;
        if(tmp=="F"){
            fmaxABB(raizABB);
        }
        if(tmp=="VD"){
            vmaxABB(raizABB);
        }
        if(tmp=="SR"){
            nrmaxABB(raizABB);
        }
        if(tmp=="L"){\
           tmaxABB(raizABB);
        }
        if(tmp=="O"){
            cin>>tmp;
            cout<<value_ABB(tmp)<<endl;           
        }
    }
}

long long get(ABB* raiz, string p){
    if(raiz==nullptr){
        return 0;
    }
    if(raiz->word==p){
        return raiz->freq;
    }
    if(raiz->word<p){
        return get(raiz->dir,p);
    }
    return get(raiz->esq,p);
}

long long value_ABB (string p){
    return get(raizABB,p);
}

void add_ABB (string p, long long val){//tornar uma busca binaria!!
    raizABB=put(raizABB,p,val);
    return;
}

ABB* put(ABB* raiz, string p, long long val){
    if(raiz==nullptr){//primeiro elemento
        raiz=new ABB;
        raiz->word=p;
        raiz->freq=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;
        raiz->nR=nR(p);
        if(nR(p)&&p.length()>nrtam_maxABB){
            nrtam_maxABB=p.length();
        }
        raiz->vogais=qtd_vogal(p);
        if(qtd_vogal(p)>vog_maxABB){
            vog_maxABB=qtd_vogal(p);
        }
        
        return raiz;
    }
    if(raiz->word==p){
        raiz->freq++;
        if(raiz->freq>freq_maxABB){
            freq_maxABB=raiz->freq;
        }
        return raiz;
    }
    if(raiz->word<p){
        raiz->dir=put(raiz->dir,p,val);
        return raiz;
    }
    raiz->esq=put(raiz->esq,p,val);
    return raiz;
}

/*void inorder(ABB *raiz) {
    if (raiz != NULL) {
      inorder(raiz->esq);
      cout << raiz->word<< raiz->freq << " ";
      inorder(raiz->dir);
    }
  }*/

void mABB(long long N){
    long long j=0,i,entrou;
    string p;

    for(j=0;j<N;j++){//ler o texto
		cin>>p;
        if(p.length()>tam_maxABB){
            tam_maxABB=p.length();
        }
        //cout<<p<<p.length()<<endl;
        add_ABB(p,1);
    }
    
    //inorder(raizABB);


    Consultas_ABB ();
}