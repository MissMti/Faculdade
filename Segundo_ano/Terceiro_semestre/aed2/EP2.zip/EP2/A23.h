#include <bits/stdc++.h>
#pragma once
using namespace std;

class A23 {
    public:
        string word;
        long long freq;  
        long long vogais;
        bool nR;
        A23* imaior;
        A23* imenor;
        A23* dir;
        A23* meio;
        A23* esq;
};