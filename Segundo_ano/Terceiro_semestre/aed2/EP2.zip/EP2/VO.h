#include <bits/stdc++.h>
#pragma once
using namespace std;


class Vordem {
    public:
        string word;
        long long freq;  
        long long vogais;
        bool nR;     
};
void add_VO (string p, Vordem* palavras);
void mVO(long long N);
void Consultas_VO();
bool nR(string p);
long long qtd_vogal(string p);
long long value_VO (string p);

