#include <bits/stdc++.h>
#include "VO.h"
using namespace std;


//diferentes bibliotecas, impressoes iniciais e finais, implementacoes diferentes, contagem de tempo
//funcao exclusivas para a pesquisa
//Declaração de variaveis globais
//tornar uma busca binaria!! VO

string E;




void ABB(long long N){
    //Consultas (Q,2);
}

void TR(long long N){
    //Consultas (Q,3);
}

void A23(long long N){
    //Consultas (Q,4);
}

void ARN(long long N){
    //Consultas (Q,5);
}


int main(){
    long long i,j;
    long long N;
    char letra;
    char palavra_tmp[100];
    cin>>E>>N;

    if(E=="VO"){
        cout<<"1";
        mVO(N);
    }
    if(E=="ABB"){
        cout<<"2";
        ABB(N);
    }
    if(E=="TR"){
        cout<<"3";
        TR(N);
    }
    if(E=="A23"){
        cout<<"4";
        A23(N);
    }
    if(E=="ARN"){
        cout<<"5";
        ARN(N);
    }

    
    /*while(j!=-1){//ler o texto
		i=1;
		
		if(j==1){
			if((verifica>='A' && verifica<='Z')||(verifica>='a' && verifica<='z')){//verifica/encontra palavras no texto
				tmp[0]=verifica;
				fscanf(file,"%c",&verifica);
				while((verifica>='A' && verifica<='Z')||(verifica>='a' && verifica<='z')){
					tmp[i]=verifica;
					i++;//conta o tamanho da palavra
					fscanf(file,"%c",&verifica);
				}
				
				p = insercao(p, tmp, linha, i);//Insere no na arvore
				
				
				for(k=0;k<i;k++){
					tmp[k]='\0';
				}
				
				
			}
		}
		
		if(verifica=='\n'){
			linha++;
		}
		
		j=fscanf(file,"%c",&verifica);
		
	}*/
}