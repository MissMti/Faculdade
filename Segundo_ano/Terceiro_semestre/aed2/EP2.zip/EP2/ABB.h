#include <bits/stdc++.h>
#pragma once
using namespace std;


class ABB {
    public:
        string word;
        long long freq;  
        long long vogais;
        bool nR;     
        ABB* dir;
        ABB* esq;
};

void add_ABB (string p, long long val);
void mABB(long long N);
long long get(ABB* raiz, string p);
long long value_ABB (string p);
void add_ABB (string p, long long val);
ABB* put(ABB* raiz, string p, long long val);
//void inorder(ABB* raiz);
void Consultas_ABB();
void fmaxABB(ABB *raiz);
void nrmaxABB(ABB *raiz);
void vmaxABB(ABB *raiz);
void tmaxABB(ABB *raiz);