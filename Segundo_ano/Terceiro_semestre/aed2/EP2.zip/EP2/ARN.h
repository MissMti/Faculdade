#include <bits/stdc++.h>
#pragma once
using namespace std;

class ARN {
    public:
        string word;
        long long freq;  
        long long vogais;
        bool nR;
        long long cor; // =0 preto, =1 vermelho
        ARN* pai;
        ARN* dir;
        ARN* esq;
};

void mARN(long long N);

void troca_cor(ARN* raiz);
void add_ARN(string p, long long val);
ARN* put(ARN* raiz, string p, long long val, ARN* pai);
ARN * avo(ARN*n);
ARN * tio(ARN*n);

/*
private static final boolean RED= true;
private static final boolean BLACK = false;
private class Node
{
Key key;
Value val;
Node left, right;
int N;
boolean color;
Node(Key key,Value val, int N, boolean color)
{
this.key=key;
this.val=val;
this.N=N;
this.color=color;
}

}
private boolean isRed(Node x)
{
if (x == null) return false;
return x.color == RED;
}

public class RedBlackBST<Key extends Comparable<Key>, Value>
{
    private Node root;
    private class Node // BST node with color bit (see page 433)
    private
    private
    private
    private
    boolean isRed(Node h)
    Node rotateLeft(Node h)
    Node rotateRight(Node h)
    void flipColors(Node h)
    private int size()
    
}


ARN* put(ARN* raiz, string p, long long val, ARN* dad){
    if (raiz == nullptr){
        raiz=new ARN;
        raiz->word=p;
        raiz->freq=val;
        raiz->cor=1;//vermelho
        raiz->esq=nullptr;
        raiz->dir=nullptr;
        raiz->nR=nR(p);
        raiz->pai=dad;
        if(nR(p)&&p.length()>nrtam_maxARN){
            nrtam_maxARN=p.length();
        }
        raiz->vogais=qtd_vogal(p);
        if(qtd_vogal(p)>vog_maxARN){
            vog_maxARN=qtd_vogal(p);
        }
    } 
    if(raiz->word > p)
        raiz->esq = put(raiz->esq, p, val, raiz);
    else{
        if (raiz->word < p) 
            raiz->dir = put(raiz->dir, p, val, raiz);
        else{
            raiz->freq++;
            return;
        } 
    }

    if(raiz->pai!=nullptr){
        if()
    }
    if (raiz->dir->cor==1 && raiz->esq->cor==0)
        raiz = rotesq(raiz);
     if (raiz->esq->cor==1 && raiz->esq->esq->cor==1)
        raiz = rotdir(raiz);
    if (raiz->esq->cor==1 && raiz->dir->cor==1)
        troca_cor(raiz);
    //raiz->N = size(raiz->esq) + size(raiz->dir) + 1;
    return raiz;
}


ARN* put(ARN* raiz, string p, long long val, ARN* dad){
    if (raiz == nullptr){
        raiz=new ARN;
        raiz->word=p;
        raiz->freq=val;
        raiz->cor=1;//vermelho
        raiz->esq=nullptr;
        raiz->dir=nullptr;
        raiz->nR=nR(p);
        raiz->pai=dad;
        if(nR(p)&&p.length()>nrtam_maxARN){
            nrtam_maxARN=p.length();
        }
        raiz->vogais=qtd_vogal(p);
        if(qtd_vogal(p)>vog_maxARN){
            vog_maxARN=qtd_vogal(p);
        }
    } 
    if(raiz->word > p)
        raiz->esq = put(raiz->esq, p, val, raiz);
    else{
        if (raiz->word < p) 
            raiz->dir = put(raiz->dir, p, val, raiz);
        else{
            raiz->freq++;
        } 
    }

    if(raiz->pai!=nullptr){
        if(raiz->pai->cor==1){//pai vermelho
            if(raiz->pai->pai==nullptr){//nao tem avo
                raiz->pai=0;//pinta raiz de preto
            }
            else{
                if(raiz->pai->pai==0){
                    if(raiz->pai->pai->esq==1 && raiz->pai->pai->dir==1 ){

                    }
                    else{
                        
                    }
                }
            }
        }
    }
    if (raiz->dir->cor==1 && raiz->esq->cor==0)
        raiz = rotesq(raiz);
     if (raiz->esq->cor==1 && raiz->esq->esq->cor==1)
        raiz = rotdir(raiz);
    if (raiz->esq->cor==1 && raiz->dir->cor==1)
        troca_cor(raiz);
    //raiz->N = size(raiz->esq) + size(raiz->dir) + 1;
    return raiz;
}
*/