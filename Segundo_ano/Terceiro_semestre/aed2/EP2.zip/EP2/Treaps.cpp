#include <bits/stdc++.h>
#include "VO.h"
#include "Treaps.h"
using namespace std;

long long kTR=0,freq_maxTR=1,tam_maxTR=0,nrtam_maxTR=0,vog_maxTR=0;
Treaps* raizTR;


void add_TR (string p, long long val){//tornar uma busca binaria!!
    //raizTR=put(raizTR,p,val);
    return;
}

/*Treaps* put(Treaps* raiz, string p, long long val){
    // If raiz is NULL, create a new node and return it
    if(raiz==nullptr){//primeiro elemento
        raiz=new Treaps;
        raiz->word=p;
        raiz->freq=val;
        raiz->esq=nullptr;
        raiz->dir=nullptr;
        raiz->nR=nR(p);
        if(nR(p)&&p.length()>nrtam_maxTR){
            nrtam_maxTR=p.length();
        }
        raiz->vogais=qtd_vogal(p);
        if(qtd_vogal(p)>vog_maxTR){
            vog_maxTR=qtd_vogal(p);
        }
        
        return raiz;
    }
    /*
    // If p is smaller than raiz
    if (p <= raiz->word)
    {
        // put in esq subtree
        raiz->esq = put(raiz->esq, p,val);
 
        // Fix Heap property if it is violated
        if (raiz->esq->prio > raiz->prio)
            raiz = dirRotate(raiz);
    }

    else  // If p is greater
    {
        // put in dir subtree
        raiz->dir = put(raiz->dir, p,val);
 
        // Fix Heap property if it is violated
        if (raiz->dir->prio > raiz->prio)
            raiz = esqRotate(raiz);
    }
    return raiz;
}*/


void mTR(long long N){
    long long j=0,i,entrou;
    string p;

    for(j=0;j<N;j++){//ler o texto
		cin>>p;
        if(p.length()>tam_maxTR){
            tam_maxTR=p.length();
        }
        cout<<p<<p.length()<<endl;
        add_TR(p,1);
    }
    //inorder(raizABB);
    //Consultas_ABB ();
}