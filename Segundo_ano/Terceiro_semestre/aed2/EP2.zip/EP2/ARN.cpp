#include <bits/stdc++.h>
#include "VO.h"
#include "ARN.h"
using namespace std;

long long kARN=0,freq_maxARN=1,tam_maxARN=0,nrtam_maxARN=0,vog_maxARN=0;
ARN* raizARN;
ARN* x;

ARN* rotdir(ARN* raiz){
    x = raiz->esq;
    raiz->esq = x->dir;
    x->dir = raiz;
    x->cor = raiz->cor;
    raiz->cor = 1;//vermelho
    //x.N = raiz.N;
    //raiz.N = 1 + size(raiz.esq) + size(raiz.dir);
    return x;
}

ARN* rotesq(ARN* raiz){
    x = raiz->dir;
    raiz->dir = x->esq;
    x->esq = raiz;
    x->cor = raiz->cor;
    raiz->cor = 1;//vermelho
    //x.N = raiz.N;
    //raiz.N = 1 + size(raiz.esq) + size(raiz.dir);
    return x;
}

//Altura preta
//Entra "vermelho"
//Vermelhos sempre tem filhos Pretos

void troca_cor(ARN* raiz){
    if(raiz->cor==1){
        raiz->cor=0;
    }
    else{
        raiz->cor=1;
    }
    return;
}

ARN * avo(ARN*n){
	if ((n != nullptr) && (n->pai != nullptr))
		return n->pai->pai;
	else
		return nullptr;
}

ARN * tio(ARN*n){
	ARN* g = avo(n);
	if (g == nullptr)
		return nullptr; 
	if (n->pai == g->esq)
		return g->dir;
	else
		return g->esq;
}

void add_ARN(string p, long long val){ 
    raizARN = put(raizARN, p, val, nullptr);
    raizARN->cor = 0;//preto
    return;
}

ARN* put(ARN* raiz, string p, long long val, ARN* dad){
    if (raiz == nullptr){
        raiz=new ARN;
        raiz->word=p;
        raiz->freq=val;
        raiz->cor=1;//vermelho
        raiz->esq=nullptr;
        raiz->dir=nullptr;
        raiz->nR=nR(p);
        raiz->pai=dad;
        if(nR(p)&&p.length()>nrtam_maxARN){
            nrtam_maxARN=p.length();
        }
        raiz->vogais=qtd_vogal(p);
        if(qtd_vogal(p)>vog_maxARN){
            vog_maxARN=qtd_vogal(p);
        }
        return;
    } 
    if(raiz->word > p)
        raiz->esq = put(raiz->esq, p, val, raiz);
    else{
        if (raiz->word < p) 
            raiz->dir = put(raiz->dir, p, val, raiz);
        else{
            raiz->freq++;
            return;
        } 
    }

    /*if(raiz->pai==nullptr){
        raiz->cor=0;
    }
    else{
        if (raiz->pai->cor == 1)
            ARN* u = tio(raiz);
            ARN* g;
            if (u!=nullptr){
                if(u->cor==1){
                    raiz->pai->cor = 0;
                    u->cor = 0;
                    g = avo(raiz);
                    g->cor = 1;
                    
                }
            }
                
            } else {
                insercao_caso4(n);
            }
    }*/
    
    if (raiz->dir->cor==1 && raiz->esq->cor==0)
        raiz = rotesq(raiz);
     if (raiz->esq->cor==1 && raiz->esq->esq->cor==1)
        raiz = rotdir(raiz);
    if (raiz->esq->cor==1 && raiz->dir->cor==1)
        troca_cor(raiz);
    //raiz->N = size(raiz->esq) + size(raiz->dir) + 1;
    return raiz;
}

/*void inorder(ARN *atual) {
    if (atual != NULL) {
      inorder(atual->esq);
      cout << atual->word<< atual->freq << " ";
      inorder(atual->dir);
    }
  }*/

void mARN(long long N){
    long long j=0,i,entrou;
    string p;

    for(j=0;j<N;j++){//ler o texto
		cin>>p;
        if(p.length()>tam_maxARN){
            tam_maxARN=p.length();
        }
        cout<<p<<p.length()<<endl;
        add_ARN(p,1);
    }
    cout<<"tam: "<<tam_maxARN<<endl;
    //inorder(raizARN);

    //Consultas_ARN ();
}
