#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "no.h"

using namespace std;