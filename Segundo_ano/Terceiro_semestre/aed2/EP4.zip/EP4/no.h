#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

#pragma once
using namespace std;

class Conchete {
    public:
        long long tipo;//0=intrvalo e 1=conj

        //intervalo
        char min;
        char max;

        //conjunto
        char conjunto;
};

class No {

    public:

        long long restricao; //0=sem rest, 1=char, 2=conchetes, 3=contraconchetes, 4=asteriscos, 5=mais, 6=alternativas, 7=paren

        //char
        char conteudo;

        //conchetes
        Conchete* interior;
        long long qtd_intervalo;

        //parentesis
        No* partes;
        long long qtd_dentro;

        //asteriscos e mais
        No* tmp;

        //alternativa
        No* possibilidades;
        long long num_psb;

};
