#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "no.h"

#pragma once
using namespace std;

void principal(string regex);

void leitura(string base, No* g);

void verifica(No* g,long long ind);

bool encaixa(No* g,string s,long long ind,long long stg,long long stp);

stack<long long> looping(No* noh,long long ind,string s, long long stp);

stack<long long> parentsis(No* noh,long long ind,string s, long long stp);

bool faz_parte(No* noh,long long ind,string s,long long stp);

long long montagem(string base, long long ind, long long pal, No* g);

long long dentro_p(No* g,long long pal,string base,long long ind);

