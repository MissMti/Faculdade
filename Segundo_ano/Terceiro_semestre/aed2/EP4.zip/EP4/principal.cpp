#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "no.h"
#include "principal.h"


using namespace std;


long long aviso;

void principal(string regex){
    No* grafo;
    grafo= new No[regex.size()+10];
    aviso=0;
    leitura(regex,grafo);
}


void verifica(No* g,long long ind){
    long long i,n;
    string s;
    cin>>n;
    for(i=0;i<n;i++){
        cin>>s;
        if(encaixa(g,s,ind,0,0)){
            cout<<"S"<<endl;
        }
        else{
            cout<<"N"<<endl;
        }
    }
}

bool encaixa(No* g,string s,long long ind,long long stg,long long stp){
    long long tmp;
   if(stg==ind && stp==s.size()){//deu bom
        return true;
    }
    if(stg>ind || stp>s.size()){//deu erro
        return false;
    }
    if(g[stg].restricao==0){//coringa
        stp++;
        stg++;
        return encaixa(g,s,ind,stg,stp);
    }
    if(g[stg].restricao==1){//char
        if(g[stg].conteudo==s[stp]){
            stp++;
            stg++;
            return encaixa(g,s,ind,stg,stp);
        }   
    }
    if(g[stg].restricao==2){//conchete
        tmp=0;
        for(long long i=0;i<g[stg].qtd_intervalo;i++){
            if(g[stg].interior[i].tipo==0){
                if(s[stp]>=g[stg].interior[i].min && s[stp]<=g[stg].interior[i].max){
                    tmp=1;
                    break;
                }
            }
            else{
                if(g[stg].interior[i].conjunto==s[stp]){
                    tmp=1;
                    break;

                }
            }
        }
        if(tmp==1){
            stp++;
            stg++;
            return encaixa(g,s,ind,stg,stp);
        } 
    }
    if(g[stg].restricao==3){//contra-conchete
        tmp=0;
        for(long long i=0;i<g[stg].qtd_intervalo;i++){
            if(g[stg].interior[i].tipo==0){
                if(s[stp]>=g[stg].interior[i].min && s[stp]<=g[stg].interior[i].max){
                    tmp=1;
                    break;
                }
            }
            else{
                if(g[stg].interior[i].conjunto==s[stp]){
                    tmp=1;
                    break;
                }
            }
        }
        if(tmp==0){
            stp++;
            stg++;
            return encaixa(g,s,ind,stg,stp);
        } 
    }
    if(g[stg].restricao==4){//asteriscos
        stack<long long> casos;
        casos=looping(g[stg].tmp,0,s,stp);
        casos.push(stp);
        while(!casos.empty()){
            if(encaixa(g,s,ind,stg+1,casos.top())){
                return true;
            }
            casos.pop();
        }
    }
    if(g[stg].restricao==5){//mais
        stack<long long> casos;
        casos=looping(g[stg].tmp,0,s,stp);
         while(!casos.empty()){
            if(encaixa(g,s,ind,stg+1,casos.top())){
                return true;
            }
            casos.pop();
        }
    }

    if(g[stg].restricao==6){
        for(long long i=0;i<g[stg].num_psb;i++){
            if(faz_parte(g[stg].possibilidades,i,s,stp)){
                if(encaixa(g[stg].possibilidades,s,i,stg,stp))
                    return true;
            }
        }
    }

    if(g[stg].restricao==7){
        for(long long i=0;i<g[stg].qtd_dentro;i++){
            if(faz_parte(g[stg].partes,i,s,stp)){
                if(encaixa(g[stg].possibilidades,s,i,stg,stp))
                    return true;
            }
        }
    }
    return false;
}

stack<long long> looping(No* nh,long long ind,string s, long long stp){
    stack<long long> candidatos;
    No noh=nh[ind];
    long long i,j,k;
    if(noh.restricao==0){//coringa
        for(i=stp;i<s.size();i++){
            candidatos.push(i);
        }
    }
    if(noh.restricao==1){//char
        i=stp;
        while(i<s.size() && noh.conteudo==s[i]){
            candidatos.push(i);
            i++;
        }
    }
    if(noh.restricao==2){//conchete
        i=stp;
        for(i=stp;i<s.size();i++){
            k=0;
            for(j=0;j<noh.qtd_intervalo;j++){
                if(noh.interior[j].tipo==0){//intervalo
                    if(noh.interior[j].min<=s[i] && noh.interior[j].max>=s[i]){
                        k=1;
                        break;
                    }
                }
                else{//conjunto
                    if(noh.interior[j].conjunto==s[i]){
                        k=1;
                        break;
                    }
                }
            }
            if(k==1){
                candidatos.push(i);
            }
            else{
                break;
            }
        }
    }
    if(noh.restricao==3){//contra-conchete
        i=stp;
        for(i=stp;i<s.size();i++){
            k=0;
            for(j=0;j<noh.qtd_intervalo;j++){
                if(noh.interior[j].tipo==0){//intervalo
                    if(noh.interior[j].min<=s[i] && noh.interior[j].max>=s[i]){
                        k=1;
                        break;
                    }
                }
                else{//conjunto
                    if(noh.interior[j].conjunto==s[i]){
                        k=1;
                        break;
                    }
                }
            }
            if(k==1){
                break;
            }
            else{
                candidatos.push(i);
            }
        }
    }
    if(noh.restricao==4 || noh.restricao==5){//asteriscos(mais são cancelados ou ficam irrelevantes)
        candidatos=looping(noh.tmp,0,s,stp);
        candidatos.push(stp);
    }
    if(noh.restricao==6){//alternativa
        for(i=stp;i<s.size();i++){
            for(j=0;j<noh.num_psb;j++){
                if(faz_parte(noh.possibilidades,j,s,i)){
                    if(noh.possibilidades[j].restricao!=7){
                        candidatos.push(i);
                    }
                    else{
                        stack<long long> tmpo;
                        tmpo=parentsis(noh.possibilidades,j,s,stp);
                        k=0;
                        while(!tmpo.empty()){
                            candidatos.push(tmpo.top());
                            tmpo.pop();
                        }
                    }
                    break;
                }
            }
        }
    }
    if(noh.restricao==7){//parentesis
        stack<long long> tmpo;
        for(i=stp;i<s.size();i++){
            tmpo=parentsis(nh,ind,s,i);
            while(!tmpo.empty()){
                candidatos.push(tmpo.top());
                tmpo.pop();
            }
        }
        
    }
    return candidatos;
}

stack<long long> parentsis(No* noh,long long ind,string s,long long stp){
    stack<long long> candidatos;
    long long i,j,k;
    long long tmp=0;
    string a="";
    for(i=stp;i<s.size();i++){//ver todos as partes do parentesis
        a=a+s[i];
        if(encaixa(noh[0].partes,a,noh[0].qtd_dentro,0,0)){
            candidatos.push(stp+a.size());
        }
    }
    return candidatos;
}

bool faz_parte(No* nh,long long ind,string s,long long stp){
    long long i,j,k;
    No noh=nh[ind];
    if(noh.restricao==0){//coringa
        return true;
    }
    if(noh.restricao==1){//char
        if(noh.conteudo==s[stp]){
            return true;
        }
    }
    if(noh.restricao==2){//conchete
        i=stp;
        
        for(j=0;j<noh.qtd_intervalo;j++){
            if(noh.interior[j].tipo==0){//intervalo
                if(noh.interior[j].min<=s[i] && noh.interior[j].max>=s[i]){
                    return true;
                }
            }
            else{//conjunto
                if(noh.interior[j].conjunto==s[i]){
                    return true;
                }
            }
        }
    }
        
    
    if(noh.restricao==3){//contra-conchete
        i=stp;
        k=0;
        for(j=0;j<noh.qtd_intervalo;j++){
            if(noh.interior[j].tipo==0){//intervalo
                if(noh.interior[j].min<=s[i] && noh.interior[j].max>=s[i]){
                    k=1;
                }
            }
            else{//conjunto
                if(noh.interior[j].conjunto==s[i]){
                    k=1;
                }
            }
        }
        if(k==0){
            return true;
        }
    }

    if(noh.restricao==4){//asteriscos
        return true;
    }

    if(noh.restricao==5){//asteriscos
        stack<long long> tempo;
        tempo=looping(nh,ind,s,stp);
        if(!tempo.empty()){
            return true;
        }
    }

    if(noh.restricao==7){
        stack<long long> tempo;
        tempo=parentsis(nh,ind,s,stp);
        if(!tempo.empty()){
            return true;
        }
    }


    return false;
}


void leitura(string base, No* g){
    long long i,j=0,tmp;

    for(i=0;j<base.size();i++, j++){
        tmp=j;
        j=montagem(base,i,j,g);
    }
    verifica(g,i);
}


long long dentro_p(No* g,long long pal,string base,long long ind){
    stack<long long> paren;
    long long a=0,k=0,tmp,j,l,i;
    char c;
    paren.push(pal);
    aviso++;
    pal++;
    while(!paren.empty()){
        a=0;
        c=base[pal];
        if(c=='(' && a==0){
            g[ind].partes[k].restricao=7;
            g[ind].partes[k].partes=new No[base.size()];
            pal=dentro_p(g[ind].partes,pal,base,k);
        }
        if(c==')' && a==0){
            paren.pop();
            aviso--;
            k--;
        }
        if(c=='.'){
            g[ind].qtd_dentro++;
            g[ind].partes[k].restricao=0;
        }
        if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')){
            g[ind].qtd_dentro++;
            g[ind].partes[k].restricao=1;
            g[ind].partes[k].conteudo=c;
        }
        if((c==92)){
            g[ind].qtd_dentro++;
            pal++;
            c=base[pal];
            g[ind].partes[k].restricao=1;
            g[ind].partes[k].conteudo=c;
            
        }

        if(c=='['){
            pal++;
            tmp=0;
            g[ind].qtd_dentro++;
            while(base[pal+tmp]!=']'){
                tmp++;
            }

            if(base[pal]!='^'){//conchetes Conchete* interior;long long qtd_intervalo;
                g[ind].partes[k].restricao=2;
                j=0;
            }
            else{//contraconchetes
                g[ind].partes[k].restricao=3;
                pal++;
                j=1;
            }

            g[ind].partes[k].qtd_intervalo=tmp-j;
            g[ind].partes[k].interior=new Conchete[tmp+10];

            l=0;

            for(i=j;i<tmp;i++,l++,pal++){
                if(base[pal+1]=='-'){//intervalo=0
                    g[ind].partes[k].interior[l].tipo=0;
                    g[ind].partes[k].interior[l].min=base[pal];
                    g[ind].partes[k].interior[l].max=base[pal+2];
                    pal=pal+2;
                    i=i+2;
                    g[ind].partes[k].qtd_intervalo=g[ind].partes[k].qtd_intervalo-2;
                }
                else{//conjunto=1
                    g[ind].partes[k].interior[l].tipo=1;
                    g[ind].partes[k].interior[l].conjunto=base[pal];
                }
            }
        }

        if(c=='|'){
            No temp=g[ind].partes[k-1];
            k--;
            if(g[ind].partes[k].restricao!=6){
                g[ind].partes[k].restricao=6;
                g[ind].partes[k].num_psb=2;
                g[ind].partes[k].possibilidades=new No[base.size()];
                g[ind].partes[k].possibilidades[0]=temp;
                pal=montagem(base,1,pal+1,g[ind].partes[k].possibilidades);
            }
            else{
                g[ind].partes[k].num_psb++;
                g[ind].partes[k].restricao=6;
                pal=montagem(base,g[ind].partes[k].num_psb-1,pal+1,g[ind].partes[k].possibilidades);
            }

        }

        if((pal<base.size()-1) && aviso!=0 ){
            
            if(base[pal+1]=='*' ){
                g[ind].partes[k].tmp=new No[5];
                No temp=g[ind].partes[k];
                g[ind].partes[k].tmp[0]=temp;
                g[ind].partes[k].restricao=4;
                pal++;
            }
            
            if(base[pal+1]=='+'){
                g[ind].partes[k].tmp=new No[5];
                No temp=g[ind].partes[k];
                g[ind].partes[k].tmp[0]=temp;
                g[ind].partes[k].restricao=5;
                pal++;

            }
            
        }
        k++;
        pal++;
    }
    pal=pal-1;
    g[ind].qtd_dentro=k;
    return pal;
}


long long montagem(string base, long long ind,long long pal, No* g){
    long long i,j,k,tmp;
    char c=base[pal];
    
    
    if(c=='.'){
        g[ind].restricao=0;
    }
   
    if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')){
        g[ind].restricao=1;
        g[ind].conteudo=c;
    }
    
    if((c==92)){
        pal++;
        c=base[pal];
        g[ind].restricao=1;
        g[ind].conteudo=c;
    }

    if(c=='['){
        pal++;
        tmp=0;

        while(base[pal+tmp]!=']'){
            tmp++;
        }
        
        if(base[pal]!='^'){//conchetes 
            g[ind].restricao=2;
            j=0;
        }
        else{//contraconchetes
            g[ind].restricao=3;
            pal++;
            j=1;
        }

        g[ind].qtd_intervalo=tmp-j;
        g[ind].interior=new Conchete[tmp+10];


        k=0;

        for(i=j;i<tmp;i++,k++,pal++){
            if(base[pal+1]=='-'){//intervalo=0
                g[ind].interior[k].tipo=0;
                g[ind].interior[k].min=base[pal];
                g[ind].interior[k].max=base[pal+2];
                pal=pal+2;
                i=i+2;
                g[ind].qtd_intervalo=g[ind].qtd_intervalo-2;
            }
            else{//conjunto=1
                g[ind].interior[k].tipo=1;
                g[ind].interior[k].conjunto=base[pal];
            }
        }
    }

    if(c=='('){
        g[ind].partes=new No[base.size()+5];
        g[ind].qtd_dentro=0;
        g[ind].restricao=7;
        pal=dentro_p(g,pal,base,ind);
    }

    if(pal<base.size()-1){
        if(base[pal+1]=='*'){
            g[ind].tmp=new No[5];
            No temp=g[ind];
            g[ind].tmp[0]=temp;
            g[ind].restricao=4;
            pal++;
        }
        
        if(base[pal+1]=='+'){
            g[ind].tmp=new No[5];
            No temp=g[ind];
            g[ind].tmp[0]=temp;
            g[ind].restricao=5;
            pal++;
        }
        
    }
    
    return pal;
}