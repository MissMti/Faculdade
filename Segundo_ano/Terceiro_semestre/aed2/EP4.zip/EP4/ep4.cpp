#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "principal.h"

using namespace std;

int main(){
    long long i,j;
    string regex;
    cin>>regex;
    principal(regex);
    
    return 0;
}