#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "basico.h"
#include "DNA.h"

using namespace std;

int main(){
    char tmp;


    cout<<endl<<"Quer realizar as funcoes basica?(s/n)\n  ->  ";
    cin>>tmp;
    if(tmp=='s'){
        cout<<endl<<"Você optou por realizar as funcoes basicas!!!"<<endl<<endl;
        funcoes_basicas();
    }
    else{
        cout<<endl<<"Você optou por não realizar as funcoes basicas"<<endl;
    }


    cout<<endl<<endl<<endl<<endl<<"Quer realizar a tentativa de reconstrução do DNA?(s/n)\n  ->  ";
    cin>>tmp;
    if(tmp=='s'){
        cout<<endl<<"Você optou por realizar a tentativa de reconstrução do DNA!!!"<<endl<<endl;
        reconstroi_DNA();
    }
    else{
        cout<<endl<<"Você optou por não realizar a tentativa de reconstrução do DNA"<<endl;
    }
    
    return 0;
}