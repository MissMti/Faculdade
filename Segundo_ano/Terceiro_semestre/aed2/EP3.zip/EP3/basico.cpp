#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "basico.h"

using namespace std;
#define TAM 1000000 //Tamanho separado para os vetores/arrays

long long bV,bE;//Vertices,edges
char bnome_arq[1000];
vector<long long> badj[TAM];
long long bqtd[TAM];





void dfs_b(long long node, long long dp[], bool vis[]){
    long long i;

	vis[node] = true;

	for (i = 0; i < badj[node].size(); i++) {
		if (!vis[badj[node][i]]){
            dfs_b(badj[node][i], dp, vis);
        }
		dp[node] = max(dp[node], 1 + dp[badj[node][i]]);
	}
}





//Encontra distancia maxima percorrida atraves de uma dfs em um grafo aciclico
long long dist_max_b(){
	long long i;
	long long dp[bV+10];
    for(i=0;i<=bV;i++){
        dp[i]=0;
    }

    bool vis[bV+10];
    for(i=0;i<=bV;i++){
        vis[i]=false;
    }

	for (i = 1; i <= bV; i++) {
		if (!vis[i]){
            dfs_b(i, dp, vis);
        }
	}

	long long rsp = 0;

	for (i = 1; i <= bV; i++) {
		rsp = max(rsp, dp[i]);
	}
	return rsp;
}





//Essa funcao verifica a existencia ou nao de circuito no grafo, cumprindo entao sua funcao de verificar se o ultimo arco u-v esta em um circuito
bool esta_em_circuito_basico(long long u, long long n,set<long long> viscirc, vector<long long> caminho){
    long long i,vizinho;
    viscirc.insert(u);
	caminho.push_back(u);

	if (n > 0) {
		vector<long long> vizinhos = badj[u];

		for (i=0;i<n;i++) {
            vizinho=vizinhos[i];
			if (viscirc.count(vizinho) > 0) {
				if (find(caminho.begin(), caminho.end(),vizinho)!= caminho.end()) {
					return true;
				}
			}
			else {
				if (esta_em_circuito_basico(vizinho, bqtd[vizinho],viscirc, caminho)) {
					return true;
				}
			}
		}
	}

	caminho.pop_back();

	return false;
}





//Leitura no estilo descrito nas tarefas basicas no enunciado do ep
void leitura_basica(ifstream &f){
    long long i,u,v;
    f>>bV>>bE;
    
    for(i=0;i<bE;i++){
        f>>u>>v;
        badj[u].push_back(v);
        bqtd[u]++;

        set<long long> viscirc;
	    vector<long long> caminho;
        //Caso o arco u-v crie um circuito ele retira o ultimo arco para manter o grafo aciclico 
        if(esta_em_circuito_basico(u,bqtd[u],viscirc,caminho)){
            badj[u].pop_back();
            bqtd[u]--;
        }
    }
    
}





void funcoes_basicas(){
    long long d,i,j,k;

    cout<<"Insira o nome do arquivo para a leitura: ";
    cin>>bnome_arq;
    ifstream f(bnome_arq);

    if(f.fail()){
        cout<<"***** Falha de leitura!!! *****"<<endl;
        return;
    }

    leitura_basica(f);
    
    d=dist_max_b();
    cout<<endl<<endl<<"O comprimento do caminho maximo do grafo formado eh: "<<d<<endl<<endl;
}