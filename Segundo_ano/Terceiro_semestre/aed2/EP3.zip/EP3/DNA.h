#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

#pragma once
using namespace std;


void dist_max(long long n);

bool dfs_aux(int v, bool visited[],bool* recStack);

bool esta_em_circuito();

void encontra_equivalencias(string u, long long i);

void reconstroi_DNA();