#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "DNA.h"

using namespace std;
#define TAM 1000000 //Tamanho separado para os vetores/arrays

long long V,k_param,maior_equivalencia;
char nome_arq[1000];
long long tab[TAM];
long long entra[TAM],sai[TAM];
vector<string> fragmentos;
vector<long long> adj[TAM];
vector<long long> entradas,saidas;
vector<pair<long long,long long>> tmp[TAM];
map<pair<long long,long long>,long long> pesos;
long long resp[TAM];
string palavras_resp;





//Funcao para encontrar o caminho maximo no grafo formado
void dist_max(long long n){
    long long m,o,i,j,d,dist_max=0,param=0;
    long long melhorfim=0,indicei,indicef;
    long long inf=0,tmp,k,w,tam=0;
    long long vis[TAM];

    //Encontra as possiveis entradas e saidas para o caminho do grafo 
    for(i=0;i<V;i++){
        if(entra[i]==0){
            entradas.push_back(i);
        }
        if(sai[i]==0){
            saidas.push_back(i);
        }
    }

    //Testa os valores entre as possiveis entradas e saidas
    melhorfim=0;
    for(m=0;m<entradas.size();m++){
        long long inf=0,tmp,k,w,tam=0;
        long long vis[TAM];
        for(i=0;i<=n;i++){
            vis[i]=inf;
            tab[i]=inf;
        }

        priority_queue<long long>fila;
        fila.push(entradas[m]);
        while(!fila.empty()){
            tmp=fila.top();
            fila.pop();
            for(i=0;i<adj[tmp].size();i++){
                k=adj[tmp][i];
                w=pesos[{tmp,k}];
                if(vis[tmp]+w<vis[k]){
                    vis[k]=vis[tmp]+w;
                    tab[k]=tmp;
                    fila.push(k);
                }
            }
        }
        
        for(o=0;o<saidas.size();o++){
            if(vis[saidas[o]]!=0 || tab[saidas[o]]!=0){
                if(melhorfim>vis[saidas[o]]){
                    //Salva o melhor caminho e seus indices
                    melhorfim=vis[saidas[o]];
                    indicei=m;
                    indicef=o;
                }
            }
        }
    }

    //Com os indices do melhor caminho, agora salva o caminho para gerar o DNA final
    for(i=0;i<=n;i++){
        vis[i]=inf;
        tab[i]=inf;
    }

    priority_queue<long long>fila;
    m=entradas[indicei];
    fila.push(m);
    while(!fila.empty()){
        tmp=fila.top();
        fila.pop();
        for(i=0;i<adj[tmp].size();i++){
            k=adj[tmp][i];
            w=pesos[{tmp,k}];
            if(vis[tmp]+w<vis[k]){
                vis[k]=vis[tmp]+w;
                tab[k]=tmp;
                fila.push(k);
            }
        }
    }


    o=saidas[indicef];

    cout<<endl<<endl;
    if(vis[o]==inf && tab[o]==0){
        cout<<"Não foi possível encontrar uma resposta :( \n\n";//Imprime caso algum erro aconteça
    }
    else{
        //Salva o caminho em resp[]
        tmp=saidas[indicef];
        while(tmp!=entradas[indicei]){
            resp[tam]=tmp;
            tam++;
            tmp=tab[tmp];
        }
        resp[tam]=tmp;
        tam++;

        //Salva o DNA
        long long min,g=0;
        palavras_resp=fragmentos[resp[tam-1]];
        for(i=tam-1;i>0;i--){
            g=0;
            for(j=0;j<palavras_resp.size();j++){
                g=0;
                while(palavras_resp[j]==fragmentos[resp[i-1]][g] && j<palavras_resp.size()){
                    j++;
                    g++;
                }
                if(g!=0 && j<palavras_resp.size()){
                    j--;
                }
            }
            min=g;
            for(j=min;j<fragmentos[resp[i-1]].size();j++){
                palavras_resp=palavras_resp+fragmentos[resp[i-1]][j];
            }    
        }

        cout<<"O DNA do caminho maximo do grafo formado: "<<palavras_resp<<endl;
        cout<<"Tamanho do DNA reconstruido encontrado: "<<palavras_resp.size()<<endl;
        
    }
    cout<<endl;
}





//Funcao dfs auxiliar
bool dfs_aux(int v, bool visitado[],bool* pilha){
	if (visitado[v] == false) {
		visitado[v] = true;
		pilha[v] = true;
		long long i;

		for (long long j = 0; j < adj[v].size(); ++j) {
			i=adj[v][j];
            if (!visitado[i] && dfs_aux(i, visitado, pilha)){
				    return true;
            }
			else if (pilha[i]){
				return true;
            }
		}
	}
	pilha[v] = false;
	return false;
}





//Funcao que usa dfs_aux para verificar a existencia de um circuito no grafo
bool esta_em_circuito(){
	bool* visitado;
	bool* pilha;
    visitado = new bool[V+10];
    pilha = new bool[V+10];

	for (int i = 0; i < V+5; i++) {
		visitado[i] = false;
		pilha[i] = false;
	}

	for (int i = 0; i < V; i++){
		if (!visitado[i] && dfs_aux(i, visitado, pilha)){
            return true;
        }
    }
	return false;
}





//Funcao que encontra os arcos com fragmentos que possuam no minimo k_param de equivalencias
void encontra_equivalencias(string u, long long n){
    long long i,j,k,erro=0,cnt;
    //O fragmento atual direciona para algum outro fragmento
    for(i=0;i<n;i++){
        for(j=0;j<u.size();j++){
            erro=0;
            cnt=0;
            if(u[j]==fragmentos[i][0]){//Encontra primeira equivalencia
                for(k=0;j<u.size() && k<fragmentos[i].size();k++,j++){
                    if(u[j]==fragmentos[i][k]){
                        cnt++;
                    }
                    else{
                        erro=1;
                        break;
                    }
                }

                if(cnt>=k_param && erro==0 && j==u.size()){
                    tmp[cnt].push_back(make_pair(n,i));//Salva o par u-v
                    if(maior_equivalencia<cnt){
                        maior_equivalencia=cnt;
                    }

                }
                else{
                    j=j-1;
                }
            }
        }
    }

    //Algum fragmento se direciona ao fragmento atual
    for(i=0;i<n;i++){
        for(j=0;j<fragmentos[i].size();j++){
            erro=0;
            cnt=0;
            if(u[0]==fragmentos[i][j]){//Encontra primeira equivalencia
                for(k=0;j<fragmentos[i].size() && k<u.size();k++,j++){
                    if(u[k]==fragmentos[i][j]){
                        cnt++;
                    }
                    else{
                        erro=1;
                        break;
                    }
                }

                if(cnt>=k_param && erro==0 && j==fragmentos[i].size()){
                    tmp[cnt].push_back(make_pair(i,n));//Salva o par u-v
                    if(maior_equivalencia<cnt){
                        maior_equivalencia=cnt;
                    }
                }
                else{
                    j=j-1;
                }
            }
        }
    }
}





//Realiza a leitura dos fragmentos e ordena o programa
void reconstroi_DNA(){
    long long i,j,k,d,min;
    long long a,b;
    string u;
    min=LONG_LONG_MAX;
    vector<string> frag_tmp;
    maior_equivalencia=0;

    //Leitura
    cout<<endl<<"Insira o nome do arq para a leitura: ";
    cin>>nome_arq;
    ifstream f(nome_arq);

    if(f.fail()){
        cout<<"***** Falha de leitura!!! *****"<<endl;
        return;
    }

    f>>V;
    for(i=0;i<V;i++){
        f>>u;
        if(u.size()<=min){
            min=u.size();
        }
        frag_tmp.push_back(u);//salva os V fragmentos
    }


    //O parametro "k" para a realização de arcos
    //k_param=(min/2)+1;
    k_param=min; //para casos com V mais altos (V>1000)

    //Encontra os arcos considerando "k" equivalencias entre as palavras
    for(i=0;i<V;i++){
        fragmentos.push_back(frag_tmp[i]);
        encontra_equivalencias(fragmentos[i],i);
    }
    

    for(i=0;i<V;i++){
        for(j=0;j<V;j++){
            pesos[{i,j}]=0;
        }
    }


    //Verica quais arcos formaram o grafo
    for(i=maior_equivalencia;i>=k_param;i--){
        for(j=0;j<tmp[i].size();j++){
            set<long long> visitado;
            vector<long long> path;
            
            a=tmp[i][j].first;
            b=tmp[i][j].second;
            adj[a].push_back(b);
            //Verifica se há um circuito quando se adiciona esse arco
            if(esta_em_circuito() || pesos[{b,a}]<0){
                //Se sim, retiramos esse arco que será o arco com menor equivalencia do circuito
                adj[a].pop_back();
            }
            else{
                sai[a]++;
                entra[b]++;
                pesos[{a,b}]=-i;//Salvar o peso negativo
            }
        }
    }

    //Procura o caminho maximo
    dist_max(V);
    
}
