#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

#pragma once
using namespace std;

void dfs_b(long long node, long long dp[], bool vis[]);

long long dist_max_b();

bool esta_em_circuito_basico(long long u,long long n,set<long long> visited, vector<long long> path);

void leitura_basica(ifstream &f);

void funcoes_basicas();