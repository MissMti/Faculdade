#include <bits/stdc++.h>
#include "HeapCin.h"
using namespace std;
#define ll long long
#define MAX 50

int main(){
    ll x,y,n,i;
    double t,v,xn;

    vector<ll> identificadores;
    vector<double> xini;
    vector<double> velocidades;

    cin>>n;
    for(i=1;i<=n;i++){
        cin>>x>>y;
        identificadores.push_back(i);
        xini.push_back(x);
        velocidades.push_back(y);
    }

    KinHeap H(identificadores,xini,velocidades,n);

    while(cin>>n){
        if(n==1){
            cin>>t;
            H.Advance(t);
        }
        if(n==2){
            cin>>i>>v;
            H.Change(i,v);
        }
        if(n==3){
            cin>>i>>xn>>v;
            H.Insert(i,xn,v);
        }
        if(n==4){
            cout<<H.Max()<<endl;
        }
        if(n==5){
            H.DeleteMax();
        }
        if(n==6){
            cin>>i;
            H.Delete(i);
        }
        if(n==7){
            H.Print();
        }
    }


    return 0;
}