#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "HeapCin.h"
using namespace std;
#define INF INT64_MAX
#define ll long long




bool sortsecond(pair<ll,double> &a,pair<ll,double> &b){//Para sortear pelo segundo elemento do pair(prazos)
    return (a.second < b.second || (a.second==b.second && a.first<b.first));
}


KinHeap::KinHeap(vector<ll> id, vector<double> xi, vector<double> speed, long long num){
    ll i;
    elementos tmp;
    pair<ll,double> prv;

    this->n=num;
    this->now=0;

    tmp.id=INF;
    tmp.v=INF;
    tmp.xi=INF;
    H.push_back(tmp);

    for(i=0;i<num;i++){
        TS_um[id[i]]=i+1;
        tmp.id=id[i];
        tmp.v=speed[i];
        tmp.xi=xi[i];
        this->H.push_back(tmp);
    }

    for(i=2;i<=num;i++){

        prv.first=i;

        if(H[i/2].v==H[i].v){
            if(H[i].xi>H[i/2].xi){
                prv.second=0;
            }
            else{
                prv.second=INF;
            }
        }
        else{
            prv.second=(H[i].xi-H[i/2].xi)/(H[i/2].v-H[i].v);
        }
        
        if(H[i].v<H[i/2].v && H[i].xi<=H[i/2].xi){
            prv.second=INF;
        }

        if(H[i].xi>H[i/2].xi){
            prv.second=0;
        }
        this->Q.push_back(prv);

    }

    sort(this->Q.begin(),this->Q.end(),sortsecond);
    Advance(this->now);
}


void KinHeap::Advance(double t){//Avança o tempo para o instante t
    if(this->n>0){
        while(this->Q[0].second<=t){//prazos
            this->now=Q[0].second;
            Event(Q[0].first,Q[0].second);
        }
    }
    
    this->now=t;
}


void KinHeap::Event(ll i, double t){//Para quando o certificado expira

    elementos tmp;
    tmp=this->H[i];
    this->H[i]=this->H[i/2];
    this->H[i/2]=tmp;

    TS_um[H[i].id]=i;
    TS_um[H[i/2].id]=i/2;

    if(i/2>1){
        Update(i/2);
    }
    
    Update(i);

    if(2*i<=this->n){
        Update(2*i);
    }
    if(2*i+1<=this->n){
        Update(2*i+1);
    }

    ll s;
    s=get_sibling(i);

    if(s>0){//tem irmao?
        Update(s);
    }

}

void KinHeap::Update(ll i){//recalcula o certificado entre i/2 e i e atualiza Q de acordo
    double virada;
    if(H[i/2].v-H[i].v==0){
        if(H[i].xi>H[i/2].xi){
                virada=0;
        }
        else{
            virada=INF;
        }
    }
    else{
        virada=(double)(H[i].xi-H[i/2].xi)/(H[i/2].v-H[i].v);
    }

    if(H[i].v<H[i/2].v && H[i].xi+H[i].v*this->now<=H[i/2].xi+H[i/2].v*this->now){
        virada=INF;
    }

    if(H[i].xi+H[i].v*this->now>H[i/2].xi+H[i/2].v*this->now){
        virada=-virada;
    }

    //aplica no Q
    ll ind=this->TS_dois[i];
    Q[ind].second=virada;

    //atualiza o Q
    sort(this->Q.begin(),this->Q.end(),sortsecond);

    //atualiza os outros/atualiza TS_dois
    for(ll j=0;j<this->n-1;j++){
        TS_dois[Q[j].first]=j;
    }

}






//Consultas
ll KinHeap::Max(){
    return H[1].id;
}







//Mudança
void KinHeap::Change(ll id, double vel){
    H[TS_um[id]].xi=H[TS_um[id]].xi+(H[TS_um[id]].v-vel)*this->now;
    H[TS_um[id]].v=vel;
}

void KinHeap::Insert(ll id, double x_atual, double vel){
    ll i;

    double xi=x_atual-vel*this->now;

    this->n++;

    this->TS_um[id]=this->n;

    elementos tmp;
    tmp.id=id;
    tmp.v=vel;
    tmp.xi=xi;
    this->H.push_back(tmp);

    pair<ll,double> prv;

    prv.first=this->n;
    i=this->n;
    if(H[i/2].v==H[i].v){
        if(H[i].xi>H[i/2].xi){
            prv.second=0;
        }
        else{
            prv.second=INF;
        }
    }
    else{
        prv.second=(H[i].xi-H[i/2].xi)/(H[i/2].v-H[i].v);
    }
        
    if(H[i].v<H[i/2].v && H[i].xi+H[i].v*this->now<=H[i/2].xi+H[i/2].v*this->now){
        prv.second=INF;
    }

    if(H[i].xi+H[i].v*this->now>H[i/2].xi+H[i/2].v*this->now){
        prv.second=-prv.second;
    }

    this->Q.push_back(prv);

    sort(this->Q.begin(),this->Q.end(),sortsecond);

    i=i-1;

    TS_dois[Q[i].first]=i;

    Advance(this->now);
}

void KinHeap::Delete(ll id){
    ll pos=this->TS_um[id];

    ll i;

    //se for o proprio n

    elementos tmp=H[pos];
    H[pos]=H[this->n];
    H[this->n]=tmp;

    TS_um[H[pos].id]=pos;

    TS_um.erase(H[this->n].id);


    H.pop_back();

    
    pair<ll,double> prv;

    prv=Q[TS_dois[this->n]];
    Q[TS_dois[this->n]]=Q[this->n-2];
    Q[this->n-2]=prv;

    Q.pop_back();

    TS_dois.erase(this->n); 

    this->n--;


    i=pos;
    if(i/2>1){
        Update(i/2);
    }
    
    if(i>1){
        Update(i);
    }
    if(2*i<this->n){
        Update(2*i);
    }
    if(2*i+1<this->n){
        Update(2*i+1);
    }

    ll s;
    s=get_sibling(i);

    if(s>0){//tem irmao?
        Update(s);
    }

    sort(this->Q.begin(),this->Q.end(),sortsecond);

    if(pos>1){
        TS_dois[Q[pos].first]=pos;//pos em h pos em Q
    }

    Advance(this->now);

}

void KinHeap::DeleteMax(){
    Delete(Max());
}





//Impressoes
void KinHeap::PrintRec(elementos r, long long i, long long ref){
    if (ref<=this->n){
        PrintRec(get_esq(ref),i+3,ref*2);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        cout << r.v*this->now+r.xi << " ("<<r.xi<<" "<<r.v<<")"<<endl;
        PrintRec(get_dir(ref),i+3,ref*2+1);
	}
}

void KinHeap::Print(){
    long long i=0;
    PrintRec(this->H[1],i,1);

    return;
}




//Funcoes Auxiliares
elementos KinHeap::get_pai(ll r){
    return this->H[r/2];
}

elementos KinHeap::get_esq(ll r){
    return this->H[2*r];
}

elementos KinHeap::get_dir(ll r){
    return this->H[2*r+1];
}

ll KinHeap::get_sibling(ll i){
    if((i/2)*2==i){//i eh filho esq
        if(i+1<=this->n){
            return i+1;
        }
        return 0;
    }
    else{//i eh filho dir
        return (i/2)*2;
    }
}
