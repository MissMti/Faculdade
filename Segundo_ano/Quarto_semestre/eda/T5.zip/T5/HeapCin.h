#include <bits/stdc++.h>
#pragma once
using namespace std;
#define ll long long

struct elementos{
  ll id;
  double v;
  double xi;
};

class KinHeap{
  private:

    ll n;
    double now;

    unordered_map <ll,ll> TS_um;//id e pos em H
    unordered_map <ll,ll> TS_dois;//pos i em H e pos em Q

    vector<elementos> H;//max heap
    vector<pair<ll,double>> Q;//min heap

  public:

    KinHeap(vector<ll> id, vector<double> xi, vector<double> speed, long long num);

    elementos get_pai(ll r);
    elementos get_esq(ll r);
    elementos get_dir(ll r);
    ll get_sibling(ll i);

    void Advance(double t);
    void Event(ll i, double t);
    void Update(ll i);
    ll Max();
    void Change(ll id, double vel);
    void Insert(ll id, double x_atual, double vel);
    void Delete(ll id);
    void DeleteMax();

    void Print();
    void PrintRec(elementos r, long long i, long long ref);

};