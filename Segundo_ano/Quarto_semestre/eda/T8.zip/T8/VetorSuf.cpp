#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "VetorSuf.h"
using namespace std;
#define ll long long


//Pre-Processamento
node newNode(ll i, string w){
    node tmp;
    tmp.ind=i;
    tmp.trecho=w;
    return tmp;
}

bool cmp_ord(node a, node b){
    if(a.trecho<b.trecho){
        return true;
    }
    return false;
}

pair<vector<ll>,vector<ll>> LRLCP(vector<ll> w,ll i,ll j,ll side,vector<ll> LLCP, vector<ll> RLCP){
    ll valor,m;
    pair<vector<ll>,vector<ll>> tmp;

    if(i==j-1){
        valor=w[j];
    }
    else{
        m=(i+j)/2;
        tmp=LRLCP(w,i,m,i,LLCP,RLCP);
        LLCP=tmp.first;
        RLCP=tmp.second;
        tmp=LRLCP(w,m,j,j,LLCP,RLCP);
        LLCP=tmp.first;
        RLCP=tmp.second;
        valor=min({LLCP[m],RLCP[m]});
    }

    if(side==i){
        LLCP[j]=valor;
    }

    if(side==j){
        RLCP[i]=valor;
    }

    return make_pair(LLCP,RLCP);
}

VS::VS(string Texto){
    //Texto
    this->T=Texto;
    Texto=Texto+"$";
    

    ll tam=Texto.size(),i;
    vector<node> v;
    string p;
    node tmp;

    //vetor de sufixos
    for(i=0;i<tam;i++){
        p=Texto.substr(i,Texto.size()-i);
        tmp=newNode(i,p);
        v.push_back(tmp);
    }

    sort(v.begin(),v.begin()+i,cmp_ord);//ordena pelos sufixos

    this->vet=v;
    
    //vetor lcp
    vector <ll> w;//"normal"
    ll k;

    w.push_back(0);

    for(i=0;i<tam-1;i++){
        k=0;
        while(v[i].trecho[k]==v[i+1].trecho[k]){
            k++;
        }
        w.push_back(k);
    }

    this->LCP=w;

    //construcao do llcp e rlcp
    vector<ll> a,b;
    pair<vector<ll>,vector<ll>> par;

    for(i=0;i<tam;i++){
        a.push_back(0);
        b.push_back(0);
    }

    par = LRLCP(w,0,tam-1,0,a,b);

    this->LLCP=par.first;
    this->RLCP=par.second;

}


//Busca
pair<bool,ll> compa(ll l, ll M, vector<node> v, string P){
    ll tmp=l;
    while(P[tmp]==v[M].trecho[tmp]){
        tmp++;
    }
    if(tmp==P.size() || P[tmp]<v[M].trecho[tmp]){
        return make_pair(true,tmp);
    }
    return make_pair(false,tmp);
}

bool busca(string P, ll L, ll R,ll l, ll r,vector<node> v,vector<ll> lcp,vector<ll> llcp,vector<ll> rlcp){
    ll M;
    pair<bool,ll> medida;
    while(L<R-1){
        M=(L+R)/2;
        if(l==r){
            medida=compa(l,M,v,P);
            if(medida.first){//P<M
                R=M;
                r=medida.second;
            }
            else{
                L=M;
                l=medida.second;
            }
        }
        else{if(l>r){
            if(l<llcp[M]){
                L=M;
            }
            else{
                if(l>llcp[M]){
                    R=M;
                    r=llcp[M];
                }
                else{
                    medida=compa(l,M,v,P);
                    if(medida.first){//P<M
                        R=M;
                        r=medida.second;
                    }
                    else{
                        L=M;
                        l=medida.second;
                    }
                }
            }
        }
        else{
            if(r<rlcp[M]){
                R=M;
            }
            else{
                if(r>rlcp[M]){
                    L=M;
                    l=rlcp[M];
                }
                else{
                    medida=compa(r,M,v,P);
                    if(medida.first){//P<M
                        R=M;
                        r=medida.second;
                    }
                    else{
                        L=M;
                        l=medida.second;
                    }
                }
            }
        }
        }
    }

    //verifica
    if(l==P.size()||r==P.size()){
        return true;
    }
    return false;
}

bool VS::Search(string P){
    string T=this->T+"$";
    return busca(P,0,this->T.size()-1,0,0,this->vet,this->LCP,this->LLCP,this->RLCP);
}


//Auxiliares
pair<bool,ll> cmp(ll l, ll M, vector<node> v, string P){
    ll tmp=l;
    while(P[tmp]==v[M].trecho[tmp]){
        tmp++;
    }
    if(tmp==P.size()){
        return make_pair(false,tmp);
    }
    if(P[tmp]<v[M].trecho[tmp]){
        return make_pair(true,tmp);
    }
    return make_pair(false,tmp);
}

pair<ll,ll> sucessor(ll x, ll M, vector<node> v, string P){
    ll tmp=x;
    while(P[tmp]==v[M].trecho[tmp]){
        tmp++;
    }
    if(tmp>0){
        if(tmp==P.size() && v[M].trecho.size()-1==P.size()){
            return make_pair(M,tmp);
        }
        if(tmp==P.size()){
            return make_pair(-1,tmp);
        }
        if(v[M].trecho[tmp]>P[tmp]){
            return make_pair(-1,tmp);
        }
        return make_pair(-2,tmp);
        
    }
    else{
        if(v[M].trecho[0]>P[0]){
            return make_pair(-1,tmp);
        }
        return make_pair(-2,tmp);
    }
}


//Predecessor e Sucessor
ll search_predecessor(string P, string T, vector<node> v,vector<ll> lcp,vector<ll> llcp,vector<ll> rlcp){
    ll rsp;
    //verifica se a resposta é o último sufixo de T
    string ult=v[T.size()-1].trecho;
    ll s=v[T.size()-1].ind,r=0,l=0;

    while(r<P.size() && P[r]==T[s+r]){
        r=r+1;
    }

    if(r==P.size() || P[r]>T[s+r]){
        return T.size();
    }

    //Caso contrario
    ll L=0,R=T.size()-1,M;
    pair<ll,ll> medida;

    while(L<R-1){
        M=(L+R)/2;
        if(l==r){
            medida=sucessor(l,M,v,P);
            if(medida.first==-2){//P<M
                L=M;
                l=medida.second;
            }
            else{
                if(medida.first==-1){
                    R=M;
                    r=medida.second;
                }
                else{
                    L=medida.first;
                    R=L;
                }
                
            }
        }
        else{
            if(l>r){
                if(l<llcp[M]){
                    L=M;
                }
                else{
                    if(l>llcp[M]){
                        R=M;
                        r=llcp[M];
                    }
                    else{
                        medida=sucessor(l,M,v,P);
                        if(medida.first==-2){//P<M
                            L=M;
                            l=medida.second;
                        }
                        else{
                            if(medida.first==-1){
                                R=M;
                                r=medida.second;
                            }
                            else{
                                L=medida.first;
                                R=L;
                            }
                            
                        }
                    }
                }
            }
            else{
                if(r<rlcp[M]){
                    R=M;
                }
                else{
                    if(r>rlcp[M]){
                        L=M;
                        l=rlcp[M];
                    }
                    else{
                        medida=sucessor(l,M,v,P);
                        if(medida.first==-2){//P<M
                            L=M;
                            l=medida.second;
                        }
                        else{
                            if(medida.first==-1){
                                R=M;
                                r=medida.second;
                            }
                            else{
                                L=medida.first;
                                R=L;
                            }
                            
                        }
                    }
                }
            }
        }
    }
    return R;
}

ll search_sucessor(string P, string T, vector<node> v,vector<ll> lcp,vector<ll> llcp,vector<ll> rlcp){
    //verifica se a resposta é o último sufixo de T
    string ult=v[T.size()-1].trecho;
    ll s=v[T.size()-1].ind,r=0;

    while(r<P.size() && P[r]==T[s+r]){
        r=r+1;
    }

    if(r==P.size() || P[r]>T[s+r]){
        return T.size();
    }

    //Caso contrário
    ll L=0,l=0,R=T.size()-1,M;
    pair<bool,ll> medida;

    while(L<R-1){
        M=(L+R)/2;
        if(l==r){
            medida=cmp(l,M,v,P);
            if(medida.first){//P<M
                R=M;
                r=medida.second;
            }
            else{
                L=M;
                l=medida.second;
            }
        }
        else{
            if(l>r){
                if(l<llcp[M]){
                    L=M;
                }
                else{
                    if(l>llcp[M]){
                        R=M;
                        r=llcp[M];
                    }
                    else{
                        medida=cmp(l,M,v,P);
                        if(medida.first){//P<M
                            R=M;
                            r=medida.second;
                        }
                        else{
                            L=M;
                            l=medida.second;
                        }
                    }
                }
            }
            else{
                if(r<rlcp[M]){
                    R=M;
                }
                else{
                    if(r>rlcp[M]){
                        L=M;
                        l=rlcp[M];
                    }
                    else{
                        medida=cmp(r,M,v,P);
                        if(medida.first){//P<M
                            R=M;
                            r=medida.second;
                        }
                        else{
                            L=M;
                            l=medida.second;
                        }
                    }
                }
            }
        }
    }

    return R;
}


//Ocorrencias
void VS::Occurrences(string P){ //lista de posição em que P aparece em T
    ll x,y,i;
    string T=this->T+"$";
    x=search_predecessor(P, T, this->vet,this->LCP,this->LLCP,this->RLCP);
    y=search_sucessor(P, T, this->vet,this->LCP,this->LLCP,this->RLCP);

    for(i=x;i<y;i++){
        cout<<this->vet[i].ind<<" ";
    }
    cout<<endl;
}


//NOcorrencias
ll VS::NOccurrences(string P){ //número de ocorrências de P em T
    ll rsp,x,y;
    string T=this->T+"$";
    x=search_predecessor(P, T, this->vet,this->LCP,this->LLCP,this->RLCP);
    y=search_sucessor(P, T, this->vet,this->LCP,this->LLCP,this->RLCP);
    rsp=y-x;
    return rsp;
} 


//Impressao
void VS::Print(){
    ll i,tam=this->T.size()+1;
    cout<<this->T<<endl;
    cout<<"VS: ";
    for(i=0;i<tam;i++){
        cout<<this->vet[i].ind<<" ";
    }
    cout<<"\n";

    cout<<"LCP: ";
    for(i=1;i<tam;i++){
        cout<<this->LCP[i]<<" ";
    }
    cout<<"\n";
}