#include <bits/stdc++.h>
#pragma once
using namespace std;
#define ll long long

struct node{
    string trecho;
    ll ind;
};

class VS{
  private:
    string T;
    vector<node> vet;
    vector<ll> LCP;
    vector<ll> LLCP;
    vector<ll> RLCP;

  public:
    VS(string Texto); 
    
    vector<node> getvet();
    
    bool Search(string P); 
    void Occurrences(string P); 
    ll NOccurrences(string P); 
    void Print(); 
};


bool busca(string P, ll L, ll R,ll l, ll r,vector<node> v,vector<ll> lcp,vector<ll> llcp,vector<ll> rlcp);