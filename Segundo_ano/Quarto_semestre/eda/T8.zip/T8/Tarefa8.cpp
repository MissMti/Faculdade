#include <bits/stdc++.h>
#include "VetorSuf.h"
using namespace std;
#define ll long long

int main(){

    string T,nome_txt;
    ll n;
    cin>>n;
    //Pré-Processamento
    if(n==1){
        cin>>T; 
    }
    if(n==2){
        cin>>nome_txt;
        ifstream myfile(nome_txt);
        if(myfile.is_open()){
            while(getline(myfile,T)){};
        }
        myfile.close();
    }
    VS vsfx(T);
    string palavra;

    while(cin>>n){
        if(n==3){//Busca Simples
            cin>>palavra;
            bool rsp=vsfx.Search(palavra);
            if(rsp==1){
                cout<<"True\n";
            }
            else{
                cout<<"False\n";
            }
        }
        if(n==4){//Posicao(oes) da(s) ocorrencia(s)
            cin>>palavra;
            vsfx.Occurrences(palavra);
        }
        if(n==5){//Numero de ocorrencias
            cin>>palavra;
            cout<<vsfx.NOccurrences(palavra)<<endl;
        }
        if(n==6){//Imprime
            vsfx.Print();
        }
    }

    return 0;
}