#include <bits/stdc++.h>
#pragma once
using namespace std;
#define ll long long

struct Noh{
    ll value;
    ll priority;
    ll altura;
    Noh* direita;
    Noh* esquerda;
};

class Trps{
    private:
        Noh* raiz;
        ll tam;
    public:
    Trps();
    Noh* get_raiz();
    void set_raiz(Noh* r);

    void Insert (Noh* r, ll x);

    Noh* rec_deleta (Noh* r, ll x);
    void Delete (Noh* r, ll x);

    pair<Noh*, Noh*> Split(Noh* t, ll x);

    Noh* Join(Noh* r1, Noh* r2);

    bool Search(Noh* raiz, ll x);

    ll Min(Noh* raiz);

    void Print(Noh* raiz);

};


