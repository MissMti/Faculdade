#include <bits/stdc++.h>
#pragma once
using namespace std;
#define ll long long

struct noh{
    ll chave;
    noh* pai;
    noh* esq;
    noh* dir;
};

class ST{ 
    private:
        noh* r;  
    public:
        ST();

        noh* get_r();
        void set_r(noh* raiz);

        pair<noh*, noh*> Split(noh* t, ll x);
        void Join(noh* r1, noh* r2);


        //Modificadoras
        void Insert(noh* r, ll x);
        void Delete(noh* r, ll x);

        //Consulta
        bool Search(noh* r, ll x);
        ll Min(noh* r);

        //Impressao
        void Print(noh* r);

};

