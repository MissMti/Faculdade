#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "SplayTree.h"
using namespace std;
#define ll long long


//Auxiliares
ST::ST(){
    this->r=nullptr;
}

noh* ST:: get_r(){
    return this->r;
}

void ST::set_r(noh* raiz){
    this->r=raiz;
}

noh* rot_esq(noh* a){
    noh* pai_a = a->pai;
    noh* b = a->dir;

    b->pai = pai_a;

    a->dir = b->esq;
    if(a->dir!=nullptr){
        a->dir->pai = a;
    }

    b->esq = a;
    a->pai = b;
    return b;
}

noh* rot_dir(noh* a){
    noh* pai_a = a->pai;
    noh* b = new noh;
    b=a->esq;

    b->pai = pai_a;

    a->esq = b->dir;
    if(a->esq!=nullptr){
        a->esq->pai = a;
    }

    b->dir = a;
    a->pai = b;
   
    return b;
}

noh* rot_esq_esq(noh* a){
    noh* pai_a = a->pai;

    noh* b = a->dir;
    noh* c = b->dir;

    a->dir = b->esq;
    if(a->dir!=nullptr){
        a->dir->pai=a;
    }

    b->esq = a;
    

    b->dir = c->esq;
    if(b->dir!=nullptr){
        b->dir->pai=b;
    }

    c->esq = b;
    c->pai = pai_a;
    b->pai =c;
    a->pai = b;
    return c;
}

noh* rot_dir_esq(noh* a){
    noh* pai_a = a->pai;

    noh* b = a->esq;
    noh* c = b->dir;

    a->esq = c->dir;
    if(a->esq!=nullptr){
        a->esq->pai=a;
    }

    b->dir = c->esq;
    if(b->dir!=nullptr){
        b->dir->pai=b;
    }

    

    c->esq = b;
    c->dir = a;
    c->pai = pai_a;
    a->pai = c;
    b->pai =c;
    
    return c;
}

noh* rot_esq_dir(noh* a){
    noh* pai_a = a->pai;

    noh* b = a->dir;
    noh* c = b->esq;

    a->dir = c->esq;
    if(a->dir!=nullptr){
        a->dir->pai=a;
    }

    b->esq = c->dir;
    if(b->esq!=nullptr){
        b->esq->pai=b;
    }
    c->esq = a;
    c->dir = b;
    
    
    c->pai = pai_a;
    a->pai = c;
    b->pai =c;
    
    return c;
}

noh* rot_dir_dir(noh* a){
    noh* pai_a = a->pai;

    noh* b = a->esq;
    noh* c = b->esq;

    a->esq = b->dir;
    if(a->esq!=nullptr){
        a->esq->pai=a;
    }

    b->dir = a;
    
    b->esq = c->dir;
    if(b->esq!=nullptr){
        b->esq->pai=b;
    }

    c->dir = b;

    c->pai = pai_a;
    b->pai =c;
    a->pai = b;
    
    return c;
}

noh* novo_noh(noh* r, ll x){
    noh* tmp;
    tmp = new noh;
    tmp->chave = x;
    tmp->pai = r;
    tmp->esq = nullptr;
    tmp->dir = nullptr;
    return tmp;
}

pair<noh*,noh*> Menor_dir(noh* r){//noh do menor a partir de r
    pair<noh*,noh*> rsp;
    if(r->esq==nullptr){
        if(r->dir==nullptr){
            return make_pair(nullptr,r->pai);
        }
        return make_pair(r->dir,r->pai);
    }
    else{
        rsp=Menor_dir(r->esq);
        r->esq=rsp.first;
        rsp.first=r;
        return rsp;
    }
}

pair<noh*,noh*> Maior_esq(noh* r){//noh do maior a partir de r
    pair<noh*,noh*> rsp;
    if(r->dir==nullptr){
        if(r->esq==nullptr){
            return make_pair(nullptr,r->pai);
        }
        return make_pair(r->esq,r->pai);
    }
    else{
        rsp=Menor_dir(r->dir);
        r->dir=rsp.first;
        rsp.first=r;
        return rsp;
    }
}

ll Menor(noh* r){//valor do menor a partir de r
    if(r->esq==nullptr){
        return r->chave;
    }
    else{
        return Menor(r->esq);
    }
}












//Splay
noh* Acha(noh* r, ll x){//acha noh de x ou o ultimo visitado na busca pelo x
    if(r->chave==x){
        return r;
    }
    else{
        if(r->chave<x){
            if(r->dir!=nullptr){
                return Acha(r->dir,x);
            }
            else{
                return r;
            }
        }   
        else{
            if(r->esq!=nullptr){
                return Acha(r->esq,x);
            }
            else{
                return r;
            }
        }
    }
}



noh* Splay(noh* r, ll x){
    //achar noh com x ou o ultimo visitado na busca pelo x
    noh* noh_x=Acha(r,x);

    //sobe com rotacao
    while(noh_x->pai!=nullptr){
        if(noh_x->pai->pai==nullptr){//filho da raiz
            if(noh_x->pai->chave>=noh_x->chave){
                noh_x->pai->esq=noh_x;
                noh_x=rot_dir(noh_x->pai);
            }
            else{
                noh_x->pai->dir=noh_x;
                noh_x=rot_esq(noh_x->pai);
            }
        }
        else{
            if(noh_x->pai->pai->chave>=noh_x->pai->chave){
                if(noh_x->pai->chave>=noh_x->chave){
                    noh_x->pai->esq=noh_x;
                    noh_x=rot_dir_dir(noh_x->pai->pai);
                }
                else{
                    noh_x->pai->dir=noh_x;
                    noh_x=rot_dir_esq(noh_x->pai->pai);      
                }
            }
            else{
                if(noh_x->pai->chave>=noh_x->chave){
                    noh_x->pai->esq=noh_x;
                    noh_x=rot_esq_dir(noh_x->pai->pai);
                }
                else{
                    noh_x->pai->dir=noh_x;
                    noh_x=rot_esq_esq(noh_x->pai->pai);
                }
            }

        }
    }
    return noh_x;
}







//Consultas
bool ST::Search(noh* r, ll x){
    if(r==nullptr){
        return false;
    }
    else{
        ll y=Acha(r,x)->chave;
        if(x==y){
            this->r=Splay(r,x);
            return true;
        }
        else{
            this->r=Splay(r,y);
            return false;
        }
    }
}


ll ST::Min(noh* r){
    ll x=Menor(r);
    this->r=Splay(r,x);
    return x;
}











//Split e Join
pair<noh*, noh*> ST::Split(noh* t, ll x){
    //procura e faz splay
    //Print(this->r);
    bool ver=Search(t,x);
    //Print(this->r);

    if(ver){//existe x
        noh* a=new noh;
        a=get_r();

        noh* b=new noh;
        b=get_r()->dir;

        b->pai=nullptr;
        a->dir=nullptr;

        return make_pair(a,b);
    }
    
    //separa
    noh* tmp=new noh;
    tmp=this->r->dir;
    this->r->dir=nullptr;
    return make_pair(this->r,tmp);
}

void ST::Join(noh* r1, noh* r2){
    //splay no menor da direita
    ll tmp=Menor(r2);
    noh* raiz=Splay(r2,tmp);
    //Print(raiz);

    //juntar ambos
    raiz->esq=r1;
    raiz->esq->pai=raiz;
    this->r=raiz;
}




//Modificadoras


noh* Aux_Insert(noh* r, ll x){
    if(x <= r->chave){ 
        if(r->esq==nullptr){
            r->esq = novo_noh(r,x);
        }
        else{
            r->esq = Aux_Insert(r->esq,x);
        }
			
	}
	else{ 
        if(r->dir==nullptr){
            r->dir = novo_noh(r,x);
        }
        else{
            r->dir = Aux_Insert(r->dir,x);
        }
	}
    return r;
}

void ST:: Insert(noh* r, ll x){
	if(r==nullptr){
        this->r=novo_noh(r,x);
        return;
    }

    if(Acha(r,x)->chave!=x){
        r=Aux_Insert(r, x);
    }   

    this->r=Splay(r,x);
}


void ST:: Delete(noh* raiz, ll x){
    pair<noh*,noh*> rsp;
    ll y;
    if(raiz!=nullptr){
        
        this->r=Splay(raiz,x);
        if(this->r->chave==x){
            pair<noh*, noh*> rsp;
            rsp=Split(this->r,x);
            //Print(rsp.first);
            //Print(rsp.second);
            rsp.first=rsp.first->esq;
            if(rsp.first!=nullptr){
                rsp.second=Splay(rsp.second,Menor(rsp.second));

                rsp.second->esq=rsp.first;
                rsp.second->esq->pai=rsp.second;
            }
            this->r=rsp.second;
            return;
        }
    }
}










//Impressao
void PrintRec(noh* n, ll i){
    if (n != nullptr){
        PrintRec(n->esq,i+3);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        
        cout << n->chave;
        /*if(n->pai!=nullptr){
            cout<<"("<<n->pai->chave<<")";
            if(n->pai->pai!=nullptr){
                cout<<"("<<n->pai->pai->chave<<")";
            }
        }*/
        
        cout<<endl;
        PrintRec(n->dir,i+3);
	}
}

void ST::Print(noh* r){
    noh* n;
    long long i=0;
    PrintRec(r,i);
	return;
}