#include <bits/stdc++.h>
#include "SplayTree.h"
using namespace std;
#define ll long long
#define MAX 50



int main(){
    ll x,n;
    ST S;
    

    while(cin>>n){
        /*if(n==0){
            return 0;
        }*/
        if(n==1){
            cin>>x;
            S.Insert(S.get_r(),x);
        }
        if(n==2){
            cin>>x;
            S.Delete(S.get_r(),x);
        }
        if(n==3){
            cin>>x;
            if(S.Search(S.get_r(),x)){
                cout<<"1"<<endl;
            }
            else{
                cout<<"0"<<endl;
            }
        }
        if(n==4){
            cout<<S.Min(S.get_r())<<endl;
        }
        if(n==5){
            cout<<endl;
            S.Print(S.get_r());
        }
        if(n==6){
            ST Sum,Sdois;
            pair<noh*, noh*> rsp;
            cin>>x;
            rsp=S.Split(S.get_r(),x);
            
            cout<<endl;
            Sum.set_r(rsp.first);
            Sum.Print(Sum.get_r());
            
            cout<<endl;
            Sdois.set_r(rsp.second);
            Sdois.Print(Sdois.get_r());
            

            S.Join(Sum.get_r(),Sdois.get_r());

        }
    
    }


    return 0;
}