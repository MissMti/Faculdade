#include <bits/stdc++.h>
#include "Treaps.h"
using namespace std;

int main(){
    long long q,i,n,t=0,x,k,tempo=1;
    Trps tr;

    while(cin>>n){
        /*if(n==0){
            return 0;
        }*/
        if(n==1){
            cin>>x;
            tr.Insert(tr.get_raiz(),x);
        }
        if(n==2){
            cin>>x;
            tr.Delete(tr.get_raiz(),x);
        }
        if(n==3){
            cin>>x;
            if(tr.Search(tr.get_raiz(),x)){
                cout<<"1"<<endl;
            }
            else{
                cout<<"0"<<endl;
            }
        }
        if(n==4){
            cout<<tr.Min(tr.get_raiz())<<endl;
        }
        if(n==5){
            cout<<endl;
            tr.Print(tr.get_raiz());
        }
        if(n==6){
            Trps trum,trdois;
            pair<Noh*,Noh*> raizes;

            cin>>x;
            raizes=tr.Split(tr.get_raiz(),x);

            cout<<endl;
            trum.set_raiz(raizes.first);
            trum.Print(trum.get_raiz());

            cout<<endl;
            trdois.set_raiz(raizes.second);
            trdois.Print(trdois.get_raiz());

            tr.set_raiz(tr.Join(trum.get_raiz(),trdois.get_raiz()));

        }
    }
    return 0;
}