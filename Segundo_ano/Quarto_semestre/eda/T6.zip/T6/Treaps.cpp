#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "Treaps.h"
using namespace std;
#define ll long long


ll rand_num(){
    return rand()%2000;
}

Noh* NewNode(ll x){
    Noh* n;
    n=new Noh;
    n->value=x;
    n->priority=rand_num();
    n->direita=nullptr;
    n->esquerda=nullptr;
    return n;
}

Noh* rot_dir(Noh* r){
    Noh* k;
    k=new Noh;

    k = r->esquerda;
    r->esquerda = k->direita;
    k->direita = r;

    return k;
}

Noh* rot_esq(Noh* r){
    Noh* k;
    k=new Noh;
    
    k = r->direita;
    r->direita = k->esquerda;
    k->esquerda = r;

    return k;
}

Trps::Trps(){
    this->raiz=nullptr;
	this->tam=0;
    srand(time(NULL));
}

Noh* Trps::get_raiz(){
	return this->raiz;
}

void Trps::set_raiz(Noh* r){
	this->raiz=r;
}


pair<Noh*, Noh*> rec_split (Noh* t, ll x) {//soh r,x (parte recursiva)
	pair<Noh*, Noh*> rsp;
	if(t==nullptr){
		return make_pair(nullptr,nullptr);
	}
	if(x==t->value){
		Noh* s=t->direita;
		t->direita=nullptr;
		return make_pair(t,s);//first eh t e second eh oq fica depois nele, nao?
	}
	else{
		if (x < t->value){
			rsp=rec_split(t->esquerda,x);
			t->esquerda=rsp.second;
			rsp.second=t;
			return rsp;
		}
			
		else{
			rsp=rec_split(t->direita,x);
			t->direita=rsp.first;
			rsp.first=t;
			return rsp;
		}
	}

}

pair<Noh*, Noh*> Trps::Split(Noh* t, ll x){
	pair<Noh*, Noh*> rsp;

	if(t==nullptr){
		return make_pair(nullptr,nullptr);
	}

    if(t->value==x){
		Noh* s=t->direita;
		t->direita=nullptr;
		return make_pair(t,s);
	}

	rsp=rec_split(t,x);

	return rsp;
}


Noh* rec_Join(Noh* r1, Noh* r2){
	if (r1==nullptr || r2==nullptr){
        if(r1==nullptr){
            return r2;
        }
        if(r2==nullptr){
            return r1;
        }
    }
    else{
        if (r1->priority > r2->priority){
            r1->direita = rec_Join (r1->direita, r2);
			return r1;
        }
        else{
            r2->esquerda = rec_Join (r1, r2->esquerda);
        }
    }
	return r2;
}

Noh* Trps::Join(Noh* r1, Noh* r2){
	Noh* root=new Noh;
	root=rec_Join(r1,r2);

	return root;
}



void Trps::Insert (Noh* r, ll x){
    Noh* tmp;
    tmp=new Noh;
	pair<Noh*,Noh*> a;
	if(Search(r,x)){
		return;
	}

	a=Split(r,x);
	tmp=Join(a.first,NewNode(x));
	tmp=Join(tmp,a.second);

	this->raiz=tmp;
}




Noh* Trps::rec_deleta (Noh* r, ll x){
	if(r->value==x){
		r=Join(r->esquerda,r->direita);
	}
	else{
		if(r->value>x){
			r->esquerda=rec_deleta(r->esquerda,x);
		}
		else{
			r->direita=rec_deleta(r->direita,x);
		}
	}
	return r;
}

void Trps::Delete (Noh* r, ll x){
    Noh* tmp;
    tmp = new Noh;

	if(!Search(r,x)){
		return;
	}

	//encontro o noh com o x
	tmp=rec_deleta(r,x);

	this->raiz=tmp;
}

bool Trps::Search(Noh* raiz, ll x){
    if(raiz==nullptr){
        return false;
    }
    else{
        if(raiz->value==x){
            return true;
        }
        else{
            if(raiz->value<x){
                return Search(raiz->direita,x);
            }   
            else{
                return Search(raiz->esquerda,x);
            }
        }
    }
}

ll Trps::Min(Noh* raiz){ 
    if(raiz->esquerda==nullptr){
        return raiz->value;
    }
    else{
        return Min(raiz->esquerda);
    }
}

void PrintRec(Noh* n, ll i){
    if (n != nullptr){
        PrintRec(n->esquerda,i+3);
        for(ll j=0;j<i;j++){
            cout<<" ";
        }
        cout << n->value<<" "<<n->priority <<endl;
        PrintRec(n->direita,i+3);
	}
}


void Trps::Print(Noh* r){
    Noh* n;
    ll i=0;
    PrintRec(r,i);
	return;
}