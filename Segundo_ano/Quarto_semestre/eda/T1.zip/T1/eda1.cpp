#include <bits/stdc++.h>
#include "eda1.h"
using namespace std;

deq Deque(){
    deq d;
    d.ini[0] = nullptr;
    d.fim[0] = nullptr;
    d.qtd = 0;
    d.t = 0;
    return d;
}

deq PushFront(deq dq,long long x){
    deq d;
    noh node;
    d=dq;
    //if(dq.t==0){}
    
    
    return d;
}