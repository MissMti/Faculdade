#include <bits/stdc++.h>
#include "Deque.h"
using namespace std;

/*
//1 <t> <x> significa d_t+1 = PushFront(d_t, x) 
//2 <t> <x> significa d_t+1 = PushBack(d_t, x) 
//3 <t>     significa d_t+1 = PopFront(d_t) 
//4 <t>     significa d_t+1 = Popback(d_t) 
//5 <t>     significa println(Front(d_t))
//6 <t>     significa println(Back(d_t))
//7 <t> <k> significa println(Kth(d_t, k))
//8 <t>     significa Print(d_t)
*/


int main(){
    long long q,i,n,t=0,x,k;
    cin>>q;
    //deq dq[10];
    //dq[0]=Deque();

    for(i=0;i<q;i++){
        cin>>n;
        if(n==1){
            cout<<"Entrou: 1"<<endl;
            //1 <t> <x> significa d_t+1 = PushFront(d_t, x)
            cin>>t>>x;
            dq[t+1]=PushFront(dq[t],x);
        }
        if(n==2){
            cout<<"Entrou: 2"<<endl;
            //2 <t> <x> significa d_t+1 = PushBack(d_t, x)
            cin>>t>>x;
        }
        if(n==3){
            cout<<"Entrou: 3"<<endl;
            //3 <t>     significa d_t+1 = PopFront(d_t)
            cin>>t;
        }
        if(n==4){
            cout<<"Entrou: 4"<<endl;
            //4 <t>     significa d_t+1 = Popback(d_t)
            cin>>t;
        }
        if(n==5){
            cout<<"Entrou: 5"<<endl;
            //5 <t>     significa println(Front(d_t))
            cin>>t;
        }
        if(n==6){
            cout<<"Entrou: 6"<<endl;
            //6 <t>     significa println(Back(d_t))
            cin>>t;
        }
        if(n==7){
            cout<<"Entrou: 7"<<endl;
            //7 <t> <k> significa println(Kth(d_t, k))
            cin>>t>>k;
        }
        if(n==8){
            cout<<"Entrou: 8"<<endl;
            //8 <t>     significa Print(d_t)
            cin>>t;
        }
    }
    return 0;
}