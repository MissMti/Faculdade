#include <bits/stdc++.h>
#include "Deque.h"
using namespace std;


deq Deque(){
    deq d;
    d.ini=nullptr;
    d.fim=nullptr;
    return d;
}

void AddLeaf(noh* u){//Adiciona folha a arvore
    noh* v;
    v=new noh[5];
    v=u->pai;
    if(v->jump!=nullptr){
        if(v->jump->depth>1){//O pulo não pode ser raiz
            if(v->depth - v->jump->depth == v->jump->depth - v->jump->jump->depth){
                u->jump=v->jump->jump;
                return;
            }
        }
    }
    u->jump=v;//O pulo eh o pai do noh
}

noh* NewNode(long long x, noh* dad, long long profundidade){ //Cria novo noh e o insere na arvore
    noh* node;
    node=new noh[5];
    node->valor=x;
    node->pai=dad;
    node->depth=profundidade;
    if(dad!=nullptr){ //Soh chama se nao eh raiz
        AddLeaf(node);
    }
    return node;
}

deq Swap(deq dq){//Inverte a deque
    deq d;
    d.ini=dq.fim;
    d.fim=dq.ini;
    return d;
}

noh* LA(long long k, noh* u){//Encontra o k-esimo ancestral de u
    long long y;
    if(k>0){
        y=u->depth-k;
        while(u->depth!=y){
            if(u->jump->depth>=y){
                u=u->jump;
            }
            else{
                u=u->pai;
            }
        }
    }
    return u;
}

noh* LCA(noh* u, noh* v){//Encontra antecessor comum de u e v com maior profundidade
    noh* t;
    
    if (u->depth>v->depth){
        t=u;
        u=v;
        v=t;
    }
    
    v=LA(v->depth-u->depth,v);

    if (u==v){
        return u;
    }

    while(u->pai!=v->pai){
        if(u->jump!=v->jump){
            u=u->jump;
            v=v->jump;
        }
        else{
            u=u->pai;
            v=v->pai;
        }
    }

    return u->pai;
}

deq PushFront(deq dq,long long x){
    deq d;
    if (dq.ini==nullptr){
        d.ini=NewNode(x,nullptr,1);
        d.fim=d.ini;
    }
    else{
        d.ini=NewNode(x,dq.ini,(dq.ini->depth)+1);
        d.fim=dq.fim;
    }
    return d;
}

deq PushBack(deq dq,long long x){
    return Swap(PushFront(Swap(dq),x)); 
}

long long Front(deq dq){
    return dq.ini->valor;
}

long long Back(deq dq){
    return dq.fim->valor;
}

deq PopFront(deq dq){
    deq novo;
    noh* tmp;

    if(dq.ini==dq.fim){
        novo.ini=nullptr;
        novo.fim=nullptr;
        return novo;
    }

    novo=dq;

    tmp=new noh[5];
    tmp=LCA(dq.ini,dq.fim);

    if(tmp==dq.ini){
        novo.ini=LA(novo.fim->depth-novo.ini->depth-1,novo.fim);
    }
    else{
        novo.ini=novo.ini->pai;
    }
    return novo;
}

deq PopBack(deq dq){
    return Swap(PopFront(Swap(dq)));
}

long long Kth(deq dq,long long k){
    long long l1,l2;
    l1=dq.ini->depth-LCA(dq.ini,dq.fim)->depth;
    if(l1>=k-1){
        return LA(k-1,dq.ini)->valor;
    }
    l2=dq.fim->depth-LCA(dq.ini,dq.fim)->depth;
    return LA(l2-(k-1-l1),dq.fim)->valor;
}

void Print(deq dq){
    noh* atual;
    atual=new noh[5];
    long long l2;
    atual=dq.ini;
    if(dq.ini!=nullptr){
        while (dq.ini!=dq.fim && atual!=LCA(dq.ini,dq.fim)){
            cout<<atual->valor<<" ";
            atual=atual->pai;
        }
        cout<<atual->valor<<" ";
        l2=dq.fim->depth-atual->depth-1;
        
        while(l2>=0){
            cout<<LA(l2,dq.fim)->valor<<" ";
            l2--;
        }
    }
    cout<<endl;
}