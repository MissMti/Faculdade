#include <bits/stdc++.h>
#pragma once
using namespace std;

struct noh{
    noh* pai;
    long long depth;
    long long valor;
    noh* jump;
};

struct deq{
    noh* ini;
    noh* fim;
};


deq Deque();

deq PushFront(deq dq,long long x);

deq PushBack(deq dq,long long x);

deq PopFront(deq dq);

deq PopBack(deq dq);

long long Front(deq dq);

long long Back(deq dq);

long long Kth(deq dq, long long k);

void Print(deq d);