#include <bits/stdc++.h>
#pragma once
using namespace std;

/*
Interface:
Deque(): cria e devolve uma deque vazia
PushFront(d,x): insere x no extremo front de d
PushBack(d,x): insere x no extremo back de d
PopFront(d): remove o elemento no extremo front de d
PopBack(d): remove o elemento no extremo back de d
Front(d): devolve o elemento no extremo front de d
Back(d): devolve o elemento no extremo back de d
Kth(d,k): k-ésimo elemento de d, onde o front é o primeiro elemento de d
Print(d): imprime todos os elementos da deque d na mesma linha, separados por um branco
          (não precisa se preocupar com eventual espaço em branco no fim da linha)
*/

struct noh{
    noh* prox;
    noh* ante;
};

/*struct deq{
    noh* ini[10];
    noh* fim[10];
    int qtd;  
    int t;
};*/