#include <bits/stdc++.h>
#include "Deque.h"
#define MAX 10000
using namespace std;

int main(){
    long long q,i,n,t=0,x,k,tempo=1;
    deq dq[MAX]; //cria MAX deques

    dq[0]=Deque();//Cria e devolve o deque vazio

    while(cin>>n){
        cin>>t;
        if(n==1){//PushFront
            cin>>x;
            dq[tempo]=PushFront(dq[t],x);
            tempo++;
        }
        if(n==2){//PushBack
            cin>>x;
            dq[tempo]=PushBack(dq[t],x);
            tempo++;
        }
        if(n==3){//PopFront
            dq[tempo]=PopFront(dq[t]);
            tempo++;
        }
        if(n==4){//PopBack
            dq[tempo]=PopBack(dq[t]);
            tempo++;
        }
        if(n==5){//Front
            cout<<Front(dq[t])<<endl;
        }
        if(n==6){//Back
            cout<<Back(dq[t])<<endl;
        }
        if(n==7){//K-th
            cin>>k;
            cout<<Kth(dq[t],k)<<endl;
        }
        if(n==8){//Print da deque
            Print(dq[t]);
        }
    }
    return 0;
}