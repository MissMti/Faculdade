#include <bits/stdc++.h>
#pragma once
using namespace std;

struct Noh{
    long long value;
    long long priority;
    long long altura;
    Noh* direita;
    Noh* esquerda;
};

struct Trps{
    Noh* raiz;
};


Trps Treap();

Noh* Insert (Noh* r, long long x);

Noh* Delete (Noh* r, long long x);

bool Search(Noh* raiz, long long x);

long long Min(Noh* raiz);

void Print(Noh* raiz);