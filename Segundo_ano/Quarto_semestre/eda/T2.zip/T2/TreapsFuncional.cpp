#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "TreapsFuncional.h"
using namespace std;


long long rand_num(){
    
    return rand()%2000;
}

Noh* NewNode(long long x,long long h){
    Noh* n;
    n=new Noh[5];
    n->value=x;
    n->altura=h;
    n->priority=rand_num();
    n->direita=nullptr;
    n->esquerda=nullptr;
    return n;
}

Noh* rot_dir(Noh* r){
    Noh* k;
    k=new Noh[5];
    k = r->esquerda;
    r->esquerda = k->direita;
    k->direita = r;
    return k;
}

Noh* rot_esq(Noh* r){
    Noh* k;
    k=new Noh[5];
    k = r->direita;
    r->direita = k->esquerda;
    k->esquerda = r;
    return k;
}

Trps Treap(){
    Trps t;
    t.raiz=nullptr;
    srand(time(NULL));
    return t;
}

Noh* Add(Noh* tmp,Noh* r, Noh* raiz){
    raiz=new Noh;
    if(r==nullptr){
        return tmp;
    }
    if(r->priority > tmp->priority){
        raiz->value=r->value;
        raiz->priority=r->priority;
        if(r->value > tmp->value){
            raiz->direita=r->direita;
            raiz->esquerda=Add(tmp,r->esquerda,raiz->esquerda);
        }
        else{
            raiz->esquerda=r->esquerda;
            raiz->direita=Add(tmp,r->direita,raiz->direita);
        }
    }
    else{
        raiz->value=tmp->value;
        raiz->priority=tmp->priority;
        if(r->value<raiz->value){
            raiz->direita=nullptr;
            raiz->esquerda=r;
        }
        else{
            raiz->direita=r;
            raiz->esquerda=nullptr;
        }
    }

    return raiz;

}

Noh* Insert (Noh* r, long long x){
    Noh* tmp;
    Noh* raiz;
    tmp=new Noh;
    raiz=new Noh;
    tmp = NewNode(x,1);
    if(r==nullptr){
        return tmp;
    }
    raiz = Add(tmp,r,raiz);
    return raiz;
}

Noh* Take (long long x, Noh* r, Noh* raiz){
    raiz=new Noh;
    if(x<r->value){
        raiz->value=r->value;
        raiz->priority=r->priority;
        raiz->direita=r->direita;
        raiz->esquerda = Take(x,r->esquerda,raiz->esquerda);
    }
    else{
        if(x>r->value){
            raiz->value=r->value;
            raiz->priority=r->priority;
            raiz->esquerda=r->esquerda;
            raiz->direita = Take(x,r->direita,raiz->direita);
        }
        else{
            if(r->direita==nullptr || r->esquerda==nullptr){
                if(r->esquerda==nullptr){
                    raiz = r->direita;
                }
                else{
                    raiz = r->esquerda;
                }
                
            }
            else{
                if(r->esquerda->priority > r->direita->priority){
                    raiz->direita=Take(x,r->direita,raiz->direita);
                }
                else{
                    raiz = rot_esq(r);
                    raiz->esquerda=Take(x,r->esquerda,raiz->esquerda);
                }
            }
        }
    }
    return raiz;
}

Noh* Delete (Noh* r, long long x){
    Noh* raiz;
    raiz=new Noh;
    raiz = Take(x,r,raiz);
    return raiz;
}

bool Search(Noh* raiz, long long x){
    
    if(raiz==nullptr){
        return false;
    }
    else{
        if(raiz->value==x){
            return true;
        }
        else{
            if(raiz->value<x){
                return Search(raiz->direita,x);
            }   
            else{
                return Search(raiz->esquerda,x);
            }
        }
    }
}

long long Min(Noh* raiz){ 
    if(raiz->esquerda==nullptr){
        return raiz->value;
    }
    else{
        return Min(raiz->esquerda);
    }
}

void PrintRec(Noh* n, long long i){
    if (n != nullptr){
        PrintRec(n->esquerda,i+3);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        cout << n->value << " "<< n->priority<<endl;
        PrintRec(n->direita,i+3);
	}
}


void Print(Noh* r){
    Noh* n;
    long long i=0;
    PrintRec(r,i);
	return;
}