#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "TreapsFuncional.h"
#define MAX 10000
using namespace std;

int main(){
    long long q,i,n,t=0,x,k,tempo=1;
    Trps tr[MAX];

    tr[0]=Treap();

    while(cin>>n){
        cin>>t;
        if(n==1){
            cin>>x;
            tr[tempo].raiz=Insert(tr[t].raiz,x);
            tempo++;
        }
        if(n==2){
            cin>>x;
            tr[tempo].raiz=Delete(tr[t].raiz,x);
            tempo++;
        }
        if(n==3){
            cin>>x;
            if(Search(tr[t].raiz,x)){
                cout<<"1"<<endl;
            }
            else{
                cout<<"0"<<endl;
            }
        }
        if(n==4){
            cout<<Min(tr[t].raiz)<<endl;
        }
        if(n==5){
            Print(tr[t].raiz);
        }
    }
    return 0;
}