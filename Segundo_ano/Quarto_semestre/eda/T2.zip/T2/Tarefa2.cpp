#include <bits/stdc++.h>
#include "Treaps.h"
using namespace std;

int main(){
    long long q,i,n,t=0,x,k,tempo=1;
    Trps tr;

    tr=Treap();

    while(cin>>n){
        if(n==1){
            cin>>x;
            tr.raiz=Insert(tr.raiz,x);
        }
        if(n==2){
            cin>>x;
            tr.raiz=Delete(tr.raiz,x);
        }
        if(n==3){
            cin>>x;
            if(Search(tr.raiz,x)){
                cout<<"1"<<endl;
            }
            else{
                cout<<"0"<<endl;
            }
        }
        if(n==4){
            cout<<Min(tr.raiz)<<endl;
        }
        if(n==5){
            Print(tr.raiz);
        }
    }
    return 0;
}