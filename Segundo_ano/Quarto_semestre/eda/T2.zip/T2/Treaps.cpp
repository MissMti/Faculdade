#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "Treaps.h"
using namespace std;


long long rand_num(){
    return rand()%2000;
}

Noh* NewNode(long long x){
    Noh* n;
    n=new Noh[5];
    n->value=x;
    n->priority=rand_num();
    n->direita=nullptr;
    n->esquerda=nullptr;
    return n;
}

Noh* rot_dir(Noh* r){
    Noh* k;
    k=new Noh[5];

    k = r->esquerda;
    r->esquerda = k->direita;
    k->direita = r;

    return k;
}

Noh* rot_esq(Noh* r){
    Noh* k;
    k=new Noh[5];
    
    k = r->direita;
    r->direita = k->esquerda;
    k->esquerda = r;

    return k;
}

Trps Treap(){
    Trps t;
    t.raiz=nullptr;
    srand(time(NULL));
    return t;
}

Noh* Insert (Noh* r, long long x){
    Noh* tmp;
    tmp=new Noh[5];

	if(r==nullptr){
        return NewNode(x);
    }
	if(x <= r->value){ 
		r->esquerda = Insert(r->esquerda,x);
		if(r->esquerda->priority > r->priority){
            r = rot_dir(r);
        }			
	}
	else{ 
		r->direita = Insert(r->direita,x);
		if(r->direita->priority > r->priority){
            r = rot_esq(r);
        }
	}
    return r;
}

Noh* Delete (Noh* r, long long x){
    Noh* tmp;
    tmp = new Noh[5];
    if(x<r->value){
        r->esquerda = Delete(r->esquerda,x);
    }
    else{
        if(x>r->value){
            r->direita = Delete(r->direita,x);
        }
        else{
            
            if(r->direita==nullptr || r->esquerda==nullptr){
                if(r->esquerda==nullptr){
                    r = r->direita;
                }
                else{
                    r = r->esquerda;
                }
                
            }
            else{
                if(r->esquerda->priority > r->direita->priority){
                    r = rot_dir(r);
                    r->direita=Delete(r->direita,x);
                }
                else{
                    r = rot_esq(r);
                    r->esquerda=Delete(r->esquerda,x);
                }
            }
        }
    }

    return r;
}

bool Search(Noh* raiz, long long x){
    if(raiz==nullptr){
        return false;
    }
    else{
        if(raiz->value==x){
            return true;
        }
        else{
            if(raiz->value<x){
                return Search(raiz->direita,x);
            }   
            else{
                return Search(raiz->esquerda,x);
            }
        }
    }
}

long long Min(Noh* raiz){ 
    if(raiz->esquerda==nullptr){
        return raiz->value;
    }
    else{
        return Min(raiz->esquerda);
    }
}

void PrintRec(Noh* n, long long i){
    if (n != nullptr){
        PrintRec(n->esquerda,i+3);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        cout << n->value << " "<< n->priority<<endl;
        PrintRec(n->direita,i+3);
	}
}


void Print(Noh* r){
    Noh* n;
    long long i=0;
    PrintRec(r,i);
	return;
}