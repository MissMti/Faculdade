#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "STdinam.h"
using namespace std;




SegTreeDinam ASD(){//inicializa a AS dinamica vazia
    SegTreeDinam n;
    n.setn(0);
    n.setbits();
    return n;
}





//Auxiliares

long long maior_bin(long long i){//devolve maior potencia de 2 menor que i
    long long a=1;
    while(a<=i){
        a=a*2;
    }
    return a/2;
}

long long maior_bit(long long i){//devolve o bit mais significativo de i
    long long a=1,b=0;
    while(a<=i){
        a=a*2;
        b++;
    }
    b--;
    return b;
}

void SegTreeDinam::setn(long long x){
    this->n=x;
}

void SegTreeDinam::setbits(){
    long long i,m=this->n,rsp=0;
    for(i=0;i<15;i++){
        this->bits[i]=0;
    }
    while(m!=0){
        i=maior_bit(m);
        this->bits[i]=1;
        m=m-maior_bin(m);
    }
}






//Insert
void SegTreeDinam::Insert(long long s, long long f){
    long long i=0,j,k;    
    listadeseg* rsp=new listadeseg;
    rsp->prox=nullptr;
    listadeseg* tmp=new listadeseg;
    tmp->a=s;
    tmp->b=f;
    tmp->prox=nullptr;
    
    this->seg[this->n]=tmp;
    this-n++;

    if(this->bits[0]==0){
        this->bits[0]=1;
        this->arv[0].setraiz(nullptr);
        this->arv[0]=AS(tmp,1,this->n,this->n);
      
    }
    else{
        while(this->bits[i]!=0){
            this->bits[i]=0;
            i++;
        }

        this->bits[i]=1;

        for(j=n-1;j>=n-pow(2,i);j--){
            listadeseg* ant=new listadeseg;
            ant->a=this->seg[j]->a;
            ant->b=this->seg[j]->b;
            ant->prox=rsp;
            rsp=ant;
        }
        
        SegTreeStat x;
        x.setraiz(nullptr);
        this->arv[i]=AS(rsp,pow(2,i),n-pow(2,i)+1,n);
        for(k=0;k<2;k++){
            rsp=rsp->prox;
        }
    }

}




//Encontra segmentos
listacomseg SegTreeDinam::Segments(long long x){
    listacomseg rsp,tmp;
    rsp.qtd=0;
    long long m,i,j,k=0;
    m=this->n;
    
    while(m!=0){
        j=maior_bit(m);
        tmp=this->arv[j].Segments(x);
        for(i=0;i<tmp.qtd;i++){
            rsp.a[k]=tmp.a[i];
            k++;
            rsp.qtd++;
        }
        m=m-maior_bin(m);
    }

    return rsp;
}




//Printa

void SegTreeDinam::PrintADS(){
    long long i,m;
    m=this->n;
    cout<<endl<<endl;
    for(i=maior_bit(m);i>=0;i--){
        if(bits[i]==1){//aqui tem arv p/ printar
            this->arv[i].Print();
            cout<<endl<<endl;
        }
        
    }

}





























//Parte da AS stat

void printseg(listacomseg aux){
    long long i;
    listacomseg n;
    n=aux;
    for(i=0;i<aux.qtd;i++){
        cout<<aux.a[i]<<" ";
    }
}

void PrintRec(noh* aux, long long i){
    noh* n =new noh;
    n=aux;
    if (n != nullptr){
        PrintRec(n->esq,i+6);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        
        if(n->min_aberto){
            cout<<"(";
            if(n->min_inf){
                cout<<"-INF";
            }
            else{
                cout<<n->min;
            }
            cout<<",";
            if(n->max_inf){
                cout<<"INF";
            }
            else{
                cout<<n->max;
            }
            if(n->max_aberto){
                cout<<") ";
            }
            else{
                cout<<"] ";
            }
        }
        else{
            cout<<"[";
            if(n->min_inf){
                cout<<"-INF";
            }
            else{
                cout<<n->min;
            }
            cout<<",";
            if(n->max_inf){
                cout<<"INF";
            }
            else{
                cout<<n->max;
            }
            if(n->max_aberto){
                cout<<") ";
            }
            else{
                cout<<"] ";
            }
        }
        cout<<" ";
        printseg(n->segmentos);
        cout<<endl;
        PrintRec(n->dir,i+6);
    }
}

void SegTreeStat::Print(){
    long long i=1;
    noh* aux=new noh;
    aux=this->r;
    PrintRec(aux,i);//print da arvore
    cout<<endl;
	return;
}







//Montando a Árvore stat

void SegTreeStat::setraiz(noh* raiz){
    this->r=raiz;
}

long long contem(noh* x, listadeseg* y){//0nada, 1parcialmente, 2 contem
    if(y->a>x->min || y->b<x->max){
        return 1;
    }
    if(y->a<=x->min && y->b>=x->max){
        return 2;
    }
    return 0;
}

void andaARV(noh* arv,listadeseg* v, long long x){
    if(arv->esq!=nullptr){
        if(contem(arv->esq,v)>=1){
            if(contem(arv->esq,v)==2){
                arv->esq->segmentos.a[arv->esq->segmentos.qtd]=x;
                arv->esq->segmentos.qtd++;
            }
            else{
                andaARV(arv->esq,v,x);
            }
        }
    }
    if(arv->dir!=nullptr){
        if(contem(arv->dir,v)>=1){
            if(contem(arv->dir,v)==2){
                arv->dir->segmentos.a[arv->dir->segmentos.qtd]=x;
                arv->dir->segmentos.qtd++;
            }
            else{
                andaARV(arv->dir,v,x);
            }
        }
    }
}

long long bin(long long i){
    long long a=1;
    while(a<i){
        a=a*2;
    }
    return a/2;
}

SegTreeStat AS(listadeseg* S, long long g,long long ini,long long fim){
    listadeseg* T=new listadeseg;
    T=S;

    SegTreeStat ST;
    vector<long long> vt(MAX*2);
    vector<long long> v(MAX*2);
    long long i=0,j,f,k,l,m=0,n;


    //Pega todos os elementos da lista de segmentos e ordena eles.
    for(k=g;k>0;k--){
        vt[i]=T->a;
        i++;
        vt[i]=T->b;
        i++;
        T=T->prox;
    }

    sort(vt.begin(),vt.begin()+i);//nlogn
    

    //retira repetiçoes
    for(k=0;k<i;k++){
        v[m]=vt[k];
        while(vt[k]==vt[k+1]){
            k++;
        }
        m++;
    }
    n=i;
    i=m;

    

    
    //Numero de folhas e de nos da arvoore
    j=2*i+1;
    noh* arvo[2*j+5];

    //j folhas, 2j-1 noh totais

    long long binario_maior=bin(j);//referencia para contas



    //Passar as folhas para a arvoore

    //(j-binario_maior)*2 folhas mais a esquerda, estao no nivel mais longe da raiz

    f=2*j-(j-binario_maior)*2;
    arvo[f]=new noh;
    arvo[f]->min_inf=1;
    arvo[f]->min=-INT64_MAX;
    arvo[f]->max_inf=0;
    arvo[f]->max=v[0];
    arvo[f]->min_aberto=1;
    arvo[f]->max_aberto=1;
    arvo[f]->esq=nullptr;
    arvo[f]->dir=nullptr;
    arvo[f]->segmentos.qtd=0;


    l=0;
    for(k=f+1;k<=2*j-1;k=k+2){//impares
        arvo[k]=new noh;
        arvo[k]->min_inf=0;
        arvo[k]->min=v[l];
        arvo[k]->max_inf=0;
        arvo[k]->max=v[l];
        arvo[k]->min_aberto=0;
        arvo[k]->max_aberto=0;
        arvo[k]->esq=nullptr;
        arvo[k]->dir=nullptr;
        arvo[k]->segmentos.qtd=0;
        l++;
    }


    l=0;

    for(k=f+2;k<=2*j-1;k=k+2){//pares
        arvo[k]=new noh;
        arvo[k]->min_inf=0;
        arvo[k]->min=v[l];
        arvo[k]->max_inf=0;
        arvo[k]->max=v[l+1];
        arvo[k]->min_aberto=1;
        arvo[k]->max_aberto=1;
        arvo[k]->esq=nullptr;
        arvo[k]->dir=nullptr;
        arvo[k]->segmentos.qtd=0;
        l++;
    }

    //j-folhas mais a esquerda = folha mais a direita
    f=2*j-1-(j-binario_maior)*2;
    arvo[f]=new noh;
    arvo[f]->min_inf=0;
    arvo[f]->min=v[i-1];
    arvo[f]->max_inf=1;
    arvo[f]->max=INT64_MAX;
    arvo[f]->min_aberto=1;
    arvo[f]->max_aberto=1;
    arvo[f]->esq=nullptr;
    arvo[f]->dir=nullptr;
    arvo[f]->segmentos.qtd=0;

    m=l;
    l=l+1;
    for(k=j+1;k<f;k=k+2){//impares
        arvo[k]=new noh;
        arvo[k]->min_inf=0;
        arvo[k]->min=v[l];
        arvo[k]->max_inf=0;
        arvo[k]->max=v[l];
        arvo[k]->min_aberto=0;
        arvo[k]->max_aberto=0;
        arvo[k]->esq=nullptr;
        arvo[k]->dir=nullptr;
        arvo[k]->segmentos.qtd=0;
        l++;
    }


    l=m;
    for(k=j;k<f;k=k+2){//pares
        arvo[k]=new noh;
        arvo[k]->min_inf=0;
        arvo[k]->min=v[l];
        arvo[k]->max_inf=0;
        arvo[k]->max=v[l+1];
        arvo[k]->min_aberto=1;
        arvo[k]->max_aberto=1;
        arvo[k]->esq=nullptr;
        arvo[k]->dir=nullptr;
        arvo[k]->segmentos.qtd=0;
        l++;
    }


    //Subindo pelos nohs da arvoore
    for(m=j-1;m>=1;m--){
        arvo[m]=new noh;
        arvo[m]->esq=arvo[m*2];
        arvo[m]->dir=arvo[m*2+1];
        arvo[m]->min_inf=arvo[m*2]->min_inf;
        arvo[m]->min=arvo[m*2]->min;
        arvo[m]->min_aberto=arvo[m*2]->min_aberto;
        arvo[m]->max_inf=arvo[m*2+1]->max_inf;
        arvo[m]->max=arvo[m*2+1]->max;
        arvo[m]->max_aberto=arvo[m*2+1]->max_aberto;
        arvo[m]->segmentos.qtd=0;
    }



    //adicionar as listas de segmentos
    T=S;
    for(m=ini;m<=fim;m++){//verificar segmentos
        andaARV(arvo[1],T,m);
        T=T->prox;
    }


    ST.setraiz(arvo[1]);


    return ST;
}






//Pega os segmentos stat
listacomseg SegTreeStat::Segments(long long x){
    noh* tmp=new noh;
    noh* prv=new noh;
    listacomseg rsp;
    rsp.qtd=0;
    long long i;
    tmp=this->r;

    while(!(tmp->esq==nullptr && tmp->dir==nullptr)){//achou o t

        if(tmp->esq->max>x || (tmp->esq->max>=x && !tmp->esq->max_aberto)){
            prv=tmp->esq;
            for(i=0;i<prv->segmentos.qtd;i++){
                rsp.a[rsp.qtd]=prv->segmentos.a[i];
                rsp.qtd++;
            }
            tmp=tmp->esq;
        }
        else{
            prv=tmp->dir;
            for(i=0;i<prv->segmentos.qtd;i++){
                rsp.a[rsp.qtd]=prv->segmentos.a[i];
                rsp.qtd++;
            }
            tmp=tmp->dir;
        }
    }
    return rsp;
}

