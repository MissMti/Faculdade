#include <bits/stdc++.h>
#include "STstat.h"
using namespace std;



int main(){
    long long i,n,x,y,a,b;
    SegTree ST;

    listadeseg* segmentos=new listadeseg;
    segmentos->prox=new listadeseg;
    segmentos->prox=nullptr;

    cin>>n;

    for(i=0;i<n;i++){
        cin>>x>>y;
        listadeseg* tmp=new listadeseg;
        tmp->a=x;
        tmp->b=y;
        tmp->prox=segmentos;
        segmentos=tmp;
    }

    ST=AS(segmentos);

    while(cin>>n){
        if(n==1){
            cin>>x;
            listacomseg l;
            l=ST.Segments(x);
            if(l.qtd==0){
                cout<<"nenhum segmento";
            }
            else{
                printseg(l);
            }
            cout<<endl;
        }
        if(n==2){
            ST.Print();
        }
    }

    return 0;

}