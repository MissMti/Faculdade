#include <bits/stdc++.h>
#pragma once
using namespace std;
#define MAX 100
#define Max 20


struct listadeseg{
    long long a;
    long long b;
    listadeseg* prox;
};

struct listacomseg{
    long long a[MAX];
    long long qtd;
};

struct noh{
    bool min_aberto;
    bool max_aberto;
    bool min_inf;
    bool max_inf;
    long long min;
    long long max;

    noh* esq;
    noh* dir;

    listacomseg segmentos;
};

class SegTreeStat{
    private:
        noh* r;
    public:
        void setraiz(noh* raiz);
        void Print();
        listacomseg Segments(long long x);
};

class SegTreeDinam{
    private:
        SegTreeStat arv[Max];
        long long n;
        long long bits[Max];
        listadeseg* seg[MAX];

    public:
        void setn(long long x);
        void setbits();
        void Insert(long long s, long long f);
        void PrintADS();
        listacomseg Segments(long long x);
};

SegTreeDinam ASD();

void printseg(listacomseg aux);
SegTreeStat AS(listadeseg* S, long long x,long long ini, long long fim);