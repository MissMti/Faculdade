#include <bits/stdc++.h>
#pragma once
using namespace std;
#define MAX 100



struct listadeseg{
    long long a;
    long long b;
    listadeseg* prox;
};

struct listacomseg{
    long long a[MAX];
    long long qtd;
};

struct noh{
    bool min_aberto;
    bool max_aberto;
    bool min_inf;
    bool max_inf;
    long long min;
    long long max;

    noh* esq;
    noh* dir;

    listacomseg segmentos;
};

class SegTree{
    private:
        noh* r;
    public:
        void Print();
        void setraiz(noh* raiz);
        listacomseg Segments(long long x);
};

SegTree AS(listadeseg* S);

void printseg(listacomseg n);