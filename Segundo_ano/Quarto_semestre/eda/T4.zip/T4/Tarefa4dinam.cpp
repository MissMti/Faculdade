#include <bits/stdc++.h>
#include "STdinam.h"
using namespace std;



int main(){
    long long n,s,f,x;
    SegTreeDinam STD;
    STD=ASD();

    while(cin>>n){
        if(n==1){
            cin>>s>>f;
            STD.Insert(s,f);
        }
        if(n==2){
            cin>>x;
            listacomseg l;
            l=STD.Segments(x);
            if(l.qtd==0){
                cout<<"nenhum segmento";
            }
            else{
                printseg(l);
            }
            cout<<endl;
        }
        if(n==3){
            STD.PrintADS();
        }

    }

    return 0;

}