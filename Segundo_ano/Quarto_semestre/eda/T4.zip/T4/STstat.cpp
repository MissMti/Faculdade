#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "STstat.h"
using namespace std;




//Montando a Árvore
void SegTree::setraiz(noh* raiz){
    this->r=raiz;
}


long long contem(noh* x, listadeseg* y){//0nada, 1parcialmente, 2 contem
    if(y->a>x->min || y->b<x->max){
        return 1;
    }
    if(y->a<=x->min && y->b>=x->max){
        return 2;
    }
    return 0;
}

void andaARV(noh* arv,listadeseg* v, long long x){
    if(arv->esq!=nullptr){
        if(contem(arv->esq,v)>=1){
            if(contem(arv->esq,v)==2){
                arv->esq->segmentos.a[arv->esq->segmentos.qtd]=x;
                arv->esq->segmentos.qtd++;
            }
            else{
                andaARV(arv->esq,v,x);
            }
        }
    }
    if(arv->dir!=nullptr){
        if(contem(arv->dir,v)>=1){
            if(contem(arv->dir,v)==2){
                arv->dir->segmentos.a[arv->dir->segmentos.qtd]=x;
                arv->dir->segmentos.qtd++;
            }
            else{
                andaARV(arv->dir,v,x);
            }
        }
    }
}

long long bin(long long i){
    long long a=1;
    while(a<=i){
        a=a*2;
    }
    return a/2;
}

SegTree AS(listadeseg* S){
    listadeseg* T=new listadeseg;
    T=S;

    SegTree ST;
    vector<long long> vt(MAX*2);
    vector<long long> v(MAX*2);
    long long i=0,j,f,k,l,m=0,n;



    //Pega todos os elementos da lista de segmentos e ordena eles.
    while(T->prox!=nullptr){
        vt[i]=T->a;
        i++;
        vt[i]=T->b;
        i++;
        T=T->prox;
    }

    sort(vt.begin(),vt.begin()+i);
    

    //retira repetiçoes
    for(k=0;k<i;k++){
        v[m]=vt[k];
        while(vt[k]==vt[k+1]){
            k++;
        }
        m++;
    }
    n=i;
    i=m;


    //Numero de folhas e de nos da arvore
    j=2*i+1;

    noh arv[2*j+10];



    //j folhas, 2j-1 noh totais

    long long binario_maior=bin(j);//referencia para contas



    //Passar as folhas para a arvore

    //(j-binario_maior)*2 folhas mais a esquerda, estao no nivel mais longe da raiz

    f=2*j-(j-binario_maior)*2;
    arv[f].min_inf=1;
    arv[f].min=-INT64_MAX;
    arv[f].max_inf=0;
    arv[f].max=v[0];
    arv[f].min_aberto=1;
    arv[f].max_aberto=1;
    arv[f].esq=nullptr;
    arv[f].dir=nullptr;
    arv[f].segmentos.qtd=0;


    l=0;
    for(k=f+1;k<=2*j-1;k=k+2){//impares
        arv[k].min_inf=0;
        arv[k].min=v[l];
        arv[k].max_inf=0;
        arv[k].max=v[l];
        arv[k].min_aberto=0;
        arv[k].max_aberto=0;
        arv[k].esq=nullptr;
        arv[k].dir=nullptr;
        arv[k].segmentos.qtd=0;
        l++;
    }

    l=0;

    for(k=f+2;k<=2*j-1;k=k+2){//pares
        arv[k].min_inf=0;
        arv[k].min=v[l];
        arv[k].max_inf=0;
        arv[k].max=v[l+1];
        arv[k].min_aberto=1;
        arv[k].max_aberto=1;
        arv[k].esq=nullptr;
        arv[k].dir=nullptr;
        arv[k].segmentos.qtd=0;
        l++;
    }

    //j-folhas mais a esquerda = folha mais a direita
    f=2*j-1-(j-binario_maior)*2;

    arv[f].min_inf=0;
    arv[f].min=v[i-1];
    arv[f].max_inf=1;
    arv[f].max=INT64_MAX;
    arv[f].min_aberto=1;
    arv[f].max_aberto=1;
    arv[f].esq=nullptr;
    arv[f].dir=nullptr;
    arv[f].segmentos.qtd=0;

    m=l;
    l=l+1;
    for(k=j+1;k<f;k=k+2){//impares
        arv[k].min_inf=0;
        arv[k].min=v[l];
        arv[k].max_inf=0;
        arv[k].max=v[l];
        arv[k].min_aberto=0;
        arv[k].max_aberto=0;
        arv[k].esq=nullptr;
        arv[k].dir=nullptr;
        arv[k].segmentos.qtd=0;
        l++;
    }


    l=m;
    for(k=j;k<f;k=k+2){//pares
        arv[k].min_inf=0;
        arv[k].min=v[l];
        arv[k].max_inf=0;
        arv[k].max=v[l+1];
        arv[k].min_aberto=1;
        arv[k].max_aberto=1;
        arv[k].esq=nullptr;
        arv[k].dir=nullptr;
        arv[k].segmentos.qtd=0;
        l++;
    }

    //Subindo pelos nohs da arvore
    for(m=j-1;m>=1;m--){
        arv[m].esq=&arv[m*2];
        arv[m].dir=&arv[m*2+1];
        arv[m].min_inf=arv[m*2].min_inf;
        arv[m].min=arv[m*2].min;
        arv[m].min_aberto=arv[m*2].min_aberto;
        arv[m].max_inf=arv[m*2+1].max_inf;
        arv[m].max=arv[m*2+1].max;
        arv[m].max_aberto=arv[m*2+1].max_aberto;
        arv[m].segmentos.qtd=0;
    }

    

    //adicionar as listas de segmentos
    T=S;
    for(m=n/2;m>=1;m--){//verificar segmentos
        andaARV(&arv[1],T,m);
        T=T->prox;
    }

    ST.setraiz(&arv[1]);

    return ST;
}






//Pega os segmentos
listacomseg SegTree::Segments(long long x){
    noh* tmp=new noh;
    noh* prv=new noh;
    listacomseg rsp;
    rsp.qtd=0;
    long long i;
    tmp=this->r;

    while(!(tmp->esq==nullptr && tmp->dir==nullptr)){//achou o t

        if(tmp->esq->max>x || (tmp->esq->max>=x && !tmp->esq->max_aberto)){
            prv=tmp->esq;
            for(i=0;i<prv->segmentos.qtd;i++){
                rsp.a[rsp.qtd]=prv->segmentos.a[i];
                rsp.qtd++;
            }
            tmp=tmp->esq;
        }
        else{
            prv=tmp->dir;
            for(i=0;i<prv->segmentos.qtd;i++){
                rsp.a[rsp.qtd]=prv->segmentos.a[i];
                rsp.qtd++;
            }
            tmp=tmp->dir;
        }
    }
    return rsp;
}









//Prints

void printseg(listacomseg aux){
    long long i;
    listacomseg n;
    n=aux;
    for(i=0;i<aux.qtd;i++){
        cout<<aux.a[i]<<" ";
    }
}

void PrintRec(noh* aux, long long i){
    noh* n =new noh;
    n=aux;
    if (n != nullptr){
        PrintRec(n->esq,i+6);
        for(long long j=0;j<i;j++){
            cout<<" ";
        }
        
        if(n->min_aberto){
            cout<<"(";
            if(n->min_inf){
                cout<<"-INF";
            }
            else{
                cout<<n->min;
            }
            cout<<",";
            if(n->max_inf){
                cout<<"INF";
            }
            else{
                cout<<n->max;
            }
            if(n->max_aberto){
                cout<<") ";
            }
            else{
                cout<<"] ";
            }
        }
        else{
            cout<<"[";
            if(n->min_inf){
                cout<<"-INF";
            }
            else{
                cout<<n->min;
            }
            cout<<",";
            if(n->max_inf){
                cout<<"INF";
            }
            else{
                cout<<n->max;
            }
            if(n->max_aberto){
                cout<<") ";
            }
            else{
                cout<<"] ";
            }
        }
        cout<<" ";
        printseg(n->segmentos);
        cout<<endl;
        PrintRec(n->dir,i+6);
    }
}




void SegTree::Print(){
    long long i=1;
    noh* aux=new noh;
    aux=this->r;
    PrintRec(aux,i);//print da arvore
    cout<<endl;
	return;
}