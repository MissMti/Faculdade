#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include "PilhaR.h"
using namespace std;
#define PUSH 1
#define POP 0


//Inicializa
PilhaRetro retroStack(){
    PilhaRetro p;
    p.setraiz(nullptr);
    return p;
}


//Auxiliares
Noh* PilhaRetro::getraiz(){
    return this->raiz;
}

void PilhaRetro::setraiz(Noh* r){
    this->raiz=r;
}

long long rand_num(){
    return (rand()%2000)+1;//No min 1;
}

Noh* NewNode(long long op, long long tipo,long long x,long long tempo,Noh* dir,Noh* esq){
    Noh* n;
    n=new Noh;

    n->op=op;
    n->t=tempo;

    if(n->op){
        n->ehpush=tipo;
        n->priority=0;
        n->max=tempo;

        if(n->ehpush){
            n->value=x;
            n->sum=1;
            n->smax=1;
        }
        else{
            n->sum=-1;
            n->smax=0;
        }
        n->direita=dir;
        n->esquerda=esq;
    }
    else{
        n->priority=rand_num();
        n->sum=dir->sum+esq->sum;
        n->max=max(dir->t,esq->t);        

        if(dir->t>esq->t){
            n->direita=dir;
            n->esquerda=esq;
        }
        else{
            n->direita=esq;
            n->esquerda=dir;
        }

        n->smax=max(n->direita->smax,n->esquerda->smax+n->direita->sum);
    }

    return n;
}







//Atualiza
Noh* atualiza(Noh* r){
    if(r->esquerda->op==0){//atualiza esq
        r->esquerda->sum=r->esquerda->esquerda->sum + r->esquerda->direita->sum;
        r->esquerda->max=r->esquerda->direita->max;
        r->esquerda->smax=max(r->esquerda->direita->smax,r->esquerda->esquerda->smax+r->esquerda->direita->sum);
    }
    if(r->direita->op==0){//atualiza dir
        r->direita->sum=r->direita->esquerda->sum + r->direita->direita->sum;;
        r->direita->max=r->direita->direita->max;
        r->direita->smax=max(r->direita->direita->smax,r->direita->esquerda->smax+r->direita->direita->sum);

    }
    //atualiza r
    r->sum=r->esquerda->sum + r->direita->sum;
    r->max=r->direita->max;
    r->smax=max(r->direita->smax,r->esquerda->smax+r->direita->sum);

    return r;
}



//rotacoes
Noh* rot_dir(Noh* r){
    Noh* k;
    k = r->esquerda;
    r->esquerda = k->direita;
    k->direita = r;

    k=atualiza(k);

    return k;
}

Noh* rot_esq(Noh* r){
    Noh* k;
    k = r->direita;
    r->direita = k->esquerda;
    k->esquerda = r;

    k=atualiza(k);

    return k;
}




//Insere
Noh* Adc(Noh* r, long long tipo, long long x, long long t){

    if(r->op){// Adc
        Noh*novo=NewNode(1,tipo,x,t,nullptr,nullptr);
        Noh*aux=NewNode(0,0,0,0,novo,r);
        r=aux;
    }
    else{
        if(t <= r->esquerda->max){//esquerda
        
            r->esquerda = Adc(r->esquerda,tipo,x,t);

            if(r->esquerda->priority > r->priority){
                r = rot_dir(r);
            }

            r = atualiza(r);
        }
        else{//direita
        
            r->direita = Adc(r->direita,tipo,x,t);

            if(r->direita->priority > r->priority){
                r = rot_esq(r);
            }

            r = atualiza(r);

        }
    }
    return r;

}

void PilhaRetro::insert(long long t,long long type,long long x){
    long long i,j,op;

    if(this->raiz==nullptr){
        this->raiz = NewNode(1,type,x,t,nullptr,nullptr);
        return;
    }

    Noh* r;
    r=this->raiz;

    this->raiz=Adc(r,type,x,t);

    return;
}



//Apaga
Noh* Retirar(Noh* r, long long t){
    if(r->esquerda->op){
        if(r->esquerda->t==t){
            r=r->direita;
            return r;
        }
    }
    if(r->direita->op){
        if(r->direita->t==t){
            r=r->esquerda;
            return r;
        }
    }
    if(r->esquerda->max>=t){
        r->esquerda=Retirar(r->esquerda,t);
        r=atualiza(r);
    }
    else{
        r->direita=Retirar(r->direita,t);
        r=atualiza(r);
    }
    
    return r;
}

void PilhaRetro::Delete(long long t){
    if(this->raiz->op){
        this->raiz=nullptr;
        return;
    }
    this->raiz=Retirar(this->raiz,t);
}





//Consultas
long long PilhaRetro::top(long long t){
    return kth(t,1);
}

long long PilhaRetro::size(long long t){//número de elemento na pilha retroativa no instante t
    long long soma=0;
    Noh* r;
    r=this->raiz;

    while(!r->op){
        if(r->esquerda->max>=t){
            r=r->esquerda;
        }
        else{
            soma=soma+r->esquerda->sum;
            r=r->direita;
        }
    }

    if(r->t<=t){
        soma=soma+r->sum;
    }
    
    return soma;
}

pair<Noh*,long long> BuscaSArv(Noh*r, long long t, long long k){
    pair<Noh*,long long> p;
    if(!r->op){
        if(t <= r->esquerda->max){
            p= BuscaSArv(r->esquerda,t,k);
            return p;
        }
        else{
            p= BuscaSArv(r->direita,t,k);
        }
    }
    if(r->op){
        if(r->ehpush){
            if(k==1){
                p=make_pair(r,0);
                return p;
            }
            else{
                p=make_pair(nullptr,k-1);
                return p;
            }
        }
        else{
            p=make_pair(nullptr,k+1);
        }
    }
    else{
        if(p.first==nullptr){
            if(p.second<=r->esquerda->smax){
                p=make_pair(r,p.second);
            }
            else{
                p=make_pair(nullptr,p.second-r->esquerda->sum);
            }
        }
    }

    return p;
}

long long PilhaRetro::kth(long long t, long long k){//k-ésimo elemento da pilha retroativa no instante t
    
    long long x;
    pair<Noh*,long long> p_certo;
    p_certo=BuscaSArv(this->raiz, t,k);//busca pela subarv

    Noh* noh_t=p_certo.first;

    if(noh_t->op){
        if(noh_t->ehpush){
            return noh_t->value;
        }
    }

    Noh* n;
    n=noh_t->esquerda;
    long long kparam=p_certo.second;
    while(!n->op){//vamos descer pela subarvore por aqui
        if(n->direita->smax>=kparam){
            n=n->direita;
        }
        else{
            kparam=kparam-n->direita->sum;
            n=n->esquerda;
        }
    }

    return n->value;
}


//Imprime
void PrintRec(Noh* n, long long i, long long t){
    if (n != nullptr){
        if(n->max>t){
            PrintRec(n->esquerda,i,t);
        }
        else{
            PrintRec(n->esquerda,i+3,t);
            for(long long j=0;j<i;j++){
                cout<<" ";
            }
            cout <<"op:"<< n->op << " p:"<< n->priority<<" max:"<< n->max<<" sum:"<<n->sum<<" smax:"<<n->smax;
            if(n->op){
                cout <<" push:"<< n->ehpush << " t:"<< n->t;
                if(n->ehpush){
                    cout<<" v:"<<n->value;
                }
            }
            cout<<endl;
            PrintRec(n->direita,i+3,t);
        }
	}
}


void PilhaRetro::Print(long long t){
    Noh* n;
    long long i=0;
    //PrintRec(this->raiz,i,t);//print da arvore
    for(i=1;i<=size(t);i++){
        cout<<kth(t,i)<<" ";
    }
    cout<<endl;
	return;
}

