#include <bits/stdc++.h>
#pragma once
using namespace std;

struct Noh{
    bool op;//1 se for operacao 0 se nao for
    bool ehpush;//1 se for push 0 se nao for
    
    long long value;//valor do push
    
    long long t;
    long long sum;
    long long smax;
    long long max;

    long long priority;
    Noh* direita;
    Noh* esquerda;
};

class PilhaRetro{
    private:
        Noh* raiz;
    public:
        Noh* getraiz();
        void setraiz(Noh* r);

        void insert(long long t,long long tipo,long long x);
        void Delete(long long t);
        
        void Print(long long t);
        long long top(long long t);
        long long size(long long t);
        long long kth(long long t, long long k);
};

PilhaRetro retroStack();

