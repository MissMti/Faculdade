#include <bits/stdc++.h>
#include "PilhaR.h"
using namespace std;
#define MAX 500
#define PUSH 1
#define POP 0


int main(){
    long long q,i,n,t=0,x,k,tempo=1;
    PilhaRetro pi;

    pi=retroStack();

    srand(time(NULL));

    while(cin>>n){
        /*if(n==0){
            return 0;
        }*/
        cin>>t;
        if(n==1){
            cin>>x;
            pi.insert(t,PUSH,x);
        }
        if(n==2){
            pi.insert(t,POP,0);
        }
        if(n==3){
            pi.Delete(t);
        }
        if(n==4){
            cout<<pi.size(t)<<endl;
        }
        if(n==5){
            cout<<pi.top(t)<<endl;
        }
        if(n==6){
            cin>>k;
            cout<<pi.kth(t,k)<<endl;
        }
        if(n==7){
            pi.Print(t);
        }
    }

    return 0;

}