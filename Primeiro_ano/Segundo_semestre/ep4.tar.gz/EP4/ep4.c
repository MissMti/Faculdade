#include<stdio.h>
#include<stdlib.h>
#include <string.h>



typedef struct line {
	long linha;
	long freq;
	struct line * prox;
}l;

typedef struct cel {
	char palavra[100];
	struct line * valor;
	struct cel * esq;
	struct cel * dir; 
} no;


l * insere_linha (l * valor, long y);
no * insercao (no * raiz, char * x, long y, int tamanho);
void imprime (l *valor);
void inordem (no *raiz);





int main(int argc, char **argv){/*Funcao principal do programa*/

	no* p=NULL;
	
	char tmp[100];
	char verifica;
	long i,j,k;
	long linha=1;
	FILE *file=fopen(argv[1],"r");/*Programa le da linha de comando o arquivo a ser lido*/
	j=fscanf(file,"%c",&verifica);
	
	while(j!=-1){
		i=1;
		
		if(j==1){
			if((verifica>='A' && verifica<='Z')||(verifica>='a' && verifica<='z')){/*verifica/encontra palavras no texto*/
				tmp[0]=verifica;
				fscanf(file,"%c",&verifica);
				while((verifica>='A' && verifica<='Z')||(verifica>='a' && verifica<='z')){
					tmp[i]=verifica;
					i++;/*conta o tamanho da palavra*/
					fscanf(file,"%c",&verifica);
				}
				
				p = insercao(p, tmp, linha, i);/*Insere no*/
				
				
				for(k=0;k<i;k++){
					tmp[k]='\0';
				}
				
				
			}
		}
		
		if(verifica=='\n'){/*Mudanca de linha*/
			linha++;
		}
		
		j=fscanf(file,"%c",&verifica);
		
	}
	
	inordem(p);/*Imprime em ordem*/
	
	free(p);
	fclose(file);
	return 0;
}






l * insere_linha (l * valor, long y){/*Insere nova celula com informacoes da linha em que a palavra foi encontrada novamente*/
	l * novo = malloc(sizeof(l));
	novo->linha = y ;
	novo->freq = 1 ;
	novo->prox = valor;
	return (novo);
}


no * insercao (no * raiz, char * x, long y, int tamanho){/*Insere no*/
	char tmp[100];
	if (raiz == NULL){/*Insere palavras novas*/
		raiz = malloc (sizeof(no));
		strcpy(raiz->palavra,"");
		strcpy(raiz->palavra,x);
		raiz->valor=malloc(sizeof(l));
		raiz->valor->linha = y;
		raiz->valor->freq = 1;
		raiz->valor->prox=malloc(sizeof(l));
		raiz->valor->prox=NULL;
 		raiz->dir = raiz->esq = NULL;
 	 	return raiz;
  	}
  
	strcpy(tmp,x);

  	if (strcmp(tmp, raiz->palavra) == 0){/*Para o caso em que seja uma palavra ja encontrada anteriormente*/
  		if(raiz->valor->linha==y){/*msm linha*/
  			raiz->valor->freq = raiz->valor->freq+1;
  		}
  		else{/*linhas diferentes*/
  			raiz->valor=insere_linha(raiz->valor,y);	    			
		}		
  
	}
  
	else if (strcmp(tmp, raiz->palavra) < 0)
		raiz->esq = insercao (raiz->esq, x, y,tamanho);
	else if (strcmp(tmp, raiz->palavra) > 0)
		raiz->dir = insercao (raiz->dir, x, y,tamanho);
		
	return raiz;
}


void imprime (l *valor){/*Imprime as linhas em que as palavras aparecem junto as suas frequencias se essas forem maior que 1*/
	if(valor->prox!=NULL){
		imprime(valor->prox);
	}
	printf("%ld",valor->linha);
	if(valor->freq > 1){
    		printf("(%ld)", valor->freq); 
    	}
    	printf("  ");		
}


void inordem (no *raiz) {/*Ordena os nos para que seja impressa as palavras em ordem alfabetica*/
	if (raiz != NULL){
		inordem (raiz->esq);
		printf("%s:  ", raiz->palavra);
		imprime(raiz->valor);
		printf("\n");
		inordem (raiz->dir);
	}
}
