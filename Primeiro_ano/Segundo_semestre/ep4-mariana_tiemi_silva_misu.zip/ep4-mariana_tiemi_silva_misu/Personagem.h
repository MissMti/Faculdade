#include <iostream>
#include <fstream>
#include <random>

#pragma once

/*! \class Personagem
*
*  \brief Essa classe será usada como herança pelas classes Pacman e Fantasma.
*/
using namespace std;

class Personagem {
private:
	int x;
	int y;
public:
	/*! 
	 * \brief Função: setx
	 * Estabelece o valor de x(linha) do personagem.
	 * 
	 * Uso: setx(a);
	 * 
	 * \param (int): inteiro que se torna o valor de x do objeto. 
	 *
	 * \return 
	 */
	void setx(int a);
	
	/*! 
	 * \brief Função: sety
	 * Estabelece o valor de y(coluna) do personagem.
	 * 
	 * Uso: sety(b);
	 * 
	 * \param (int): inteiro que se torna o valor de y do objeto. 
	 *
	 * \return 
	 */
	void sety(int b);

	/*! 
	 * \brief Função: getx
	 * Retorna ao usuario o inteiro x(linha) do personagem.
	 * 
	 * Uso: d = getx();
	 *
	 * \return (int) retorna o valor x.
	*/
	int getx();
	/*! 
	 * \brief Função: gety
	 * Retorna ao usuario o inteiro y(coluna) do personagem.
	 * 
	 * Uso: d = gety();
	 *
	 * \return (int) retorna o valor de y.
	*/
	int gety();
	
};

