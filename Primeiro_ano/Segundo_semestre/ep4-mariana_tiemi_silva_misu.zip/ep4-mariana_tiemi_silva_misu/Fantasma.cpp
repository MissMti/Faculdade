#include <iostream>
#include <fstream>
#include <random>
#include "Fantasma.h"
#include "Personagem.h"

using namespace std;


char Fantasma::getdot() {
	return dot;
}

void Fantasma::setdot(char c) {
	this->dot = c;
}
