#include <iostream>
#include <fstream>
#include <random>
#include "Partida.h"
#include "Personagem.h"
#include "Fantasma.h"
#include "Pacman.h"
#define VIVO 1
#define MORTO 0

using namespace std;


int confere(string* labirinto,int i,int j,Pacman pac,Fantasma* phantom,int n_fantasmas,int l,int c,int a){//0 continua, 1 para;
	char tmp;
	int b;
	
	if(labirinto[l][c]=='P'){
		return 1;
	}
	if(labirinto[l][c]=='.'){
		labirinto[phantom[a].getx()][phantom[a].gety()]=phantom[a].getdot();
		phantom[a].setx(l);
		phantom[a].sety(c);
		phantom[a].setdot('.');
		labirinto[l][c]='F';
	}
	if(labirinto[l][c]==' '){
		labirinto[phantom[a].getx()][phantom[a].gety()]=phantom[a].getdot();
		phantom[a].setx(l);
		phantom[a].sety(c);
		phantom[a].setdot(' ');
		labirinto[l][c]='F';
	}
	if(labirinto[l][c]=='F'){
		labirinto[phantom[a].getx()][phantom[a].gety()]=phantom[a].getdot();
		for(b=0;b<a;b++){//entrou aqui nessa rodada
			if(phantom[b].getx()==l && phantom[b].gety()==c){
				phantom[a].setdot(phantom[b].getdot());
				phantom[b].setdot('F');
			}
		}
		for(b=a;b<n_fantasmas;b++){//estava na rodada passada
			if(phantom[b].getx()==l && phantom[b].gety()==c){
				tmp=phantom[b].getdot();
				phantom[b].setdot('F');
				phantom[a].setdot(tmp);
			}
		}
		
		phantom[a].setx(l);
		phantom[a].sety(c);
		labirinto[l][c]='F';
	}
	return 0;
}


void jogo(string* labirinto,int i,int j,Pacman pac,Fantasma* phantom,int n_fantasmas,int n_pacdots){
	int pontos=0, a;
	int mov_fantasma;
	int l,c;
	int check=0;
	char escolha;
	random_device rd;
	mt19937 mt(rd());
	uniform_int_distribution<int> dist(1,4);
	
	cout << "Começo do Jogo!!!"<<endl;
	
	while(check==0 && pontos<n_pacdots){
	
		for(a=0;a<i;a++){
			cout<<string(labirinto[a])<<endl;
		}
		
		a=0;
		while(a<n_fantasmas && check==0){
			mov_fantasma=dist(mt);
			if(mov_fantasma==1){/*Move esquerda*/
				if(phantom[a].gety()==0){
					if(labirinto[phantom[a].getx()][j-1]!='*'){
						l=phantom[a].getx();
						c=j-1;
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}					
					}
				}
				else{
					if(labirinto[phantom[a].getx()][phantom[a].gety()-1]!='*'){
						l=phantom[a].getx();
						c=phantom[a].gety()-1;
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}
					}
				}
			}
			if(mov_fantasma==2){/*Move direita*/
				if(phantom[a].gety()==j-1){
					if(labirinto[phantom[a].getx()][0]!='*'){
						l=phantom[a].getx();
						c=0;
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}					
					}
				}
				else{
					if(labirinto[phantom[a].getx()][phantom[a].gety()+1]!='*'){
						l=phantom[a].getx();
						c=phantom[a].gety()+1;
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}
					}
				}
			}
			if(mov_fantasma==3){/*Move cima*/
				if(phantom[a].getx()==0){
					if(labirinto[i-1][phantom[a].gety()]!='*'){
						l=i-1;
						c=phantom[a].gety();
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}					
					}
				}
				else{
					if(labirinto[phantom[a].getx()-1][phantom[a].gety()]!='*'){
						l=phantom[a].getx()-1;
						c=phantom[a].gety();
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}
					}
				}
			}
			if(mov_fantasma==4){/*Move baixo*/
				if(phantom[a].getx()==i-1){
					if(labirinto[0][phantom[a].gety()]!='*'){
						l=0;
						c=phantom[a].gety();
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}					
					}
				}
				else{
					if(labirinto[phantom[a].getx()+1][phantom[a].gety()]!='*'){
						l=phantom[a].getx()+1;
						c=phantom[a].gety();
						check=confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a);
						if(check==0){
							a++;
						}
					}
				}
			}
			
			
		}
		
		if (check==1){
			break;
		}
		
		while(true){
			cout << "Direção (a - esquerda, d - direita, w - cima, s - baixo):"<<endl;
			cin>>escolha;
			if(escolha=='a'){
				if(pac.gety()==0){
					if(labirinto[pac.getx()][j-1]!='*'){
						l=pac.getx();
						c=j-1;
						break;				
					}
				}
				else{
					if(labirinto[pac.getx()][pac.gety()-1]!='*'){
						l=pac.getx();
						c=pac.gety()-1;
						break;
					}
				}
			}
			
			if(escolha=='d'){/*Move direita*/
				if(pac.gety()==j-1){
					if(labirinto[pac.getx()][0]!='*'){
						l=pac.getx();
						c=0;
						break;					
					}
				}
				else{
					if(labirinto[pac.getx()][pac.gety()+1]!='*'){
						l=pac.getx();
						c=pac.gety()+1;
						break;
					}
				}
			}
			if(escolha=='w'){/*Move cima*/
				if(pac.getx()==0){
					if(labirinto[i-1][pac.gety()]!='*'){
						l=i-1;
						c=pac.gety();
						break;				
					}
				}
				else{
					if(labirinto[pac.getx()-1][pac.gety()]!='*'){
						l=pac.getx()-1;
						c=pac.gety();
						break;
					}
				}
			}
			if(escolha=='s'){/*Move baixo*/
				if(pac.getx()==i-1){
					if(labirinto[0][pac.gety()]!='*'){
						l=0;
						c=pac.gety();
						break;				
					}
				}
				else{
					if(labirinto[pac.getx()+1][pac.gety()]!='*'){
						l=pac.getx()+1;
						c=pac.gety();
						break;
					}
				}
			}
			
			cout << "Você digitou alguma posição ou comando indisponível,"<<endl;
			cout << "Por favor, escolher outra opção."<<endl;
		}
		
		if(labirinto[l][c]=='F'){
			check=1;
			break;
		}
		else{
			if(labirinto[l][c]=='.'){
				pontos=pontos+1;
				if(pontos==n_pacdots){
					check=2;
					break;
				}
			}
			labirinto[pac.getx()][pac.gety()]=' ';
			pac.setx(l);
			pac.sety(c);
			labirinto[l][c]='P';
		}
		
	}
	
	if (check==1){
			pac.setstatus(MORTO);
			cout << "Game over! Pontos = " << int(pontos) <<endl;
	}
	if (check==2){
			cout << "Congratulations! Pontos = " << int(pontos) <<endl;
	}
}
