#include <iostream>
#include <fstream>
#include <random>

#include "Arquivo.h"
#include "Labirinto.h"

#define MAX_Linha_Coluna 50

using namespace std;



void leitura_arquivo(char* nome){
	string labirinto[MAX_Linha_Coluna];
	int i=0;
	char ch='*';
	int j=0;
	int n_fantasmas=0,n_pacdots=0;
	int l=0,c=0;
	
	ifstream txtFile;
	
	txtFile.open(nome);
	
	while(!txtFile.eof()){
		getline(txtFile,labirinto[i]);	
		i++;
	}
	i=i-1;
	
	/*Conficao para arquivo vazio... ou soh com o espaco do pacman??*/
	
	while(ch=='.'||ch=='F'||ch==' '||ch=='*'){
		ch=labirinto[0][j];
		j++;
	}
	
	for(l=0;l<i;l++){
		for(c=0;c<j;c++){
			ch=labirinto[l][c];
			if(ch=='F'){
				n_fantasmas++;
			}
			if(ch=='.'){
				n_pacdots++;
			}
		}
	}	
	
	j=j-1;
	
	estrutura_labirinto(labirinto,i,j,n_fantasmas,n_pacdots);
}


