#include <iostream>
#include <fstream>
#include <random>
#include "Pacman.h"
#include "Personagem.h"
#define VIVO 1
#define MORTO 0

using namespace std;

int Pacman::getstatus() {
	return status;
}


void Pacman::setstatus(int d){
	this->status = d;
}
