#include <iostream>
#include <fstream>
#include <random>

#include "Personagem.h"
#include "Fantasma.h"
#include "Pacman.h"
#include "Partida.h"
#include "Labirinto.h"
#define VIVO 1
#define MORTO 0

using namespace std;

void estrutura_labirinto(string* labirinto,int i,int j,int n_fantasmas,int n_pacdots){
	int meio_i,meio_j;
	int parametro=0;
	int l,c;
	char ch;
	Pacman pac;
	Fantasma phantom[n_fantasmas];
	
	/*Posiciona o pac man ao centro*/
	labirinto[i/2][j/2]='P';
	pac.setx(i/2);
	pac.sety(j/2);
	pac.setstatus(VIVO);
	
	/*Posiciona os fantasmas*/
	for(l=0;l<i;l++){
		for(c=0;c<j;c++){
			ch=labirinto[l][c];
			if(ch=='F'){
				phantom[parametro].setx(l);
				phantom[parametro].sety(c);
				phantom[parametro].setdot(' ');
				parametro++;
			}
		}
	}
	
	
	jogo(labirinto,i,j,pac,phantom,n_fantasmas,n_pacdots);
	
}
