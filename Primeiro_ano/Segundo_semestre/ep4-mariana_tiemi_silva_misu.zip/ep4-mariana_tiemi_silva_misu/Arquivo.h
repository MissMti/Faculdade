#include <iostream>
#include <fstream>
#include <random>

using namespace std;

/*! 
 * \brief Função: leitura_arquivo
 * Essa funcao le um arquivo de nome "nome".
 * 
 * Uso: leitura_arquivo(nome);
 * 
 * \param nome do arquivo que sera lido.
*/

void leitura_arquivo(char* nome);


