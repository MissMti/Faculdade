#include <iostream>
#include <fstream>
#include <random>
#define VIVO 1
#define MORTO 0

/*! 
 * \brief Função: estrutura_labirinto
 * Essa funcao, estabelce os locais do pacman e fantasmas, a fim de terminar a estrutura do labirinto.
 * 
 * Uso: estrutura_labirinto(labirinto,i,j,n_fantasmas,n_pacdots);
 * 
 * \param labirinto
 * \param valor de i(linhas)
 * \param valor de j(colunas)
 * \param numero de fantasmas do labirinto
 * \param numero de pacdots do labirinto
*/

using namespace std;

void estrutura_labirinto(string* labirinto,int i,int j,int n_fantasmas,int n_pacdots);
