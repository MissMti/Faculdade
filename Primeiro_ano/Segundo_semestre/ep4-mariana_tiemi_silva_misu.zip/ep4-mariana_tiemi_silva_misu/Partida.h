#include <iostream>
#include <fstream>
#include <random>
#include "Personagem.h"
#include "Fantasma.h"
#include "Pacman.h"
#define VIVO 1
#define MORTO 0

using namespace std;

/*! 
 * \brief Função: confere
 * Essa funcao, confere para onde o fantasma irá se mover.
 * 
 * Uso: d= confere(labirinto,i,j,pac,phantom,n_fantasmas,l,c,a)
 * 
 * \param labirinto
 * \param o pacman
 * \param os fantasmas
 * \param numero de fantasmas do labirinto
 * \param valor de linha onde o fantasma irá se mover
 * \param valor da coluna onde o fantasma irá se mover
 * \param qual fantasma esta sendo analisado
*/
int confere(string* labirinto,int i,int j,Pacman pac,Fantasma* phantom,int n_fantasmas,int l,int c,int a);
/*! 
 * \brief Função: jogo
 * Essa funcao, é onde o jogo realmente é gerado.
 * 
 * Uso: jogo(labirinto,i,j,pac,phantom,n_fantasmas,n_pacdots);
 * 
 * \param labirinto
 * \param valor de i(linhas)
 * \param valor de j(colunas)
 * \param o pacman
 * \param os fantasmas
 * \param numero de fantasmas do labirinto
 * \param numero de pacdots do labirinto
*/
void jogo(string* labirinto,int i,int j,Pacman pac,Fantasma* phantom,int n_fantasmas,int n_pacdots);
