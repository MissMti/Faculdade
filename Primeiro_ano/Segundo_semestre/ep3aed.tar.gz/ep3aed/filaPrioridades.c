#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "filaPrioridades.h"

void corrige_heap_descendo(long i, word* lista_palavras,long n){
	char aux[12];
	long maior=i;
	if((2*i<n) && (strcmp(lista_palavras[2*i].letras,lista_palavras[maior].letras)>0)){
		maior=2*i;
	}
	
	if((2*i+1<n) && (strcmp(lista_palavras[2*i+1].letras,lista_palavras[maior].letras)>0)){
		maior=2*i+1;
	}
	
	if(maior != i){
		strcpy(aux,lista_palavras[i].letras);
		strcpy(lista_palavras[i].letras,lista_palavras[maior].letras);
		strcpy(lista_palavras[maior].letras,aux);
		corrige_heap_descendo(maior, lista_palavras,n);
	}
}


void constroi_heap(long n,word* lista_palavras){
	long i;
	
	for (i = (n/2); i >= 0; i--) {                   
 	     corrige_heap_descendo(i, lista_palavras,n);
        }
}


void heapsort(word* lista_palavras,long n){
	long i,tamanho;
	char aux[12];
	tamanho=n;
	
	constroi_heap(n,lista_palavras);
	for(i=n-1;i>0;i--){
		
		strcpy(aux,lista_palavras[i].letras);
		strcpy(lista_palavras[i].letras,lista_palavras[0].letras);
		strcpy(lista_palavras[0].letras,aux);	
		
		tamanho=tamanho-1;
		corrige_heap_descendo(0, lista_palavras,tamanho);
	}
}
