#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "filaPrioridades.h"



word* leitura(word* lista_leitura, long n){
	long i;
	
	printf("\nAgora, insira a lista de palavras: \n");
	for(i=0;i<n;i++){
		scanf("\n %s",lista_leitura[i].letras);
	}
	return lista_leitura;
}


int main(){
	long n,i;
	word* lista_palavras;
	
	printf("\nPor favor, insira o numero de palavras da lista: ");
	scanf("%ld",&n);
	lista_palavras=malloc(sizeof(word)*n);
	lista_palavras=leitura(lista_palavras,n);
	
	
	heapsort(lista_palavras, n);
	
	
	printf("\n\nLista ordenada das palavras: \n");
	for(i=0;i<n;i++){
		printf("%s \n",lista_palavras[i].letras);
	}
	
	printf("\n");

	free(lista_palavras);
	return 0;
}
