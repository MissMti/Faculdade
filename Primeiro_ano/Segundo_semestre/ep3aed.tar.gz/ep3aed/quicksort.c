#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#define MAX 12





char** troca (char* v[], long i, long j){
	char* aux;
	
	aux = v[j];
	v[j] = v[i];
	v[i] = aux;
	return v;
}





long particiona (char* v[], long comeco, long final) {
	long i, j;
	char* x;

	i = comeco;
	j = final+1;
	x = v[comeco];
	
	while (1){
		while (strcmp(v[++i],x)<0)
			if (i == final){
				break;
			}
    
		while (strcmp(v[--j],x)>0)
			if (j == comeco){
				break;
			}
    	
		if (i >= j)
			break;
			
		v=troca(v, i, j);
		
	}
	
	v=troca(v, comeco, j);
	
	return j;

}




void quicksort (char* v[], long comeco, long final) {
	long x;

	if (comeco < final){
		x = particiona(v, comeco, final);
		quicksort(v, comeco, x - 1);
		quicksort(v, x + 1, final);
	}

}




char** leitura(char** lista_leitura, long n){
	long i,j,len;
	char* palavra_tmp;
	palavra_tmp=malloc(sizeof(char)*MAX);
	
	printf("\nAgora, insira a lista de palavras: \n");
	for(i=0;i<n;i++){
		scanf("\n %s",palavra_tmp);
		len = strlen(palavra_tmp);
		lista_leitura[i]=malloc(sizeof(char)*len);
		for(j=0;j<len;j++){
			lista_leitura[i][j]=palavra_tmp[j];
		}
		
	}
	free(palavra_tmp);
	return lista_leitura;
}





int main(){
	long n,i;
	char** lista_palavras;
	
	printf("\nPor favor, insira o numero de palavras da lista: ");
	scanf("%ld",&n);
	lista_palavras=malloc(sizeof(char*)*n);
	lista_palavras=leitura(lista_palavras,n);

	
	quicksort(lista_palavras, 0, n - 1);
	
	
	printf("\n\nLista ordenada das palavras: \n");
	for(i=0;i<n;i++){
		printf("%s \n",lista_palavras[i]);
	}

	printf("\n");
	free(lista_palavras);
	return 0;
}
