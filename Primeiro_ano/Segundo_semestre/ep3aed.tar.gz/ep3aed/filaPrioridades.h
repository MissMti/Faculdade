#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#define MAX 12

typedef struct {
	char letras[MAX];
}word;

/*
 * Função: corrige_heap_descendo;
 * Certifica-se que o maior número é o "pai" do heap.
 * 
 * Uso: corrige_heap_descendo(i, lista_palavras, n);
 * 
 * i (long): numero da posicao do "pai" do heap
 * lista_palavras (word*): estrutura que contem a lista de palavras.
 * n (long): tamanho da lista a ser verificada.
*/
void corrige_heap_descendo(long i, word* lista_palavras,long n);

/*
 * Função: constroi_heap;
 * Constrói a estrutura de heap com o vetor.
 * 
 * Uso: constroi_heap(n,lista_palavras);
 * 
 * n (long): tamanho da lista.
 * lista_palavras (word*): estrutura que contem a lista de palavras.
*/
void constroi_heap(long n,word* lista_palavras);

/*
 * Função: heapsort;
 * Ordena o vetor ao retirar as palavras mais prioritarias, "pai" do heap, e colocá-los 
 * no final do vetor, e repetir o processo de correção e retirada com os outros 
 * elementos ainda não ordenados.
 * 
 * Uso: heapsort(lista_palavras, n);
 * 
 * lista_palavras (word*): estrutura que contem a lista de palavras.
  * n (long): tamanho da lista.
*/
void heapsort(word* lista_palavras,long n);

