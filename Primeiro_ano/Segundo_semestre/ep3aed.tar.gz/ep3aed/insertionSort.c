#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 12


char** insertionSort (char* A[], long n) {
	long i,j;
	char* chave;
	chave=malloc(sizeof(char)*MAX);
    
	for (i = 1; i < n; i++) {
		chave = A[i];
		j = i - 1;
		
		while (j >= 0 && strcmp(A[j],chave)>0) {
			A[j + 1] = A[j];
			j = j - 1;	
		}
		A[j + 1] = chave;
		
	}
	return A;
}


char** leitura(char** lista_leitura, int n){
	long i,j,len;
	char* palavra_tmp;
	palavra_tmp=malloc(sizeof(char)*MAX);
	
	printf("\nAgora,insira a lista de palavras: \n");
	for(i=0;i<n;i++){
		scanf("\n %s",palavra_tmp);
		len = strlen(palavra_tmp);
		lista_leitura[i]=malloc(sizeof(char)*len);
		for(j=0;j<len;j++){
			lista_leitura[i][j]=palavra_tmp[j];
		}
	}
	free(palavra_tmp);
	return lista_leitura;
}

	

int main() {
	long n,i;
	char** lista_palavras; 
	
	printf("\nPor favor, insira o numero n de palavras da lista: ");
	scanf("%ld",&n);
	lista_palavras=malloc(sizeof(char*)*n);
	lista_palavras=leitura(lista_palavras,n);

	
	lista_palavras=insertionSort(lista_palavras, n);
	
	
	printf("\n\nLista ordenada das palavras: \n");
	for(i=0;i<n;i++){
		printf("%s \n",lista_palavras[i]);
	}
	printf("\n");

	free(lista_palavras);
	
	return 0;	
}

