#include <iostream>
#include <fstream>
#include <random>

using namespace std;

/*! \class Labirinto
*
*  \brief Essa classe define o labirinto e o i (numero de linhas do labirinto).
*/

class Labirinto{
private:
	string* mapa;
	int i;
public:
	/*! 
	 * \brief Função: setmapa
	 * Essa funcao estabelece o labirinto e o valor de i do arquivo.
	 * 
	 * Uso: setmapa(n);
	 * 
	 * \param nome do arquivo que sera lido.
	*/
	void setmapa(char* n);
	/*! 
	 * \brief Função: getmapa
	 * Essa funcao devolve o labirinto.
	 * 
	 * Uso: getmapa();
	 * 
	 * \return (string*) retorna o labirinto
	*/
	string* getmapa();
	/*! 
	 * \brief Função: geti
	 * Essa funcao devolve o valor de i.
	 * 
	 * Uso: geti();
	 * 
	 * \return (int) retorna o valor do i
	*/
	int geti();
};
