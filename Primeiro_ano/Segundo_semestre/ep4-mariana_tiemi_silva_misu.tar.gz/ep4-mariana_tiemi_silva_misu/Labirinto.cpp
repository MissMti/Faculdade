#include <iostream>
#include <fstream>
#include <random>

#include "Labirinto.h"
#define VIVO 1
#define MORTO 0
#define MAX 50

using namespace std;

void Labirinto::setmapa(char* n){
	string maps[50];
	int v=0,a;
	ifstream txtFile;
	txtFile.open(n);
	while(!txtFile.eof()){
		getline(txtFile,maps[v]);	
		v++;
	}
	v=v-1;
	
	this->i=v;
	this->mapa=maps;
	
}

string* Labirinto::getmapa(){
	return mapa;
}

int Labirinto::geti(){
	return i;
}
