#include <iostream>
#include <fstream>
#include <random>
#include <gtest/gtest.h>
#include "Personagem.h"
#include "Fantasma.h"
#include "Pacman.h"
#include "Partida.h"
#include "Arquivo.h"
#include "Labirinto.h"

#ifndef NDEBUG

using namespace std;
	
int main(int argc, char **argv) {
	Arquivo arc;
	Labirinto map;
	Partida game;
	int i;
	
	arc.setarq(argv[1]);
	map.setmapa(arc.getarq());
	i=map.geti();
	game.jogo(map.getmapa(),i);

	#endif
	return 0;
}


