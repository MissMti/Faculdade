#include <iostream>
#include <fstream>
#include <random>
/*#include <gtest/gtest.h>*/
#include "Personagem.h"

using namespace std;

void Personagem::setx(int x) {
	this->x = x;
}

void Personagem::sety(int y) {
	this->y = y;
}

int Personagem::getx() {
	return x;
}

int Personagem::gety() {
	return y;
}
