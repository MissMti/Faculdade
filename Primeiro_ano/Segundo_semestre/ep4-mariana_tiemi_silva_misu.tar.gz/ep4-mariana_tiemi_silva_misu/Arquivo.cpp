#include <iostream>
#include <fstream>
#include <random>

#include "Arquivo.h"

#define MAX_Linha_Coluna 50

using namespace std;

void Arquivo::setarq(char* nome){
	this->arq = nome;
}

char* Arquivo::getarq(){
	return arq;
}


