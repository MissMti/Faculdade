#include <iostream>
#include <fstream>
#include <random>
#include "Personagem.h"
#pragma once

using namespace std;

/*! \class Fantasma
*
*  \brief Essa classe é herdeira da Classe Personagem e é a classe que estabelece o funcionamento dos fantasmas.
*/
class Fantasma:public Personagem{
private:
	char dot;

public:
	/*! 
	 * \brief Função: getdot
	 * Retorna ao usuario o character dot.
	 * 
	 * Uso: d = getdot();
	 *
	 * \return (char) retorna o que se encontrava previamente abaixo do fantasma.
	*/
	char getdot();
	/*! 
	 * \brief Função: setdot
	 * Estabelece o valor de dot.
	 * 
	 * Uso: setdot(c);
	 * 
	 * \param char c: caracter que funciona como uma memoria do que estava "abaixo" do fantasma. 
	 *
	 * \return 
	 */
	void setdot(char c);	
};
