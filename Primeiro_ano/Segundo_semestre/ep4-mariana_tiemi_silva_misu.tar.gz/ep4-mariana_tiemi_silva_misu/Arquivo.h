#include <iostream>
#include <fstream>
#include <random>

using namespace std;


/*! \class Arquivo
*
*  \brief Essa classe será usada para pegar o nome do arquivo.
*/
class Arquivo{
private:
	char* arq;
public:
	/*! 
	 * \brief Função: setarq
	 * Essa funcao estabelece o "nome" do arquivo.
	 * 
	 * Uso: setarq(nome);
	 * 
	 * \param nome do arquivo que sera lido.
	*/
	void setarq(char* nome);
	/*! 
	 * \brief Função: getarq
	 * Essa funcao devolve o nome do arquivo.
	 * 
	 * Uso: getarq();
	 * 
	 * \return (char*) retorna o nome do arquivo
	*/
	char* getarq();
};

