#include <iostream>
#include <fstream>
#include <random>
#include "Personagem.h"
#include "Fantasma.h"
#include "Pacman.h"
#define VIVO 1
#define MORTO 0

using namespace std;

/*! \class Partida
*
*  \brief Essa classe é a principal responsavel pelo funcionamento do programa sendo a que roda o jogo.
*/
class Partida{
private:
	int points;
public:
	/*! 
	 * \brief Função: jogo
	 * Funcao responsavel pelo jogo.
	 * 
	 * Uso: jogo(n,i);
	 * 
	 * \param (string*): o labirinto.
	 * \param (int): qunatidade de linhas do mapa.
	 *
	 * \return 
	 */
	void jogo(string* n,int i);
	/*! 
	 * \brief Função: getpoints
	 * Essa funcao devolve a quantidade de pontos.
	 * 
	 * Uso: getpoints();
	 * 
	 * \return (int) retorna o valor dos pontos
	*/
	int getpoints();
};
