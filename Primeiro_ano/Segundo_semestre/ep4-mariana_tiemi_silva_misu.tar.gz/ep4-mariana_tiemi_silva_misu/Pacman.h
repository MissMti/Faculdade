#include <iostream>
#include <fstream>
#include <random>
#include "Personagem.h"
#pragma once
#define VIVO 1
#define MORTO 0
using namespace std;

/*! \class Pacman
*
*  \brief Essa classe é herdeira da Classe Personagem e é a classe que estabelece o funcionamento do Pacman.
*/
class Pacman:public Personagem{
private:
	int status;

public:
	/*! 
	 * \brief Função: setstatus
	 * Estabelece o valor de status.
	 * 
	 * Uso: setstatus(d);
	 * 
	 * \param int: Estabelece se o pacman esta vivo ou morto. 
	 *
	 * \return 
	 */
	void setstatus(int d);
	/*! 
	 * \brief Função: getstatus
	 * Retorna ao usuario o inteiro status.
	 * 
	 * Uso: d = getstatus();
	 *
	 * \return (int) retorna se o pacman esta vivo ou morto.
	*/
	int getstatus();		
};
