#include <stdio.h>
#include <stdlib.h>
#include "vetoraleatorio.h"

long long * criaVetorAleatorio(int semente, int tamanho){
long long * vetor;
long long r,h;
int j;
vetor = malloc(sizeof(long long)*tamanho);

srand(semente);

for (j = 0; j < tamanho; j++) {
	r=rand();
	h=rand();
        vetor[j] =  r*4294967296+h;
}

return vetor;
}
