#include <stdio.h>
#include <stdlib.h>
#include "vetoraleatorio.h"
#include "propriedadesnumericas.h"


int main(){
int semente, tamanho, nvetor,i,j;
long a,b,c,d,e,f;
int sucesso;
struct timeval t0,t1;
long elapsed;
long long* vetor;


//MODIFICAR VALORES AQUI:
semente=1;//semente para a criacao de valores pseudo-aleatorios
tamanho=1;//tamanho do vetor
nvetor=1;//numero de vetores

vetor=malloc(sizeof(long long)*tamanho);//aloca memoria para o vetor

for(i=0;i<nvetor;i++){

	vetor=criaVetorAleatorio(semente,tamanho);//funcao que gera os vetores com numeros pseudo-aleatorios
	
	for(j=0;j<tamanho;j++){
	
		a= ehPar(vetor[j]);//funcao que define se o numero é ou não par, 1 se for, 0 se nao.
		
		b= ehPrimo(vetor[j]);//funcao que define se o numero é ou não primo, 1 se for, 0 se nao.
		
		c= ehQuadradoPerfeito(vetor[j]);//funcao que define se o numero é ou não quadrado perfeito, 1 se for, 0 se nao.
		
		d= ehCuboPerfeito(vetor[j]);//funcao que define se o numero é ou não cubo perfeito, 1 se for, 0 se nao.
		
		e= ehFibonacci(vetor[j]);//funcao que define se o numero é ou não parte da sequencia de fibonacci, 1 se for, 0 se nao.
		
		f= ehFatorial(vetor[j]);//funcao que define se o numero é ou não fatorial, 1 se for, 0 se nao.
		
		printf("\nValor: %lld",vetor[j]);
		printf("\nResultado dos testes: \n");
		printf("ehPar: %ld, ehPrimo: %ld, ehQuadradoPerfeito: %ld, ehCuboPerfeito: %ld, ehFibonacci: %ld, ehFatorial: %ld\n \n",a,b,c,d,e,f);
	}
}
	
free(vetor);
return 0;
}
