#!/bin/bash


function verifica { #funcao usada para verificar algum problema com a compilacao, devolve 1, caso haja algum problema, e 0 caso nao.
if [ $? -ne 0 ]; then
	echo "A compilação falhou :("
	echo "1"
	exit 1
else
	echo "0"
fi
}



gcc -Wall -c -o propriedadesnumericas.o propriedadesnumericas.c 
verifica

ar -rcv libpropriedadesnumericas.a propriedadesnumericas.o #converte propriedadesnumericas em uma biblioteca estatica
verifica

gcc -c -fPIC -o vetoraleatorio.o vetoraleatorio.c
verifica

gcc -o libvetoraleatorio.so -shared vetoraleatorio.o #converte vetoraleatorio em uma biblioteca dinamica
verifica

gcc -o testa testa.c -L${PWD} libvetoraleatorio.so libpropriedadesnumericas.a #faz compilacao entre bibliotecas e testa.c, gerando o executavel testa
verifica

export LD_LIBRARY_PATH=/tmp/ep3-mariana_tiemi_silva_misu:${LD_LIBRARY_PATH}

./testa #executa testa




doxygen Doxyfile #executa o doxygen para a criacao da documentacao

if [ $? -ne 0 ]; then #para caso de algum problema no doxygen
	echo "O doxygen falhou :("
	echo "1"
else
	echo "0"
fi





rm -f testa propriedadesnumericas.o vetoraleatorio.o libvetoraleatorio.so libpropriedadesnumericas.a #remove esses arquivos

exit 0
