#include <stdio.h>
#include <stdlib.h>
#include "propriedadesnumericas.h"

int ehPar(long long num){
if(num%2==0){
	return 1;	
}
return 0;
}

int ehPrimo(long long num){
long long i;
if (num==0 || num==1){
	return 0;
}

for(i=2;i<num/2+1;i++){
	if(num%i==0){
		return 0;
	}
}
return 1;
}

int ehQuadradoPerfeito(long long num){
long long i;
i=0;
while(i*i <=num){
	if(i*i==num){
		return 1;
	}
	i++;
}
return 0;
}

int ehCuboPerfeito(long long num){
long long i;
i=0;
while(i*i*i<=num){
	if(i*i*i==num){
		return 1;
	}
	i++;
}
return 0;
}

int ehFibonacci(long long num){
long long i,j,tmp;
i=0;
j=1;

if(num==0){
	return 1;
}

while(i < num/2+1){
	if(i+j==num){
		return 1;
	}
	tmp = i;
	i = j;
	j = tmp+j;
}

return 0;
}

int ehFatorial(long long num){
long long i,atual;
i=2;
atual=1;

while(atual<=num){
	if(atual==num){
		return 1;
	}
	atual=atual*i;
	i++;
}
return 0;
}
