#include <stdio.h>
#include <stdlib.h>

/*! 
 * \brief Função: criaVetorAleatorio
 * Gera um vetor com valores pseudo-aleatorios. Faz isso a partir da semente "semente" e gera um vetor de tamanho "tamanho" desses valores. 
 * 
 * Uso: d = ehPar(numero);
 * 
 * \param semente (int): semente para a criacao dos valores.
 * \param tamanho (int): tamanho do vetor de valores aleatorios.
 *
 * \return (long long *) retorna um vetor com valores pseudo-aleatorios (long long)
*/

long long * criaVetorAleatorio(int semente, int tamanho);
