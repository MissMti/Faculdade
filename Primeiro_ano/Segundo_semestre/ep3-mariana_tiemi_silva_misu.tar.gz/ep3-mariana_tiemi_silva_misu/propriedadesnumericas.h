#include <stdio.h>
#include <stdlib.h>

/*! 
 * \brief Função: ehPar
 * Verifica se um numero é par ou não. Faz isso com base no resto da
 * divisão do número por 2. Se esse resto for zero, é porque é par. Caso contraio,
 * é porque é impar.
 * 
 * Uso: a = ehPar(numero);
 * 
 * \param num (long long): numero que será testado.
 * \return  (int): 1 se for par. 0 se não for par.
*/

int ehPar(long long num);

/*! 
 * \brief Função: ehPrimo
 * Verifica se um numero é primo ou não. Faz isso com base de se algum resto de
 * divisão do número por algum valor entre [2;numero/2] é igual a zero. 
 * Se algum resto for zero, é porque o numero não é primo. 
 * Caso contraio, é porque é um numero primo.
 * 
 * Uso: b = ehPrimo(numero);
 * 
 * \param num (long long): numero que será testado.
 * \return  (int): 1 se for primo. 0 se não for primo.
*/


int ehPrimo(long long num);

/*! 
 * \brief Função: ehQuadradoPerfeito
 * Verifica se um numero é quadrado perfeito ou não. Faz isso com base da
 * tentativa e erro, comparando os valores de se i*i é igual ao numero ou não,
 * com i começando desde 0 somando 1 até chegar em um valor em que i*i
 * seja maior que o proprio numero ou que i*i seja igual ao numero.
 * Caso encontre algum i, tal que i*i==num, num é um quadrado perfeito.
 * 
 * Uso: c = ehQuadradoPerfeito(numero);
 * 
 * \param num (long long): numero que será testado.
 * \return  (int): 1 se for quadrado perfeito. 0 se não for quadrado perfeito.
*/

int ehQuadradoPerfeito(long long num);

/*! 
 * \brief Função: ehCuboPerfeito
 * Verifica se um numero é cubo perfeito ou não. Faz isso com base da
 * tentativa e erro, comparando os valores de se i*i*i é igual ao numero ou não,
 * com i começando desde 0 somando 1 até chegar em um valor em que i*i*i
 * seja maior que o proprio numero ou que i*i*i seja igual ao numero.
 * Caso encontre algum i, tal que i*i*i==num, num é um cubo perfeito.
 * 
 * Uso: d = ehCuboPerfeito(numero);
 * 
 * \param num (long long): numero que será testado.
 * \return  (int): 1 se for cubo perfeito. 0 se não for cubo perfeito.
*/

int ehCuboPerfeito(long long num);

/*! 
 * \brief Função: ehFibonacci
 * Verifica se um numero é parte da seuqencia de fibonacci ou não. Faz isso com
 * base da tentativa e erro, comparando as somas (valores da sequencia) 
 * é igual ao numero ou não, comecando com 0 até chegar a uma soma que seja maior ou
 * igual ao valor do numero.
 * Caso encontre alguma soma i+j, tal que i+j==num, num é parte da sequencia.
 * 
 * Uso: e = ehFibonacci(numero);
 * 
 * \param num (long long): numero que será testado.
 * \return  (int): 1 se for parte da sequencia de fibonacci. 0 se não for.
*/

int ehFibonacci(long long num);

/*! 
 * \brief Função: ehFatorial
 * Verifica se um numero é fatorial ou não. Faz isso com base da
 * tentativa e erro, comparando os valores do produto das multiplicacoes
 * com o numero, com o produto começando desde 1 multpilicando por valores 
 * 1 unidade maior que o valor ultimo valor multiplicado.
 * Caso encontre algum produto atual, tal que atual==num, num é fatorial.
 * 
 * Uso: f = ehFatorial(numero);
 * 
 *\param num (long long): numero que será testado.
 * \return  (int): 1 se for fatorial. 0 se não for fatorial.
*/

int ehFatorial(long long num);
