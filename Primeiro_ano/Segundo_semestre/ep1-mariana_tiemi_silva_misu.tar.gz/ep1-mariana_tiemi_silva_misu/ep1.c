#include <stdio.h>
#include <stdlib.h>





/*Funcao que define se o numero eh primo ou nao*/
int eh_primo(int numero){ 
int i;
if (numero==1){
	return 0;
	
}
for(i=2;i<=numero/2;i++){
	if (numero%i==0){
		return 0;
	}
}
return 1;
}





/*Funcao que entra em looping ate achar o proximo primo*/
void qual_prox_primo(int numero){
int primo;
primo=0;
while(primo==0){
	numero = numero+1;
	primo = eh_primo(numero);
}
printf("%d",numero);
}






/*Funcao que encontra um divisor para o numero e confere se ele e o quociente da divisao do numero por ele sao primos*/
void eh_mult_primo(int numero){
int divide, primeiro_mult, segundo_mult;
int veredito;
primeiro_mult=0;
divide=1;
while (primeiro_mult==0){
	divide=divide+1;
	if(numero%divide==0){
		primeiro_mult=divide;
	}
}
segundo_mult=numero/primeiro_mult;

veredito=eh_primo(primeiro_mult);
if (veredito==1){
	veredito = eh_primo(segundo_mult);
	if(veredito==1){
		printf("%d %d",primeiro_mult,segundo_mult);
	}
}

}




/*Funcao que lê as informacoes e define o modulo de exe*/
int main (){
int modulo_exe;
int num;

scanf(" %d %d",&modulo_exe,&num);

if (modulo_exe == 0){
	qual_prox_primo(num);
}
else {
	eh_mult_primo(num);
}

return 0;
}
