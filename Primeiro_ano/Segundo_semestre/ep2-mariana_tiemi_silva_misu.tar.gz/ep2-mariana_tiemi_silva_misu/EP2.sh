#!/bin/bash

Intervalo=$1
Caminho=$2
LimiteOc=$3
Token=$4
IDbot=$5

Repetidor=0
Contador=0
Soma=0
TempoForadoAR=0

while [ $Repetidor -eq 0 ]; do
	
	echo "   "
	echo "   " >> $Caminho
	
	echo -n "Data: "	
	echo $(date +%d/%m/%y)	
	echo -n "Horário: "	
	echo $(date +%H:%M:%S)	
	
	echo -n "Data: "	>> $Caminho
	echo $(date +%d/%m/%y)	>> $Caminho
	echo -n "Horário: "	>> $Caminho
	echo $(date +%H:%M:%S)	>> $Caminho
	
	curl -s --data "text= " https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null	
	curl -s --data "text=Data: $(date +%d/%m/%y)" https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
	curl -s --data "text=Horario: $(date +%H:%M:%S)" https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
	
	
	
	
	
	IP=$(netstat -anp 2>/dev/null|grep 45052|grep ESTABELECIDA| cut -d' ' -f 16| cut -c 1-9 | sort | uniq)
	
	if [ -z $IP ]; then
		echo "Não há conexões no momento"
	else
		echo "Há conexões no momento em: "
		netstat -anp 2>/dev/null| grep 45052 | grep ESTABELECIDA | cut -d' ' -f 16| cut -c 1-9|sort | uniq
		echo "Há conexões no momento em: " >> $Caminho
		echo $(netstat -anp 2>/dev/null| grep 45052 | grep ESTABELECIDA | cut -d' ' -f 16| cut -c 1-9|  sort | uniq) >> $Caminho
		curl -s --data "text= Há conexões no momento em: " https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
		curl -s --data "text= $(netstat -anp 2>/dev/null| grep 45052 | grep ESTABELECIDA | cut -d' ' -f 16| cut -c 1-9| sort | uniq)" https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
	fi
	
	
	
	
	
	
	Ociosidade=$(top -n 1| grep CPU| grep , | cut -d' ' -f11 | cut -c 1-2)
	
	if [ $Ociosidade -eq $Ociosidade ] 2>/dev/null;then
		echo -n
	else
		Ociosidade=100
	fi


	var=$( echo "$Ociosidade>$LimiteOc" | bc -l )
	
	if [ $var -eq 1 ]; then
		echo "Ociosidade acima do limite"
		echo "Ociosidade: $Ociosidade %" >> $Caminho
	else
		echo "Ociosidade: $Ociosidade %"
		curl -s --data "text= Ociosidade: $Ociosidade %" https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
		echo "Ociosidade: $Ociosidade %" >> $Caminho
	fi

	
	
	
	
	
	
	
	Servidor=$(netstat -anp 2>/dev/null|grep 45052|grep OUÇA|cut -d' ' -f 42)
	
	if [ -z $Servidor ]; then
		echo "Servidor fora do ar"
		echo "Servidor fora do ar">> $Caminho
		curl -s --data "text= Servidor fora do ar" https://api.telegram.org/bot"$Token"/sendMessage?chat_id="$IDbot" 1>/dev/null
		let TempoForadoAR=TempoForadoAR+1
	else
		echo "Conectado"
	fi
	
	
	
	
	let Contador=Contador+1
	Soma=$(echo "scale=2;$Soma+$Ociosidade"|bc -l)
	if [ $Contador == 100 ];then
		Contador=0
		echo -n "A média da ociosidades foi de :  " >> $Caminho
		echo -n $( echo "scale=2;$Soma/100" |bc -l) >> $Caminho
		echo " %" >> $Caminho
		Soma=0
		echo -n "O Programa ficou fora do ar por aproximadamente :  " >> $Caminho
		echo -n $(echo "scale=2;$Intervalo*$TempoForadoAR" |bc -l) >> $Caminho
		echo " segundos" >> $Caminho
		TempoForadoAR=0
	else
		echo -n ""
	fi
	
	
	
	echo "   "
	echo "   " >> $Caminho
	
	sleep "$Intervalo"s
done




exit 0
